/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Master Application Entry Point
 * HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine
 */

import React, { useState, useEffect } from 'react';
import { Sidebar, NavView } from './components/Sidebar';
import { TopNav } from './components/TopNav';
import { OverviewView } from './components/OverviewView';
import { ForecastView } from './components/ForecastView';
import { GridControllerView } from './components/GridControllerView';
import { BatteryView } from './components/BatteryView';
import { UploadView } from './components/UploadView';
import { AnalyticsView } from './components/AnalyticsView';
import { EventsView } from './components/EventsView';
import { ConfigView } from './components/ConfigView';
import { MlLabView } from './components/MlLabView';
import { ExplainabilityView } from './components/ExplainabilityView';
import { UncertaintyView } from './components/UncertaintyView';
import { PeakIntelligenceView } from './components/PeakIntelligenceView';
import { NationalGridView } from './components/NationalGridView';
import type {
  BatteryConfig,
  ForecastHourResult,
  GridEvent,
  GridMode,
  TelemetryRow,
} from './types/microgrid';
import { DEFAULT_BATTERY_CONFIG } from './engine/batterySimulator';
import { generateSynthetic24HourTelemetry, executeForecast } from './engine/forecastingEngine';

export default function App() {
  const [currentView, setCurrentView] = useState<NavView>('overview');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const [forecastData, setForecastData] = useState<ForecastHourResult[]>([]);
  const [batteryConfig, setBatteryConfig] = useState<BatteryConfig>(DEFAULT_BATTERY_CONFIG);
  const [isForecasting, setIsForecasting] = useState<boolean>(false);
  const [events, setEvents] = useState<GridEvent[]>([]);

  const [metadata, setMetadata] = useState({
    modelUsed: 'Trained Ridge Regression (Held-Out Evaluated on Official Telemetry)',
    isQuickMlLive: false,
    forecastingMode: 'local_baseline_demo',
    timestamp: new Date().toISOString(),
    notes: 'System initialized. Ready for telemetry ingestion or live QuickML invocation.',
  });

  // Fetch latest forecast & grid status from backend or seed on mount
  useEffect(() => {
    fetch('/api/forecast/latest')
      .then(res => res.json())
      .then(data => {
        if (data.forecast && Array.isArray(data.forecast) && data.forecast.length > 0) {
          setForecastData(data.forecast);
          if (data.metadata) {
            setMetadata(data.metadata);
          }
          if (data.batteryConfig) {
            setBatteryConfig(data.batteryConfig);
          }
        } else {
          runLocalSeedForecast();
        }
      })
      .catch(() => {
        runLocalSeedForecast();
      });

    fetch('/api/grid/events')
      .then(res => res.json())
      .then(data => {
        if (data.events) setEvents(data.events);
      })
      .catch(() => {});
  }, []);

  const runLocalSeedForecast = async () => {
    const seed = generateSynthetic24HourTelemetry();
    const output = await executeForecast(seed);
    setForecastData(output.results);
    setMetadata({
      modelUsed: output.modelUsed,
      isQuickMlLive: output.isQuickMlLive,
      forecastingMode: output.forecastingMode,
      timestamp: output.executionTimestamp,
      notes: output.notes,
    });
  };

  // Run or Refresh 24-Hour Forecast (Phase 2: Zero client secrets sent)
  const handleRefreshForecast = async (rowsToUse?: TelemetryRow[]) => {
    setIsForecasting(true);
    try {
      const res = await fetch('/api/forecast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          telemetryRows: rowsToUse,
          batteryConfig,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.results) {
          setForecastData(data.results);
          if (data.metadata) setMetadata(data.metadata);
        }
      } else {
        const telemetry = rowsToUse || generateSynthetic24HourTelemetry();
        const output = await executeForecast(telemetry);
        setForecastData(output.results);
        setMetadata({
          modelUsed: output.modelUsed,
          isQuickMlLive: output.isQuickMlLive,
          forecastingMode: output.forecastingMode,
          timestamp: output.executionTimestamp,
          notes: output.notes,
        });
      }
    } catch {
      const telemetry = rowsToUse || generateSynthetic24HourTelemetry();
      const output = await executeForecast(telemetry);
      setForecastData(output.results);
      setMetadata({
        modelUsed: output.modelUsed,
        isQuickMlLive: output.isQuickMlLive,
        forecastingMode: output.forecastingMode,
        timestamp: output.executionTimestamp,
        notes: output.notes,
      });
    } finally {
      setIsForecasting(false);
    }
  };

  const handleRunForecastWithTelemetry = async (rows: TelemetryRow[]) => {
    await handleRefreshForecast(rows);
    setCurrentView('forecast');
  };

  // Operational metrics
  const currentPoint = forecastData[0] || null;
  const currentMode: GridMode = currentPoint?.grid_mode || 'Main Grid Mode';
  const criticalAlertCount = forecastData.filter(r => r.critical_overload).length;
  const batterySocPct = currentPoint?.battery_soc_pct ?? batteryConfig.initial_soc_pct;
  const batterySocKwh = currentPoint?.battery_soc_kwh ?? (batteryConfig.initial_soc_pct / 100) * batteryConfig.capacity_kwh;

  const peakDemand = forecastData.reduce(
    (max, r) => (r.predicted_demand_kw > max.demand ? { demand: r.predicted_demand_kw, time: r.timestamp } : max),
    { demand: 0, time: '' }
  );

  const hoursInRenewableStorage = forecastData.filter(r => r.grid_mode === 'Renewable Storage Mode').length;
  const hoursInMainGrid = forecastData.filter(r => r.grid_mode === 'Main Grid Mode').length;

  return (
    <div className="flex h-screen w-screen bg-[#030712] text-slate-100 overflow-hidden font-sans antialiased">
      {/* Collapsible Sidebar */}
      <Sidebar
        currentView={currentView}
        onSelectView={setCurrentView}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        criticalAlertCount={criticalAlertCount}
        isQuickMlLive={metadata.isQuickMlLive}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        {/* Top Navigation */}
        <TopNav
          currentView={currentView}
          onSelectView={setCurrentView}
          onRefreshForecast={() => handleRefreshForecast()}
          isForecasting={isForecasting}
          currentMode={currentMode}
          criticalAlertCount={criticalAlertCount}
          lastForecastTimestamp={metadata.timestamp}
          isQuickMlLive={metadata.isQuickMlLive}
        />

        {/* Viewport Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-[#030712] relative">
          <div className="max-w-7xl mx-auto">
            {currentView === 'overview' && (
              <OverviewView
                forecastData={forecastData}
                currentMode={currentMode}
                peakDemand={peakDemand.demand}
                peakTimestamp={peakDemand.time}
                hoursInRenewableStorage={hoursInRenewableStorage}
                hoursInMainGrid={hoursInMainGrid}
                criticalAlertCount={criticalAlertCount}
                batterySocPct={batterySocPct}
                batterySocKwh={batterySocKwh}
                isQuickMlLive={metadata.isQuickMlLive}
                lastForecastTimestamp={metadata.timestamp}
                modelUsed={metadata.modelUsed}
                onNavigateToUpload={() => setCurrentView('upload')}
                onNavigateToController={() => setCurrentView('controller')}
              />
            )}

            {currentView === 'forecast' && (
              <ForecastView
                forecastData={forecastData}
                modelUsed={metadata.modelUsed}
              />
            )}

            {currentView === 'controller' && <GridControllerView />}

            {currentView === 'battery' && (
              <BatteryView
                forecastData={forecastData}
                batteryConfig={batteryConfig}
              />
            )}

            {currentView === 'mllab' && <MlLabView />}

            {currentView === 'explainability' && <ExplainabilityView />}

            {currentView === 'uncertainty' && <UncertaintyView />}

            {currentView === 'peak' && <PeakIntelligenceView />}

            {currentView === 'nationalgrid' && <NationalGridView />}

            {currentView === 'upload' && (
              <UploadView
                onTelemetryLoaded={() => {}}
                onRunForecastWithTelemetry={handleRunForecastWithTelemetry}
                isForecasting={isForecasting}
              />
            )}

            {currentView === 'analytics' && <AnalyticsView />}

            {currentView === 'events' && <EventsView initialEvents={events} />}

            {currentView === 'config' && (
              <ConfigView
                batteryConfig={batteryConfig}
                onSaveBatteryConfig={setBatteryConfig}
                metadata={metadata}
              />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
