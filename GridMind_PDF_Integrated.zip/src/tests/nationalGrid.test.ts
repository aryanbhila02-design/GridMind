/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Comprehensive Unit Tests for CEA National & Regional Power Supply Position Dataset
 * Validating complete data extraction from electric Data.pdf (5 pages)
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  getNationalGridReport,
  getAllNationalGridReports,
  getForecastingSuitabilityAudit,
  exportNationalGridToCsv,
  ORDERED_REPORT_KEYS,
} from '../data/nationalGridData.ts';

// -------------------------------------------------------------
// 1. PAGE-BY-PAGE REPORT EXISTENCE & MAPPING
// -------------------------------------------------------------

test('National Grid: All 5 monthly reports are registered and ordered', () => {
  const reports = getAllNationalGridReports();
  assert.equal(reports.length, 5, 'Should have exactly 5 monthly reports');
  assert.deepEqual(ORDERED_REPORT_KEYS, ['2026-05', '2026-06', '2026-07', '2026-08', '2026-01']);
});

test('National Grid: Page 1 maps to June 2026 with 264,768 MW peak demand', () => {
  const rep = getNationalGridReport('2026-06');
  assert.equal(rep.page_number, 1);
  assert.equal(rep.reporting_month, 'June 2026');
  assert.equal(rep.cumulative_period, 'April 2026 to June 2026');
  assert.equal(rep.all_india_monthly.peak_demand_mw, 264768);
  assert.equal(rep.all_india_monthly.peak_met_mw, 264768);
  assert.equal(rep.all_india_monthly.deficit_mw, 0);
  assert.equal(rep.all_india_monthly.deficit_pct, 0);
  assert.equal(rep.all_india_cumulative.peak_demand_mw, 270832);
  assert.equal(rep.all_india_cumulative.peak_met_mw, 270820);
  assert.equal(rep.all_india_cumulative.deficit_mw, 12);
});

test('National Grid: Page 2 maps to July 2026 with 270,209 MW peak demand and carryover note', () => {
  const rep = getNationalGridReport('2026-07');
  assert.equal(rep.page_number, 2);
  assert.equal(rep.reporting_month, 'July 2026');
  assert.equal(rep.cumulative_period, 'April 2026 to July 2026');
  assert.equal(rep.all_india_monthly.peak_demand_mw, 270209);
  assert.equal(rep.all_india_monthly.peak_met_mw, 270203);
  assert.equal(rep.all_india_monthly.deficit_mw, 6);
  assert.ok(rep.footnotes.some(fn => fn.includes('Andaman & Nicobar')), 'Must contain Andaman & Nicobar carryover footnote');
});

test('National Grid: Page 3 maps to August 2026 with 258,276 MW peak demand', () => {
  const rep = getNationalGridReport('2026-08');
  assert.equal(rep.page_number, 3);
  assert.equal(rep.reporting_month, 'August 2026');
  assert.equal(rep.cumulative_period, 'April 2026 to August 2026');
  assert.equal(rep.all_india_monthly.peak_demand_mw, 258276);
  assert.equal(rep.all_india_monthly.peak_met_mw, 258270);
  assert.equal(rep.all_india_monthly.deficit_mw, 6);
});

test('National Grid: Page 4 maps to January 2026 winter report with 245,444 MW peak demand', () => {
  const rep = getNationalGridReport('2026-01');
  assert.equal(rep.page_number, 4);
  assert.equal(rep.reporting_month, 'January 2026');
  assert.equal(rep.cumulative_period, 'April 2025 to January 2026');
  assert.equal(rep.all_india_monthly.peak_demand_mw, 245444);
  assert.equal(rep.all_india_monthly.peak_met_mw, 245416);
  assert.equal(rep.all_india_monthly.deficit_mw, 28);
});

test('National Grid: Page 5 maps to May 2026 heatwave peak report with historic 270,832 MW peak demand', () => {
  const rep = getNationalGridReport('2026-05');
  assert.equal(rep.page_number, 5);
  assert.equal(rep.reporting_month, 'May 2026');
  assert.equal(rep.cumulative_period, 'April 2026 to May 2026');
  assert.equal(rep.all_india_monthly.peak_demand_mw, 270832);
  assert.equal(rep.all_india_monthly.peak_met_mw, 270820);
  assert.equal(rep.all_india_monthly.deficit_mw, 12);
});

// -------------------------------------------------------------
// 2. REGIONAL STRUCTURE & ENTITY COMPLETENESS
// -------------------------------------------------------------

test('National Grid: All 5 regions (NR, WR, SR, ER, NER) contain valid state entities', () => {
  const rep = getNationalGridReport('2026-05');
  const expectedRegions = ['NR', 'WR', 'SR', 'ER', 'NER'];
  const foundRegions = rep.regions.map(r => r.region_id);
  assert.deepEqual(foundRegions, expectedRegions);

  for (const reg of rep.regions) {
    assert.ok(reg.states.length >= 6, `${reg.region_name} should have at least 6 states/UTs`);
    assert.ok(reg.regional_peak.peak_demand_mw > 0, `${reg.region_name} peak demand should be positive`);
    assert.ok(reg.regional_peak.peak_met_mw <= reg.regional_peak.peak_demand_mw, 'Met demand cannot exceed demand');
  }
});

test('National Grid: Stand-alone systems (Lakshadweep, Andaman & Nicobar) are correctly tagged', () => {
  const rep = getNationalGridReport('2026-06');
  const sr = rep.regions.find(r => r.region_id === 'SR');
  const lak = sr?.states.find(s => s.name === 'Lakshadweep');
  assert.ok(lak, 'Lakshadweep should exist in SR');
  assert.equal(lak?.is_standalone, true, 'Lakshadweep must be flagged as stand-alone');

  const er = rep.regions.find(r => r.region_id === 'ER');
  const an = er?.states.find(s => s.name === 'Andaman & Nicobar');
  assert.ok(an, 'Andaman & Nicobar should exist in ER');
  assert.equal(an?.is_standalone, true, 'Andaman & Nicobar must be flagged as stand-alone');
});

// -------------------------------------------------------------
// 3. FORECASTING SUITABILITY AUDIT CONTRACT
// -------------------------------------------------------------

test('National Grid: Forecasting suitability audit categorizes data as Technical Reference', () => {
  const audit = getForecastingSuitabilityAudit();
  assert.equal(audit.category, 'Technical Reference Data & Macro Grid Benchmark');
  assert.equal(audit.is_suitable_for_hourly_model, false);
  assert.ok(audit.reasons.length >= 3, 'Should supply multiple explicit technical reasons');
  assert.ok(audit.recommended_usage.length >= 3, 'Should define valid architectural applications');
  assert.equal(audit.units.conversion_ratio, '1 MW = 1,000 kW');
});

// -------------------------------------------------------------
// 4. CSV EXPORT INTEGRITY
// -------------------------------------------------------------

test('National Grid: CSV Export produces valid CSV headers and records', () => {
  const csv = exportNationalGridToCsv('2026-05');
  const lines = csv.trim().split('\n');
  assert.ok(lines.length > 35, 'Should have headers plus over 35 regional and state rows');
  assert.ok(lines[0].includes('Peak_Demand_MW'), 'Header must contain Peak_Demand_MW');
  assert.ok(lines[0].includes('Deficit_Pct'), 'Header must contain Deficit_Pct');
  assert.ok(lines.some(l => l.includes('All India')), 'Must contain All India entry');
  assert.ok(lines.some(l => l.includes('Maharashtra')), 'Must contain state entries like Maharashtra');
});
