/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Comprehensive Unit Tests for HackSphere 3.0 Grid Rules, Battery, Validation, ML Lab & Persistence
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateGridTransition, extractHourFromTimestamp } from '../engine/transitionController.ts';
import { BatterySimulator } from '../engine/batterySimulator.ts';
import { validateTelemetryCsv, exportPredictionsToCsv } from '../engine/telemetryValidator.ts';
import { predictLocalDemandKw } from '../engine/forecastingEngine.ts';
import {
  savePersistedTelemetry,
  loadPersistedTelemetry,
  savePersistedSettings,
  loadPersistedSettings,
  savePersistedEvents,
  loadPersistedEvents,
  isPersistenceLayerOperational,
} from '../engine/persistenceService.ts';
import {
  trainGradientDescent,
  trainPerceptronClassifier,
  trainNeuralNetworkMLP,
  MicrogridMLPRegressor,
} from '../engine/mlLabEngine.ts';
import { computePermutationImportance } from '../engine/explainabilityEngine.ts';
import { computeConformalUncertainty } from '../engine/uncertaintyEngine.ts';
import { computePeakIntelligence } from '../engine/peakIntelligenceEngine.ts';
import { runWhatIfScenarios } from '../engine/whatIfEngine.ts';
import type { TelemetryRow, ForecastHourResult } from '../types/microgrid.ts';

// Sample synthetic training rows for unit tests
const TEST_ROWS: TelemetryRow[] = [
  { timestamp: '2026-10-27T00:00:00', ambient_temp_c: 18.5, humidity_pct: 75, solar_irradiance_wm2: 0, target_demand_kw: 88.4 },
  { timestamp: '2026-10-27T04:00:00', ambient_temp_c: 16.7, humidity_pct: 85, solar_irradiance_wm2: 0, target_demand_kw: 81.0 },
  { timestamp: '2026-10-27T08:00:00', ambient_temp_c: 21.5, humidity_pct: 69, solar_irradiance_wm2: 380, target_demand_kw: 146.8 },
  { timestamp: '2026-10-27T12:00:00', ambient_temp_c: 29.9, humidity_pct: 41, solar_irradiance_wm2: 930, target_demand_kw: 178.4 },
  { timestamp: '2026-10-27T14:00:00', ambient_temp_c: 30.2, humidity_pct: 40, solar_irradiance_wm2: 880, target_demand_kw: 176.5 },
  { timestamp: '2026-10-27T16:00:00', ambient_temp_c: 27.5, humidity_pct: 50, solar_irradiance_wm2: 530, target_demand_kw: 158.3 },
  { timestamp: '2026-10-27T18:00:00', ambient_temp_c: 23.8, humidity_pct: 64, solar_irradiance_wm2: 60, target_demand_kw: 184.2 },
  { timestamp: '2026-10-27T19:00:00', ambient_temp_c: 22.5, humidity_pct: 69, solar_irradiance_wm2: 0, target_demand_kw: 198.5 },
  { timestamp: '2026-10-27T20:00:00', ambient_temp_c: 21.4, humidity_pct: 72, solar_irradiance_wm2: 0, target_demand_kw: 206.4 },
  { timestamp: '2026-10-27T21:00:00', ambient_temp_c: 20.7, humidity_pct: 75, solar_irradiance_wm2: 0, target_demand_kw: 192.8 },
  { timestamp: '2026-10-27T22:00:00', ambient_temp_c: 20.0, humidity_pct: 77, solar_irradiance_wm2: 0, target_demand_kw: 174.1 },
  { timestamp: '2026-10-27T23:00:00', ambient_temp_c: 19.3, humidity_pct: 78, solar_irradiance_wm2: 0, target_demand_kw: 128.6 },
];

// ==========================================
// 1. GRID TRANSITION RULES TEST SUITE (PHASE 5)
// ==========================================

test('Rule: Demand <= 160 kW outside evening window (14:00) selects Main Grid Mode', () => {
  const result = evaluateGridTransition('2026-10-27T14:00:00', 145.0);
  assert.equal(result.grid_mode, 'Main Grid Mode');
  assert.equal(result.critical_overload, false);
  assert.equal(result.hour, 14);
});

test('Rule: Demand exactly 160.0 kW outside evening window selects Main Grid Mode', () => {
  const result = evaluateGridTransition('2026-10-27T12:00:00', 160.0);
  assert.equal(result.grid_mode, 'Main Grid Mode');
  assert.equal(result.critical_overload, false);
});

test('Rule: Demand > 160 kW (160.1 kW) selects Renewable Storage Mode', () => {
  const result = evaluateGridTransition('2026-10-27T12:00:00', 160.1);
  assert.equal(result.grid_mode, 'Renewable Storage Mode');
  assert.equal(result.critical_overload, false);
});

test('Rule: Hour 17:00 with demand <= 160 kW remains in Main Grid Mode', () => {
  const result = evaluateGridTransition('2026-10-27T17:00:00', 130.0);
  assert.equal(result.grid_mode, 'Main Grid Mode');
  assert.equal(result.hour, 17);
});

test('Rule: Hour 18:00 (evening peak start) triggers Renewable Storage Mode even if demand <= 160 kW', () => {
  const result = evaluateGridTransition('2026-10-27T18:00:00', 120.0);
  assert.equal(result.grid_mode, 'Renewable Storage Mode');
  assert.equal(result.hour, 18);
});

test('Rule: Hour 22:00 (evening peak end) triggers Renewable Storage Mode even if demand <= 160 kW', () => {
  const result = evaluateGridTransition('2026-10-27T22:00:00', 110.0);
  assert.equal(result.grid_mode, 'Renewable Storage Mode');
  assert.equal(result.hour, 22);
});

test('Rule: Hour 23:00 outside evening window with demand <= 160 kW returns to Main Grid Mode', () => {
  const result = evaluateGridTransition('2026-10-27T23:00:00', 95.0);
  assert.equal(result.grid_mode, 'Main Grid Mode');
  assert.equal(result.hour, 23);
});

test('Rule: Critical Overload Alert triggers when demand exactly 200.0 kW', () => {
  const result = evaluateGridTransition('2026-10-27T15:00:00', 200.0);
  assert.equal(result.critical_overload, true);
  assert.equal(result.grid_mode, 'Renewable Storage Mode'); // 200 > 160
});

test('Rule: Critical Overload Alert triggers in both modes when demand >= 200 kW', () => {
  const eveningResult = evaluateGridTransition('2026-10-27T19:00:00', 215.0);
  assert.equal(eveningResult.grid_mode, 'Renewable Storage Mode');
  assert.equal(eveningResult.critical_overload, true);

  const dayResult = evaluateGridTransition('2026-10-27T13:00:00', 220.0);
  assert.equal(dayResult.grid_mode, 'Renewable Storage Mode');
  assert.equal(dayResult.critical_overload, true);
});

test('Rule: Demand 199.9 kW does NOT trigger Critical Overload Alert', () => {
  const result = evaluateGridTransition('2026-10-27T13:00:00', 199.9);
  assert.equal(result.critical_overload, false);
});

// ==========================================
// 2. BATTERY SIMULATOR TEST SUITE
// ==========================================

test('Battery: Discharge in Renewable Storage Mode respects max discharge limit', () => {
  const sim = new BatterySimulator({
    capacity_kwh: 500,
    initial_soc_pct: 80,
    max_discharge_kw: 100,
    min_soc_pct: 15,
  });

  const step = sim.step({
    demand_kw: 180,
    solar_irradiance_wm2: 0,
    grid_mode: 'Renewable Storage Mode',
  });

  assert.equal(step.battery_power_kw, 100);
  assert.ok(step.final_soc_kwh < step.initial_soc_kwh);
  assert.equal(step.grid_import_kw, 80);
});

test('Battery: State of charge never drops below minimum reserve buffer (15%)', () => {
  const sim = new BatterySimulator({
    capacity_kwh: 100,
    initial_soc_pct: 16,
    max_discharge_kw: 50,
    min_soc_pct: 15,
  });

  const step = sim.step({
    demand_kw: 80,
    solar_irradiance_wm2: 0,
    grid_mode: 'Renewable Storage Mode',
  });

  assert.ok(sim.getCurrentSocPct() >= 15);
  assert.ok(step.final_soc_kwh >= 15);
});

// ==========================================
// 3. PERSISTENCE LAYER TEST SUITE (PHASE 6)
// ==========================================

test('Persistence: Operational check returns true and handles atomic write/read', () => {
  assert.equal(isPersistenceLayerOperational(), true);

  const testTelemetry: TelemetryRow[] = [
    { timestamp: '2026-10-27T10:00:00', ambient_temp_c: 25.0, humidity_pct: 50, solar_irradiance_wm2: 700 },
  ];
  const saveOk = savePersistedTelemetry(testTelemetry);
  assert.equal(saveOk, true);

  const loaded = loadPersistedTelemetry();
  assert.equal(loaded.length, 1);
  assert.equal(loaded[0].ambient_temp_c, 25.0);
});

test('Persistence: Settings survive save and reload', () => {
  const testSettings = {
    batteryConfig: {
      capacity_kwh: 750,
      initial_soc_pct: 70,
      max_charge_kw: 150,
      max_discharge_kw: 180,
      efficiency_pct: 94,
      min_soc_pct: 15,
      low_soc_warning_pct: 20,
    },
    lastUpdated: new Date().toISOString(),
  };

  const ok = savePersistedSettings(testSettings);
  assert.equal(ok, true);

  const reloaded = loadPersistedSettings();
  assert.ok(reloaded !== null);
  assert.equal(reloaded?.batteryConfig.capacity_kwh, 750);
  assert.equal(reloaded?.batteryConfig.max_discharge_kw, 180);
});

// ==========================================
// 4. MACHINE LEARNING RESEARCH LAB TESTS (PHASE 4 & P1)
// ==========================================

test('ML Lab: Gradient Descent trains and reduces MSE loss', () => {
  const result = trainGradientDescent(TEST_ROWS, {
    learningRate: 0.05,
    epochs: 100,
    batchSize: 4,
  });

  assert.equal(result.weights.length, 5);
  assert.ok(result.lossHistory.length > 2);
  const initialLoss = result.lossHistory[0].trainLoss;
  const finalLoss = result.lossHistory[result.lossHistory.length - 1].trainLoss;
  assert.ok(finalLoss < initialLoss, `Final loss (${finalLoss}) must be lower than initial loss (${initialLoss})`);
  assert.ok(result.trainRmse > 0);
});

test('ML Lab: Single Perceptron partitions binary high-demand class', () => {
  const result = trainPerceptronClassifier(TEST_ROWS, {
    thresholdKw: 160.0,
    epochs: 50,
    learningRate: 0.05,
  });

  assert.equal(result.weights.length, 2);
  assert.ok(result.accuracy >= 0 && result.accuracy <= 1.0);
  assert.ok(result.boundaryEquation.includes('X_norm'));
});

test('ML Lab: Multilayer Perceptron backpropagation verified with finite differences', () => {
  const mlp = new MicrogridMLPRegressor(42);
  const x = [0.5, -0.2, 1.2, 0.7, -0.7];
  const y = 1.0;

  // Finite difference gradient checking test
  const gradDiff = mlp.verifyGradientsFiniteDifference(x, y, 1e-4);
  assert.ok(gradDiff < 1e-3, `Analytical vs numerical gradient difference (${gradDiff}) must be < 1e-3`);

  const trainRes = trainNeuralNetworkMLP(TEST_ROWS, {
    learningRate: 0.01,
    epochs: 60,
    batchSize: 4,
  });
  assert.ok(trainRes.trainRmse > 0);
  assert.equal(trainRes.weightsSummary.length, 3);
});

// ==========================================
// 5. EXPLAINABILITY, UNCERTAINTY & WHAT-IF TESTS
// ==========================================

test('Explainability: Permutation Feature Importance computes valid delta RMSE rankings', () => {
  const result = computePermutationImportance(TEST_ROWS, 3);
  assert.ok(result.importances.length === 4);
  assert.ok(result.baselineRmse > 0);
  // Total relative contribution sums to ~100%
  const totalRel = result.importances.reduce((acc, curr) => acc + curr.relativeImportancePct, 0);
  assert.ok(Math.abs(totalRel - 100) < 2.0);
});

test('Uncertainty: Conformal prediction quantiles provide ordered confidence bands', () => {
  const sampleForecast: ForecastHourResult[] = TEST_ROWS.map((r, i) => ({
    timestamp: r.timestamp,
    hour: i * 2,
    ambient_temp_c: r.ambient_temp_c,
    humidity_pct: r.humidity_pct,
    solar_irradiance_wm2: r.solar_irradiance_wm2,
    predicted_demand_kw: r.target_demand_kw!,
    grid_mode: 'Main Grid Mode',
    critical_overload: false,
    decision_reason: 'Nominal',
    battery_soc_pct: 70,
    battery_soc_kwh: 350,
    battery_power_kw: 0,
    grid_import_kw: r.target_demand_kw!,
    solar_used_kw: 0,
    solar_curtailed_kw: 0,
  }));

  const unc = computeConformalUncertainty(TEST_ROWS, sampleForecast);
  assert.ok(unc.quantile80Kw <= unc.quantile90Kw);
  assert.ok(unc.quantile90Kw <= unc.quantile95Kw);
  assert.ok(unc.intervals.length === sampleForecast.length);
});

test('Peak Intelligence: Calculates peak demand and load factor accurately', () => {
  const sampleForecast: ForecastHourResult[] = TEST_ROWS.map((r, i) => ({
    timestamp: r.timestamp,
    hour: i * 2,
    ambient_temp_c: r.ambient_temp_c,
    humidity_pct: r.humidity_pct,
    solar_irradiance_wm2: r.solar_irradiance_wm2,
    predicted_demand_kw: r.target_demand_kw!,
    grid_mode: r.target_demand_kw! > 160 ? 'Renewable Storage Mode' : 'Main Grid Mode',
    critical_overload: r.target_demand_kw! >= 200,
    decision_reason: 'Test',
    battery_soc_pct: 60,
    battery_soc_kwh: 300,
    battery_power_kw: 25,
    grid_import_kw: r.target_demand_kw!,
    solar_used_kw: 0,
    solar_curtailed_kw: 0,
  }));

  const peak = computePeakIntelligence(sampleForecast);
  assert.equal(peak.peakDemandKw, 206.4);
  assert.equal(peak.hoursCriticalOverload200Kw, 1);
  assert.ok(peak.loadFactor > 0 && peak.loadFactor <= 1.0);
});

test('What-If Engine: Simulates multiple battery capacities with hypothetical flag', () => {
  const sampleForecast: ForecastHourResult[] = TEST_ROWS.map((r, i) => ({
    timestamp: r.timestamp,
    hour: i * 2,
    ambient_temp_c: r.ambient_temp_c,
    humidity_pct: r.humidity_pct,
    solar_irradiance_wm2: r.solar_irradiance_wm2,
    predicted_demand_kw: r.target_demand_kw!,
    grid_mode: 'Main Grid Mode',
    critical_overload: false,
    decision_reason: 'Test',
    battery_soc_pct: 60,
    battery_soc_kwh: 300,
    battery_power_kw: 0,
    grid_import_kw: r.target_demand_kw!,
    solar_used_kw: 0,
    solar_curtailed_kw: 0,
  }));

  const scenarios = runWhatIfScenarios(sampleForecast, [
    {
      name: 'Baseline 500 kWh',
      config: {
        capacity_kwh: 500,
        initial_soc_pct: 70,
        max_charge_kw: 100,
        max_discharge_kw: 120,
        efficiency_pct: 92,
        min_soc_pct: 15,
        low_soc_warning_pct: 20,
      },
    },
    {
      name: 'High Capacity 1000 kWh',
      config: {
        capacity_kwh: 1000,
        initial_soc_pct: 70,
        max_charge_kw: 200,
        max_discharge_kw: 250,
        efficiency_pct: 92,
        min_soc_pct: 15,
        low_soc_warning_pct: 20,
      },
    },
  ]);

  assert.equal(scenarios.length, 2);
  assert.equal(scenarios[0].isHypothetical, true);
  assert.equal(scenarios[1].isHypothetical, true);
  assert.ok(scenarios[0].batteryConfig.capacity_kwh === 500);
  assert.ok(scenarios[1].batteryConfig.capacity_kwh === 1000);
});
