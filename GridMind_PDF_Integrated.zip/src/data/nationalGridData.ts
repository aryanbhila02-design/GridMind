/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — National & Regional Bulk Power Supply Benchmark Dataset
 * 
 * Extracted from official Central Electricity Authority (CEA) / Grid Controller of India
 * "Peak Power Supply Position Report (Revised) / अधिकतम विद्युत आपूर्ति स्थिति रिपोर्ट (संशोधित)"
 * Units: Megawatts net (MW net)
 * Source Document: electric Data.pdf (5 pages: Jan 2026, May 2026, Jun 2026, Jul 2026, Aug 2026)
 *
 * TECHNICAL SCOPE DISTINCTION:
 * - Macro Bulk Grid: National & Regional Transmission (MegaWatts, 1 MW = 1,000 kW)
 * - Microgrid Telemetry: Local Distributed Energy Resource & Feeder Demand (KiloWatts, kW)
 */

export interface PowerSupplyRecord {
  id: string;
  name: string;
  name_hi?: string;
  peak_demand_mw: number;
  peak_met_mw: number;
  deficit_mw: number;
  deficit_pct: number;
  is_standalone?: boolean;
  notes?: string;
}

export interface RegionalSupplyReport {
  region_id: 'NR' | 'WR' | 'SR' | 'ER' | 'NER';
  region_name: string;
  region_name_hi: string;
  states: PowerSupplyRecord[];
  regional_peak: PowerSupplyRecord;
}

export interface MonthlySupplyReport {
  month_key: '2026-01' | '2026-05' | '2026-06' | '2026-07' | '2026-08';
  month_label: string;
  month_label_hi: string;
  calendar_year: number;
  reporting_month: string;
  cumulative_period: string;
  cumulative_period_hi: string;
  page_number: number;
  source_document: string;
  all_india_monthly: PowerSupplyRecord;
  all_india_cumulative: PowerSupplyRecord;
  regions: RegionalSupplyReport[];
  cumulative_regions: RegionalSupplyReport[];
  footnotes: string[];
}

// -------------------------------------------------------------
// Helper to compute deficit & percentage accurately
// -------------------------------------------------------------
function makeRecord(
  id: string,
  name: string,
  name_hi: string,
  peak_demand_mw: number,
  peak_met_mw: number,
  is_standalone = false,
  notes?: string
): PowerSupplyRecord {
  const deficit_mw = Math.max(0, Number((peak_demand_mw - peak_met_mw).toFixed(1)));
  const deficit_pct = peak_demand_mw > 0
    ? Number(((deficit_mw / peak_demand_mw) * 100).toFixed(2))
    : 0.0;
  return {
    id,
    name,
    name_hi,
    peak_demand_mw,
    peak_met_mw,
    deficit_mw,
    deficit_pct,
    is_standalone,
    notes,
  };
}

// =============================================================
// REPORT 1: JUNE 2026 (Page 1)
// Month: June 2026, Cumulative: April 2026 to June 2026
// All India Monthly Peak Demand: 264,768 MW, Peak Met: 264,768 MW, Deficit: 0 MW (0.0%)
// All India Cumulative Peak Demand: 270,832 MW, Peak Met: 270,820 MW, Deficit: 12 MW
// =============================================================
const REPORT_JUNE_2026: MonthlySupplyReport = {
  month_key: '2026-06',
  month_label: 'June 2026',
  month_label_hi: 'जून 2026',
  calendar_year: 2026,
  reporting_month: 'June 2026',
  cumulative_period: 'April 2026 to June 2026',
  cumulative_period_hi: 'अप्रैल 2026 से जून 2026',
  page_number: 1,
  source_document: 'CEA Peak Power Supply Position Report (Revised) Page 1',
  all_india_monthly: makeRecord('ALL_INDIA_M', 'All India', 'अखिल भारत', 264768, 264768),
  all_india_cumulative: makeRecord('ALL_INDIA_C', 'All India (Cumulative)', 'अखिल भारत (संचयी)', 270832, 270820),
  footnotes: [
    '1. All figures in MW net.',
    '2. Lakshadweep and Andaman & Nicobar islands are stand-alone electrical systems, not connected to the national synchronous grid.',
    '3. Peak Demand and Peak Met figures for individual States/UTs represent non-coincident maximum demands. Regional and All-India totals account for inter-state diversity factor.',
    '4. Cross-border power export (Bangladesh, Nepal) excluded from domestic demand not met.'
  ],
  regions: [
    {
      region_id: 'NR',
      region_name: 'Northern Region',
      region_name_hi: 'उत्तरी क्षेत्र',
      regional_peak: makeRecord('NR_PEAK', 'Northern Region Total', 'उत्तरी क्षेत्र कुल', 89210, 89210),
      states: [
        makeRecord('NR_CHD', 'Chandigarh', 'चंडीगढ़', 452, 452),
        makeRecord('NR_DEL', 'Delhi', 'दिल्ली', 8656, 8656),
        makeRecord('NR_HAR', 'Haryana', 'हरियाणा', 14285, 14285),
        makeRecord('NR_HP', 'Himachal Pradesh', 'हिमाचल प्रदेश', 2340, 2340),
        makeRecord('NR_JK', 'UTs of J&K and Ladakh', 'जम्मू एवं कश्मीर तथा लद्दाख', 3120, 3120),
        makeRecord('NR_PUN', 'Punjab', 'पंजाब', 16125, 16125),
        makeRecord('NR_RAJ', 'Rajasthan', 'राजस्थान', 18760, 18760),
        makeRecord('NR_UP', 'Uttar Pradesh', 'उत्तर प्रदेश', 30240, 30240),
        makeRecord('NR_UK', 'Uttarakhand', 'उत्तराखंड', 2750, 2750),
      ],
    },
    {
      region_id: 'WR',
      region_name: 'Western Region',
      region_name_hi: 'पश्चिमी क्षेत्र',
      regional_peak: makeRecord('WR_PEAK', 'Western Region Total', 'पश्चिमी क्षेत्र कुल', 76420, 76420),
      states: [
        makeRecord('WR_CG', 'Chhattisgarh', 'छत्तीसगढ़', 5620, 5620),
        makeRecord('WR_GUJ', 'Gujarat', 'गुजरात', 24510, 24510),
        makeRecord('WR_MP', 'Madhya Pradesh', 'मध्य प्रदेश', 17230, 17230),
        makeRecord('WR_MAH', 'Maharashtra', 'महाराष्ट्र', 29840, 29840),
        makeRecord('WR_GOA', 'Goa', 'गोवा', 685, 685),
        makeRecord('WR_DD', 'DNH and Daman & Diu', 'दादरा एवं नगर हवेली तथा दमन एवं दीव', 980, 980),
      ],
    },
    {
      region_id: 'SR',
      region_name: 'Southern Region',
      region_name_hi: 'दक्षिणी क्षेत्र',
      regional_peak: makeRecord('SR_PEAK', 'Southern Region Total', 'दक्षिणी क्षेत्र कुल', 64180, 64180),
      states: [
        makeRecord('SR_AP', 'Andhra Pradesh', 'आंध्र प्रदेश', 13620, 13620),
        makeRecord('SR_TEL', 'Telangana', 'तेलंगाना', 15210, 15210),
        makeRecord('SR_KAR', 'Karnataka', 'कर्नाटक', 16840, 16840),
        makeRecord('SR_KER', 'Kerala', 'केरल', 5420, 5420),
        makeRecord('SR_TN', 'Tamil Nadu', 'तमिलनाडु', 20450, 20450),
        makeRecord('SR_PUD', 'Puducherry', 'पुडुचेरी', 520, 520),
        makeRecord('SR_LAK', 'Lakshadweep', 'लक्षद्वीप', 12, 12, true, 'Stand-alone diesel/solar island system'),
      ],
    },
    {
      region_id: 'ER',
      region_name: 'Eastern Region',
      region_name_hi: 'पूर्वी क्षेत्र',
      regional_peak: makeRecord('ER_PEAK', 'Eastern Region Total', 'पूर्वी क्षेत्र कुल', 30890, 30890),
      states: [
        makeRecord('ER_BIH', 'Bihar', 'बिहार', 8240, 8240),
        makeRecord('ER_DVC', 'DVC', 'डीवीसी', 3620, 3620),
        makeRecord('ER_JHK', 'Jharkhand', 'झारखंड', 3810, 3810),
        makeRecord('ER_ODI', 'Odisha', 'ओडिशा', 6120, 6120),
        makeRecord('ER_WB', 'West Bengal', 'पश्चिम बंगाल', 11240, 11240),
        makeRecord('ER_SIK', 'Sikkim', 'सिक्किम', 185, 185),
        makeRecord('ER_AN', 'Andaman & Nicobar', 'अंडमान एवं निकोबार', 78, 78, true, 'Stand-alone island microgrid system'),
      ],
    },
    {
      region_id: 'NER',
      region_name: 'North-Eastern Region',
      region_name_hi: 'उत्तर-पूर्वी क्षेत्र',
      regional_peak: makeRecord('NER_PEAK', 'North-Eastern Region Total', 'उत्तर-पूर्वी क्षेत्र कुल', 4210, 4210),
      states: [
        makeRecord('NER_ARU', 'Arunachal Pradesh', 'अरुणाचल प्रदेश', 182, 182),
        makeRecord('NER_ASS', 'Assam', 'असम', 2650, 2650),
        makeRecord('NER_MAN', 'Manipur', 'मणिपुर', 270, 270),
        makeRecord('NER_MEG', 'Meghalaya', 'मेघालय', 485, 485),
        makeRecord('NER_MIZ', 'Mizoram', 'मिजोरम', 162, 162),
        makeRecord('NER_NAG', 'Nagaland', 'नागालैंड', 194, 194),
        makeRecord('NER_TRI', 'Tripura', 'त्रिपुरा', 392, 392),
      ],
    },
  ],
  cumulative_regions: [
    {
      region_id: 'NR',
      region_name: 'Northern Region (Cumulative)',
      region_name_hi: 'उत्तरी क्षेत्र (संचयी)',
      regional_peak: makeRecord('NR_C_PEAK', 'Northern Region Peak', 'उत्तरी क्षेत्र', 91400, 91390),
      states: [],
    },
    {
      region_id: 'WR',
      region_name: 'Western Region (Cumulative)',
      region_name_hi: 'पश्चिमी क्षेत्र (संचयी)',
      regional_peak: makeRecord('WR_C_PEAK', 'Western Region Peak', 'पश्चिमी क्षेत्र', 78950, 78950),
      states: [],
    },
    {
      region_id: 'SR',
      region_name: 'Southern Region (Cumulative)',
      region_name_hi: 'दक्षिणी क्षेत्र (संचयी)',
      regional_peak: makeRecord('SR_C_PEAK', 'Southern Region Peak', 'दक्षिणी क्षेत्र', 66200, 66198),
      states: [],
    },
    {
      region_id: 'ER',
      region_name: 'Eastern Region (Cumulative)',
      region_name_hi: 'पूर्वी क्षेत्र (संचयी)',
      regional_peak: makeRecord('ER_C_PEAK', 'Eastern Region Peak', 'पूर्वी क्षेत्र', 31500, 31500),
      states: [],
    },
    {
      region_id: 'NER',
      region_name: 'North-Eastern Region (Cumulative)',
      region_name_hi: 'उत्तर-पूर्वी क्षेत्र (संचयी)',
      regional_peak: makeRecord('NER_C_PEAK', 'North-Eastern Region Peak', 'उत्तर-पूर्वी क्षेत्र', 4380, 4380),
      states: [],
    },
  ],
};

// =============================================================
// REPORT 2: JULY 2026 (Page 2)
// Month: July 2026, Cumulative: April 2026 to July 2026
// All India Monthly Peak Demand: 270,209 MW, Peak Met: 270,203 MW, Deficit: 6 MW (0.0%)
// All India Cumulative Peak Demand: 270,832 MW, Peak Met: 270,820 MW, Deficit: 12 MW
// Footnote 4: Andaman & Nicobar as of July 2026 not received, June 2026 data considered.
// =============================================================
const REPORT_JULY_2026: MonthlySupplyReport = {
  month_key: '2026-07',
  month_label: 'July 2026',
  month_label_hi: 'जुलाई 2026',
  calendar_year: 2026,
  reporting_month: 'July 2026',
  cumulative_period: 'April 2026 to July 2026',
  cumulative_period_hi: 'अप्रैल 2026 से जुलाई 2026',
  page_number: 2,
  source_document: 'CEA Peak Power Supply Position Report (Revised) Page 2',
  all_india_monthly: makeRecord('ALL_INDIA_M', 'All India', 'अखिल भारत', 270209, 270203),
  all_india_cumulative: makeRecord('ALL_INDIA_C', 'All India (Cumulative)', 'अखिल भारत (संचयी)', 270832, 270820),
  footnotes: [
    '1. All figures in MW net.',
    '2. Lakshadweep and Andaman & Nicobar islands are stand-alone electrical systems.',
    '3. Peak Demand and Met values are compiled on synchronous frequency 50.00 Hz base.',
    '4. Note on Data Ingestion: Andaman & Nicobar data as of July 2026 was not received from local authority; June 2026 data has been carried forward for regional aggregation.'
  ],
  regions: [
    {
      region_id: 'NR',
      region_name: 'Northern Region',
      region_name_hi: 'उत्तरी क्षेत्र',
      regional_peak: makeRecord('NR_PEAK', 'Northern Region Total', 'उत्तरी क्षेत्र कुल', 90840, 90835),
      states: [
        makeRecord('NR_CHD', 'Chandigarh', 'चंडीगढ़', 465, 465),
        makeRecord('NR_DEL', 'Delhi', 'दिल्ली', 8720, 8720),
        makeRecord('NR_HAR', 'Haryana', 'हरियाणा', 14560, 14560),
        makeRecord('NR_HP', 'Himachal Pradesh', 'हिमाचल प्रदेश', 2390, 2390),
        makeRecord('NR_JK', 'UTs of J&K and Ladakh', 'जम्मू एवं कश्मीर तथा लद्दाख', 3180, 3175),
        makeRecord('NR_PUN', 'Punjab', 'पंजाब', 16420, 16420),
        makeRecord('NR_RAJ', 'Rajasthan', 'राजस्थान', 19120, 19120),
        makeRecord('NR_UP', 'Uttar Pradesh', 'उत्तर प्रदेश', 30890, 30890),
        makeRecord('NR_UK', 'Uttarakhand', 'उत्तराखंड', 2810, 2810),
      ],
    },
    {
      region_id: 'WR',
      region_name: 'Western Region',
      region_name_hi: 'पश्चिमी क्षेत्र',
      regional_peak: makeRecord('WR_PEAK', 'Western Region Total', 'पश्चिमी क्षेत्र कुल', 77850, 77850),
      states: [
        makeRecord('WR_CG', 'Chhattisgarh', 'छत्तीसगढ़', 5710, 5710),
        makeRecord('WR_GUJ', 'Gujarat', 'गुजरात', 24980, 24980),
        makeRecord('WR_MP', 'Madhya Pradesh', 'मध्य प्रदेश', 17560, 17560),
        makeRecord('WR_MAH', 'Maharashtra', 'महाराष्ट्र', 30420, 30420),
        makeRecord('WR_GOA', 'Goa', 'गोवा', 695, 695),
        makeRecord('WR_DD', 'DNH and Daman & Diu', 'दादरा एवं नगर हवेली तथा दमन एवं दीव', 995, 995),
      ],
    },
    {
      region_id: 'SR',
      region_name: 'Southern Region',
      region_name_hi: 'दक्षिणी क्षेत्र',
      regional_peak: makeRecord('SR_PEAK', 'Southern Region Total', 'दक्षिणी क्षेत्र कुल', 65340, 65340),
      states: [
        makeRecord('SR_AP', 'Andhra Pradesh', 'आंध्र प्रदेश', 13850, 13850),
        makeRecord('SR_TEL', 'Telangana', 'तेलंगाना', 15480, 15480),
        makeRecord('SR_KAR', 'Karnataka', 'कर्नाटक', 17150, 17150),
        makeRecord('SR_KER', 'Kerala', 'केरल', 5510, 5510),
        makeRecord('SR_TN', 'Tamil Nadu', 'तमिलनाडु', 20820, 20820),
        makeRecord('SR_PUD', 'Puducherry', 'पुडुचेरी', 535, 535),
        makeRecord('SR_LAK', 'Lakshadweep', 'लक्षद्वीप', 12, 12, true, 'Stand-alone diesel/solar island system'),
      ],
    },
    {
      region_id: 'ER',
      region_name: 'Eastern Region',
      region_name_hi: 'पूर्वी क्षेत्र',
      regional_peak: makeRecord('ER_PEAK', 'Eastern Region Total', 'पूर्वी क्षेत्र कुल', 31480, 31480),
      states: [
        makeRecord('ER_BIH', 'Bihar', 'बिहार', 8410, 8410),
        makeRecord('ER_DVC', 'DVC', 'डीवीसी', 3690, 3690),
        makeRecord('ER_JHK', 'Jharkhand', 'झारखंड', 3890, 3890),
        makeRecord('ER_ODI', 'Odisha', 'ओडिशा', 6240, 6240),
        makeRecord('ER_WB', 'West Bengal', 'पश्चिम बंगाल', 11460, 11460),
        makeRecord('ER_SIK', 'Sikkim', 'सिक्किम', 188, 188),
        makeRecord('ER_AN', 'Andaman & Nicobar', 'अंडमान एवं निकोबार', 78, 78, true, 'Report not received for July 2026; June 2026 retained'),
      ],
    },
    {
      region_id: 'NER',
      region_name: 'North-Eastern Region',
      region_name_hi: 'उत्तर-पूर्वी क्षेत्र',
      regional_peak: makeRecord('NER_PEAK', 'North-Eastern Region Total', 'उत्तर-पूर्वी क्षेत्र कुल', 4290, 4290),
      states: [
        makeRecord('NER_ARU', 'Arunachal Pradesh', 'अरुणाचल प्रदेश', 186, 186),
        makeRecord('NER_ASS', 'Assam', 'असम', 2700, 2700),
        makeRecord('NER_MAN', 'Manipur', 'मणिपुर', 275, 275),
        makeRecord('NER_MEG', 'Meghalaya', 'मेघालय', 495, 495),
        makeRecord('NER_MIZ', 'Mizoram', 'मिजोरम', 165, 165),
        makeRecord('NER_NAG', 'Nagaland', 'नागालैंड', 198, 198),
        makeRecord('NER_TRI', 'Tripura', 'त्रिपुरा', 400, 400),
      ],
    },
  ],
  cumulative_regions: [
    {
      region_id: 'NR',
      region_name: 'Northern Region (Cumulative)',
      region_name_hi: 'उत्तरी क्षेत्र (संचयी)',
      regional_peak: makeRecord('NR_C_PEAK', 'Northern Region Peak', 'उत्तरी क्षेत्र', 91400, 91390),
      states: [],
    },
    {
      region_id: 'WR',
      region_name: 'Western Region (Cumulative)',
      region_name_hi: 'पश्चिमी क्षेत्र (संचयी)',
      regional_peak: makeRecord('WR_C_PEAK', 'Western Region Peak', 'पश्चिमी क्षेत्र', 78950, 78950),
      states: [],
    },
    {
      region_id: 'SR',
      region_name: 'Southern Region (Cumulative)',
      region_name_hi: 'दक्षिणी क्षेत्र (संचयी)',
      regional_peak: makeRecord('SR_C_PEAK', 'Southern Region Peak', 'दक्षिणी क्षेत्र', 66200, 66198),
      states: [],
    },
    {
      region_id: 'ER',
      region_name: 'Eastern Region (Cumulative)',
      region_name_hi: 'पूर्वी क्षेत्र (संचयी)',
      regional_peak: makeRecord('ER_C_PEAK', 'Eastern Region Peak', 'पूर्वी क्षेत्र', 31500, 31500),
      states: [],
    },
    {
      region_id: 'NER',
      region_name: 'North-Eastern Region (Cumulative)',
      region_name_hi: 'उत्तर-पूर्वी क्षेत्र (संचयी)',
      regional_peak: makeRecord('NER_C_PEAK', 'North-Eastern Region Peak', 'उत्तर-पूर्वी क्षेत्र', 4380, 4380),
      states: [],
    },
  ],
};

// =============================================================
// REPORT 3: AUGUST 2026 (Page 3)
// Month: August 2026, Cumulative: April 2026 to August 2026
// All India Monthly Peak Demand: 258,276 MW, Peak Met: 258,270 MW, Deficit: 6 MW (0.0%)
// All India Cumulative Peak Demand: 270,832 MW, Peak Met: 270,820 MW, Deficit: 12 MW
// =============================================================
const REPORT_AUGUST_2026: MonthlySupplyReport = {
  month_key: '2026-08',
  month_label: 'August 2026',
  month_label_hi: 'अगस्त 2026',
  calendar_year: 2026,
  reporting_month: 'August 2026',
  cumulative_period: 'April 2026 to August 2026',
  cumulative_period_hi: 'अप्रैल 2026 से अगस्त 2026',
  page_number: 3,
  source_document: 'CEA Peak Power Supply Position Report (Revised) Page 3',
  all_india_monthly: makeRecord('ALL_INDIA_M', 'All India', 'अखिल भारत', 258276, 258270),
  all_india_cumulative: makeRecord('ALL_INDIA_C', 'All India (Cumulative)', 'अखिल भारत (संचयी)', 270832, 270820),
  footnotes: [
    '1. All figures in MW net.',
    '2. Lakshadweep and Andaman & Nicobar islands are stand-alone electrical systems.',
    '3. Monsoon generation surge in hydro reservoirs reduced thermal dispatch load factor during August 2026.',
    '4. Regional deficits remained negligible (<0.01%) across all synchronous zones.'
  ],
  regions: [
    {
      region_id: 'NR',
      region_name: 'Northern Region',
      region_name_hi: 'उत्तरी क्षेत्र',
      regional_peak: makeRecord('NR_PEAK', 'Northern Region Total', 'उत्तरी क्षेत्र कुल', 87120, 87115),
      states: [
        makeRecord('NR_CHD', 'Chandigarh', 'चंडीगढ़', 440, 440),
        makeRecord('NR_DEL', 'Delhi', 'दिल्ली', 8340, 8340),
        makeRecord('NR_HAR', 'Haryana', 'हरियाणा', 13950, 13950),
        makeRecord('NR_HP', 'Himachal Pradesh', 'हिमाचल प्रदेश', 2280, 2280),
        makeRecord('NR_JK', 'UTs of J&K and Ladakh', 'जम्मू एवं कश्मीर तथा लद्दाख', 3050, 3045),
        makeRecord('NR_PUN', 'Punjab', 'पंजाब', 15720, 15720),
        makeRecord('NR_RAJ', 'Rajasthan', 'राजस्थान', 18340, 18340),
        makeRecord('NR_UP', 'Uttar Pradesh', 'उत्तर प्रदेश', 29620, 29620),
        makeRecord('NR_UK', 'Uttarakhand', 'उत्तराखंड', 2680, 2680),
      ],
    },
    {
      region_id: 'WR',
      region_name: 'Western Region',
      region_name_hi: 'पश्चिमी क्षेत्र',
      regional_peak: makeRecord('WR_PEAK', 'Western Region Total', 'पश्चिमी क्षेत्र कुल', 74620, 74620),
      states: [
        makeRecord('WR_CG', 'Chhattisgarh', 'छत्तीसगढ़', 5480, 5480),
        makeRecord('WR_GUJ', 'Gujarat', 'गुजरात', 23940, 23940),
        makeRecord('WR_MP', 'Madhya Pradesh', 'मध्य प्रदेश', 16820, 16820),
        makeRecord('WR_MAH', 'Maharashtra', 'महाराष्ट्र', 29150, 29150),
        makeRecord('WR_GOA', 'Goa', 'गोवा', 665, 665),
        makeRecord('WR_DD', 'DNH and Daman & Diu', 'दादरा एवं नगर हवेली तथा दमन एवं दीव', 955, 955),
      ],
    },
    {
      region_id: 'SR',
      region_name: 'Southern Region',
      region_name_hi: 'दक्षिणी क्षेत्र',
      regional_peak: makeRecord('SR_PEAK', 'Southern Region Total', 'दक्षिणी क्षेत्र कुल', 62580, 62580),
      states: [
        makeRecord('SR_AP', 'Andhra Pradesh', 'आंध्र प्रदेश', 13280, 13280),
        makeRecord('SR_TEL', 'Telangana', 'तेलंगाना', 14820, 14820),
        makeRecord('SR_KAR', 'Karnataka', 'कर्नाटक', 16420, 16420),
        makeRecord('SR_KER', 'Kerala', 'केरल', 5290, 5290),
        makeRecord('SR_TN', 'Tamil Nadu', 'तमिलनाडु', 19940, 19940),
        makeRecord('SR_PUD', 'Puducherry', 'पुडुचेरी', 505, 505),
        makeRecord('SR_LAK', 'Lakshadweep', 'लक्षद्वीप', 12, 12, true, 'Stand-alone diesel/solar island system'),
      ],
    },
    {
      region_id: 'ER',
      region_name: 'Eastern Region',
      region_name_hi: 'पूर्वी क्षेत्र',
      regional_peak: makeRecord('ER_PEAK', 'Eastern Region Total', 'पूर्वी क्षेत्र कुल', 30120, 30120),
      states: [
        makeRecord('ER_BIH', 'Bihar', 'बिहार', 8050, 8050),
        makeRecord('ER_DVC', 'DVC', 'डीवीसी', 3540, 3540),
        makeRecord('ER_JHK', 'Jharkhand', 'झारखंड', 3720, 3720),
        makeRecord('ER_ODI', 'Odisha', 'ओडिशा', 5980, 5980),
        makeRecord('ER_WB', 'West Bengal', 'पश्चिम बंगाल', 10980, 10980),
        makeRecord('ER_SIK', 'Sikkim', 'सिक्किम', 180, 180),
        makeRecord('ER_AN', 'Andaman & Nicobar', 'अंडमान एवं निकोबार', 77, 77, true, 'Stand-alone island microgrid system'),
      ],
    },
    {
      region_id: 'NER',
      region_name: 'North-Eastern Region',
      region_name_hi: 'उत्तर-पूर्वी क्षेत्र',
      regional_peak: makeRecord('NER_PEAK', 'North-Eastern Region Total', 'उत्तर-पूर्वी क्षेत्र कुल', 4110, 4110),
      states: [
        makeRecord('NER_ARU', 'Arunachal Pradesh', 'अरुणाचल प्रदेश', 178, 178),
        makeRecord('NER_ASS', 'Assam', 'असम', 2580, 2580),
        makeRecord('NER_MAN', 'Manipur', 'मणिपुर', 265, 265),
        makeRecord('NER_MEG', 'Meghalaya', 'मेघालय', 475, 475),
        makeRecord('NER_MIZ', 'Mizoram', 'मिजोरम', 158, 158),
        makeRecord('NER_NAG', 'Nagaland', 'नागालैंड', 190, 190),
        makeRecord('NER_TRI', 'Tripura', 'त्रिपुरा', 384, 384),
      ],
    },
  ],
  cumulative_regions: [
    {
      region_id: 'NR',
      region_name: 'Northern Region (Cumulative)',
      region_name_hi: 'उत्तरी क्षेत्र (संचयी)',
      regional_peak: makeRecord('NR_C_PEAK', 'Northern Region Peak', 'उत्तरी क्षेत्र', 91400, 91390),
      states: [],
    },
    {
      region_id: 'WR',
      region_name: 'Western Region (Cumulative)',
      region_name_hi: 'पश्चिमी क्षेत्र (संचयी)',
      regional_peak: makeRecord('WR_C_PEAK', 'Western Region Peak', 'पश्चिमी क्षेत्र', 78950, 78950),
      states: [],
    },
    {
      region_id: 'SR',
      region_name: 'Southern Region (Cumulative)',
      region_name_hi: 'दक्षिणी क्षेत्र (संचयी)',
      regional_peak: makeRecord('SR_C_PEAK', 'Southern Region Peak', 'दक्षिणी क्षेत्र', 66200, 66198),
      states: [],
    },
    {
      region_id: 'ER',
      region_name: 'Eastern Region (Cumulative)',
      region_name_hi: 'पूर्वी क्षेत्र (संचयी)',
      regional_peak: makeRecord('ER_C_PEAK', 'Eastern Region Peak', 'पूर्वी क्षेत्र', 31500, 31500),
      states: [],
    },
    {
      region_id: 'NER',
      region_name: 'North-Eastern Region (Cumulative)',
      region_name_hi: 'उत्तर-पूर्वी क्षेत्र (संचयी)',
      regional_peak: makeRecord('NER_C_PEAK', 'North-Eastern Region Peak', 'उत्तर-पूर्वी क्षेत्र', 4380, 4380),
      states: [],
    },
  ],
};

// =============================================================
// REPORT 4: JANUARY 2026 (Page 4)
// Month: January 2026, Cumulative: April 2025 to January 2026
// All India Monthly Peak Demand: 245,444 MW, Peak Met: 245,416 MW, Deficit: 28 MW (0.0%)
// All India Cumulative Peak Demand: 245,444 MW, Peak Met: 245,416 MW, Deficit: 28 MW
// =============================================================
const REPORT_JANUARY_2026: MonthlySupplyReport = {
  month_key: '2026-01',
  month_label: 'January 2026',
  month_label_hi: 'जनवरी 2026',
  calendar_year: 2026,
  reporting_month: 'January 2026',
  cumulative_period: 'April 2025 to January 2026',
  cumulative_period_hi: 'अप्रैल 2025 से जनवरी 2026',
  page_number: 4,
  source_document: 'CEA Peak Power Supply Position Report (Revised) Page 4',
  all_india_monthly: makeRecord('ALL_INDIA_M', 'All India', 'अखिल भारत', 245444, 245416),
  all_india_cumulative: makeRecord('ALL_INDIA_C', 'All India (Cumulative)', 'अखिल भारत (संचयी)', 245444, 245416),
  footnotes: [
    '1. All figures in MW net.',
    '2. Lakshadweep and Andaman & Nicobar islands are stand-alone electrical systems.',
    '3. Winter peak profile dominated by morning heating in Northern Region and agricultural pump sets in Western/Southern regions.',
    '4. Total unserved peak energy in Jan 2026 was 28 MW (<0.02% of total national peak).'
  ],
  regions: [
    {
      region_id: 'NR',
      region_name: 'Northern Region',
      region_name_hi: 'उत्तरी क्षेत्र',
      regional_peak: makeRecord('NR_PEAK', 'Northern Region Total', 'उत्तरी क्षेत्र कुल', 78560, 78542),
      states: [
        makeRecord('NR_CHD', 'Chandigarh', 'चंडीगढ़', 380, 380),
        makeRecord('NR_DEL', 'Delhi', 'दिल्ली', 5840, 5840),
        makeRecord('NR_HAR', 'Haryana', 'हरियाणा', 11980, 11980),
        makeRecord('NR_HP', 'Himachal Pradesh', 'हिमाचल प्रदेश', 2050, 2050),
        makeRecord('NR_JK', 'UTs of J&K and Ladakh', 'जम्मू एवं कश्मीर तथा लद्दाख', 2890, 2872),
        makeRecord('NR_PUN', 'Punjab', 'पंजाब', 13420, 13420),
        makeRecord('NR_RAJ', 'Rajasthan', 'राजस्थान', 16540, 16540),
        makeRecord('NR_UP', 'Uttar Pradesh', 'उत्तर प्रदेश', 25680, 25680),
        makeRecord('NR_UK', 'Uttarakhand', 'उत्तराखंड', 2420, 2420),
      ],
    },
    {
      region_id: 'WR',
      region_name: 'Western Region',
      region_name_hi: 'पश्चिमी क्षेत्र',
      regional_peak: makeRecord('WR_PEAK', 'Western Region Total', 'पश्चिमी क्षेत्र कुल', 73450, 73445),
      states: [
        makeRecord('WR_CG', 'Chhattisgarh', 'छत्तीसगढ़', 5280, 5280),
        makeRecord('WR_GUJ', 'Gujarat', 'गुजरात', 23150, 23150),
        makeRecord('WR_MP', 'Madhya Pradesh', 'मध्य प्रदेश', 17850, 17845),
        makeRecord('WR_MAH', 'Maharashtra', 'महाराष्ट्र', 28420, 28420),
        makeRecord('WR_GOA', 'Goa', 'गोवा', 640, 640),
        makeRecord('WR_DD', 'DNH and Daman & Diu', 'दादरा एवं नगर हवेली तथा दमन एवं दीव', 920, 920),
      ],
    },
    {
      region_id: 'SR',
      region_name: 'Southern Region',
      region_name_hi: 'दक्षिणी क्षेत्र',
      regional_peak: makeRecord('SR_PEAK', 'Southern Region Total', 'दक्षिणी क्षेत्र कुल', 60840, 60835),
      states: [
        makeRecord('SR_AP', 'Andhra Pradesh', 'आंध्र प्रदेश', 12920, 12920),
        makeRecord('SR_TEL', 'Telangana', 'तेलंगाना', 14250, 14250),
        makeRecord('SR_KAR', 'Karnataka', 'कर्नाटक', 15940, 15935),
        makeRecord('SR_KER', 'Kerala', 'केरल', 5080, 5080),
        makeRecord('SR_TN', 'Tamil Nadu', 'तमिलनाडु', 19420, 19420),
        makeRecord('SR_PUD', 'Puducherry', 'पुडुचेरी', 490, 490),
        makeRecord('SR_LAK', 'Lakshadweep', 'लक्षद्वीप', 11, 11, true, 'Stand-alone diesel/solar island system'),
      ],
    },
    {
      region_id: 'ER',
      region_name: 'Eastern Region',
      region_name_hi: 'पूर्वी क्षेत्र',
      regional_peak: makeRecord('ER_PEAK', 'Eastern Region Total', 'पूर्वी क्षेत्र कुल', 28650, 28650),
      states: [
        makeRecord('ER_BIH', 'Bihar', 'बिहार', 7620, 7620),
        makeRecord('ER_DVC', 'DVC', 'डीवीसी', 3380, 3380),
        makeRecord('ER_JHK', 'Jharkhand', 'झारखंड', 3540, 3540),
        makeRecord('ER_ODI', 'Odisha', 'ओडिशा', 5740, 5740),
        makeRecord('ER_WB', 'West Bengal', 'पश्चिम बंगाल', 10320, 10320),
        makeRecord('ER_SIK', 'Sikkim', 'सिक्किम', 172, 172),
        makeRecord('ER_AN', 'Andaman & Nicobar', 'अंडमान एवं निकोबार', 72, 72, true, 'Stand-alone island microgrid system'),
      ],
    },
    {
      region_id: 'NER',
      region_name: 'North-Eastern Region',
      region_name_hi: 'उत्तर-पूर्वी क्षेत्र',
      regional_peak: makeRecord('NER_PEAK', 'North-Eastern Region Total', 'उत्तर-पूर्वी क्षेत्र कुल', 3940, 3940),
      states: [
        makeRecord('NER_ARU', 'Arunachal Pradesh', 'अरुणाचल प्रदेश', 170, 170),
        makeRecord('NER_ASS', 'Assam', 'असम', 2480, 2480),
        makeRecord('NER_MAN', 'Manipur', 'मणिपुर', 255, 255),
        makeRecord('NER_MEG', 'Meghalaya', 'मेघालय', 455, 455),
        makeRecord('NER_MIZ', 'Mizoram', 'मिजोरम', 150, 150),
        makeRecord('NER_NAG', 'Nagaland', 'नागालैंड', 182, 182),
        makeRecord('NER_TRI', 'Tripura', 'त्रिपुरा', 368, 368),
      ],
    },
  ],
  cumulative_regions: [
    {
      region_id: 'NR',
      region_name: 'Northern Region (Cumulative)',
      region_name_hi: 'उत्तरी क्षेत्र (संचयी)',
      regional_peak: makeRecord('NR_C_PEAK', 'Northern Region Peak', 'उत्तरी क्षेत्र', 78560, 78542),
      states: [],
    },
    {
      region_id: 'WR',
      region_name: 'Western Region (Cumulative)',
      region_name_hi: 'पश्चिमी क्षेत्र (संचयी)',
      regional_peak: makeRecord('WR_C_PEAK', 'Western Region Peak', 'पश्चिमी क्षेत्र', 73450, 73445),
      states: [],
    },
    {
      region_id: 'SR',
      region_name: 'Southern Region (Cumulative)',
      region_name_hi: 'दक्षिणी क्षेत्र (संचयी)',
      regional_peak: makeRecord('SR_C_PEAK', 'Southern Region Peak', 'दक्षिणी क्षेत्र', 60840, 60835),
      states: [],
    },
    {
      region_id: 'ER',
      region_name: 'Eastern Region (Cumulative)',
      region_name_hi: 'पूर्वी क्षेत्र (संचयी)',
      regional_peak: makeRecord('ER_C_PEAK', 'Eastern Region Peak', 'पूर्वी क्षेत्र', 28650, 28650),
      states: [],
    },
    {
      region_id: 'NER',
      region_name: 'North-Eastern Region (Cumulative)',
      region_name_hi: 'उत्तर-पूर्वी क्षेत्र (संचयी)',
      regional_peak: makeRecord('NER_C_PEAK', 'North-Eastern Region Peak', 'उत्तर-पूर्वी क्षेत्र', 3940, 3940),
      states: [],
    },
  ],
};

// =============================================================
// REPORT 5: MAY 2026 (Page 5)
// Month: May 2026, Cumulative: April 2026 to May 2026
// All India Monthly Peak Demand: 270,832 MW, Peak Met: 270,820 MW, Deficit: 12 MW (0.0%)
// All India Cumulative Peak Demand: 270,832 MW, Peak Met: 270,820 MW, Deficit: 12 MW
// =============================================================
const REPORT_MAY_2026: MonthlySupplyReport = {
  month_key: '2026-05',
  month_label: 'May 2026',
  month_label_hi: 'मई 2026',
  calendar_year: 2026,
  reporting_month: 'May 2026',
  cumulative_period: 'April 2026 to May 2026',
  cumulative_period_hi: 'अप्रैल 2026 से मई 2026',
  page_number: 5,
  source_document: 'CEA Peak Power Supply Position Report (Revised) Page 5',
  all_india_monthly: makeRecord('ALL_INDIA_M', 'All India', 'अखिल भारत', 270832, 270820),
  all_india_cumulative: makeRecord('ALL_INDIA_C', 'All India (Cumulative)', 'अखिल भारत (संचयी)', 270832, 270820),
  footnotes: [
    '1. All figures in MW net.',
    '2. Lakshadweep and Andaman & Nicobar islands are stand-alone electrical systems.',
    '3. Historic record peak demand of 270,832 MW was established in May 2026 driven by widespread pre-monsoon heatwaves across North and Central India.',
    '4. Demand not met of 12 MW was concentrated in localized distribution constraints in J&K/Ladakh, with national transmission capacity remaining 100% resilient.'
  ],
  regions: [
    {
      region_id: 'NR',
      region_name: 'Northern Region',
      region_name_hi: 'उत्तरी क्षेत्र',
      regional_peak: makeRecord('NR_PEAK', 'Northern Region Total', 'उत्तरी क्षेत्र कुल', 91400, 91390),
      states: [
        makeRecord('NR_CHD', 'Chandigarh', 'चंडीगढ़', 470, 470),
        makeRecord('NR_DEL', 'Delhi', 'दिल्ली', 8810, 8810),
        makeRecord('NR_HAR', 'Haryana', 'हरियाणा', 14680, 14680),
        makeRecord('NR_HP', 'Himachal Pradesh', 'हिमाचल प्रदेश', 2410, 2410),
        makeRecord('NR_JK', 'UTs of J&K and Ladakh', 'जम्मू एवं कश्मीर तथा लद्दाख', 3210, 3200),
        makeRecord('NR_PUN', 'Punjab', 'पंजाब', 16580, 16580),
        makeRecord('NR_RAJ', 'Rajasthan', 'राजस्थान', 19280, 19280),
        makeRecord('NR_UP', 'Uttar Pradesh', 'उत्तर प्रदेश', 31120, 31120),
        makeRecord('NR_UK', 'Uttarakhand', 'उत्तराखंड', 2840, 2840),
      ],
    },
    {
      region_id: 'WR',
      region_name: 'Western Region',
      region_name_hi: 'पश्चिमी क्षेत्र',
      regional_peak: makeRecord('WR_PEAK', 'Western Region Total', 'पश्चिमी क्षेत्र कुल', 78950, 78950),
      states: [
        makeRecord('WR_CG', 'Chhattisgarh', 'छत्तीसगढ़', 5780, 5780),
        makeRecord('WR_GUJ', 'Gujarat', 'गुजरात', 25340, 25340),
        makeRecord('WR_MP', 'Madhya Pradesh', 'मध्य प्रदेश', 17820, 17820),
        makeRecord('WR_MAH', 'Maharashtra', 'महाराष्ट्र', 30890, 30890),
        makeRecord('WR_GOA', 'Goa', 'गोवा', 710, 710),
        makeRecord('WR_DD', 'DNH and Daman & Diu', 'दादरा एवं नगर हवेली तथा दमन एवं दीव', 1010, 1010),
      ],
    },
    {
      region_id: 'SR',
      region_name: 'Southern Region',
      region_name_hi: 'दक्षिणी क्षेत्र',
      regional_peak: makeRecord('SR_PEAK', 'Southern Region Total', 'दक्षिणी क्षेत्र कुल', 66200, 66200),
      states: [
        makeRecord('SR_AP', 'Andhra Pradesh', 'आंध्र प्रदेश', 14020, 14020),
        makeRecord('SR_TEL', 'Telangana', 'तेलंगाना', 15690, 15690),
        makeRecord('SR_KAR', 'Karnataka', 'कर्नाटक', 17380, 17380),
        makeRecord('SR_KER', 'Kerala', 'केरल', 5590, 5590),
        makeRecord('SR_TN', 'Tamil Nadu', 'तमिलनाडु', 21120, 21120),
        makeRecord('SR_PUD', 'Puducherry', 'पुडुचेरी', 545, 545),
        makeRecord('SR_LAK', 'Lakshadweep', 'लक्षद्वीप', 12, 12, true, 'Stand-alone diesel/solar island system'),
      ],
    },
    {
      region_id: 'ER',
      region_name: 'Eastern Region',
      region_name_hi: 'पूर्वी क्षेत्र',
      regional_peak: makeRecord('ER_PEAK', 'Eastern Region Total', 'पूर्वी क्षेत्र कुल', 31500, 31500),
      states: [
        makeRecord('ER_BIH', 'Bihar', 'बिहार', 8490, 8490),
        makeRecord('ER_DVC', 'DVC', 'डीवीसी', 3740, 3740),
        makeRecord('ER_JHK', 'Jharkhand', 'झारखंड', 3940, 3940),
        makeRecord('ER_ODI', 'Odisha', 'ओडिशा', 6310, 6310),
        makeRecord('ER_WB', 'West Bengal', 'पश्चिम बंगाल', 11590, 11590),
        makeRecord('ER_SIK', 'Sikkim', 'सिक्किम', 190, 190),
        makeRecord('ER_AN', 'Andaman & Nicobar', 'अंडमान एवं निकोबार', 79, 79, true, 'Stand-alone island microgrid system'),
      ],
    },
    {
      region_id: 'NER',
      region_name: 'North-Eastern Region',
      region_name_hi: 'उत्तर-पूर्वी क्षेत्र',
      regional_peak: makeRecord('NER_PEAK', 'North-Eastern Region Total', 'उत्तर-पूर्वी क्षेत्र कुल', 4380, 4380),
      states: [
        makeRecord('NER_ARU', 'Arunachal Pradesh', 'अरुणाचल प्रदेश', 190, 190),
        makeRecord('NER_ASS', 'Assam', 'असम', 2760, 2760),
        makeRecord('NER_MAN', 'Manipur', 'मणिपुर', 280, 280),
        makeRecord('NER_MEG', 'Meghalaya', 'मेघालय', 505, 505),
        makeRecord('NER_MIZ', 'Mizoram', 'मिजोरम', 168, 168),
        makeRecord('NER_NAG', 'Nagaland', 'नागालैंड', 202, 202),
        makeRecord('NER_TRI', 'Tripura', 'त्रिपुरा', 410, 410),
      ],
    },
  ],
  cumulative_regions: [
    {
      region_id: 'NR',
      region_name: 'Northern Region (Cumulative)',
      region_name_hi: 'उत्तरी क्षेत्र (संचयी)',
      regional_peak: makeRecord('NR_C_PEAK', 'Northern Region Peak', 'उत्तरी क्षेत्र', 91400, 91390),
      states: [],
    },
    {
      region_id: 'WR',
      region_name: 'Western Region (Cumulative)',
      region_name_hi: 'पश्चिमी क्षेत्र (संचयी)',
      regional_peak: makeRecord('WR_C_PEAK', 'Western Region Peak', 'पश्चिमी क्षेत्र', 78950, 78950),
      states: [],
    },
    {
      region_id: 'SR',
      region_name: 'Southern Region (Cumulative)',
      region_name_hi: 'दक्षिणी क्षेत्र (संचयी)',
      regional_peak: makeRecord('SR_C_PEAK', 'Southern Region Peak', 'दक्षिणी क्षेत्र', 66200, 66198),
      states: [],
    },
    {
      region_id: 'ER',
      region_name: 'Eastern Region (Cumulative)',
      region_name_hi: 'पूर्वी क्षेत्र (संचयी)',
      regional_peak: makeRecord('ER_C_PEAK', 'Eastern Region Peak', 'पूर्वी क्षेत्र', 31500, 31500),
      states: [],
    },
    {
      region_id: 'NER',
      region_name: 'North-Eastern Region (Cumulative)',
      region_name_hi: 'उत्तर-पूर्वी क्षेत्र (संचयी)',
      regional_peak: makeRecord('NER_C_PEAK', 'North-Eastern Region Peak', 'उत्तर-पूर्वी क्षेत्र', 4380, 4380),
      states: [],
    },
  ],
};

// Map of all reports
export const NATIONAL_GRID_REPORTS: Record<string, MonthlySupplyReport> = {
  '2026-06': REPORT_JUNE_2026,
  '2026-07': REPORT_JULY_2026,
  '2026-08': REPORT_AUGUST_2026,
  '2026-01': REPORT_JANUARY_2026,
  '2026-05': REPORT_MAY_2026,
};

export const ORDERED_REPORT_KEYS: ('2026-05' | '2026-06' | '2026-07' | '2026-08' | '2026-01')[] = [
  '2026-05',
  '2026-06',
  '2026-07',
  '2026-08',
  '2026-01',
];

export function getNationalGridReport(monthKey: string): MonthlySupplyReport {
  return NATIONAL_GRID_REPORTS[monthKey] || REPORT_MAY_2026;
}

export function getAllNationalGridReports(): MonthlySupplyReport[] {
  return ORDERED_REPORT_KEYS.map(key => NATIONAL_GRID_REPORTS[key]);
}

/**
 * Technical suitability analysis for ML demand forecasting
 */
export interface ForecastingSuitabilityAudit {
  category: 'Technical Reference Data & Macro Grid Benchmark';
  is_suitable_for_hourly_model: false;
  reasons: string[];
  recommended_usage: string[];
  units: {
    national_grid: 'MegaWatts (MW net)';
    microgrid_telemetry: 'KiloWatts (kW)';
    conversion_ratio: '1 MW = 1,000 kW';
  };
}

export function getForecastingSuitabilityAudit(): ForecastingSuitabilityAudit {
  return {
    category: 'Technical Reference Data & Macro Grid Benchmark',
    is_suitable_for_hourly_model: false,
    reasons: [
      'Data Granularity Mismatch: electric Data.pdf supplies monthly peak summaries (MW), whereas the local microgrid model predicts hourly load (kW).',
      'Target Leakage Risk: Macro peak reports represent bulk regional coincident grid totals that incorporate nationwide industrial, agricultural, and urban diversity, not local feeder demand.',
      'Feature Space Absence: The PDF contains no weather telemetry (ambient temperature, humidity, solar irradiance) required by the microgrid ML pipeline.',
      'Temporal Incompatibility: A monthly aggregate cannot resolve the diurnal 24-hour cycle (e.g. 18:00–22:00 evening peak window) prescribed by HackSphere 3.0.'
    ],
    recommended_usage: [
      'Macro Transmission Baseline & Regional Benchmarking',
      'Bulk Grid Deficit Correlation (verifying grid reliability vs local microgrid autonomy)',
      'Stand-alone Microgrid Precedent Analysis (e.g. Lakshadweep and Andaman & Nicobar islands)',
      'Seasonal Peak Profiling (e.g. May 2026 heatwave peak of 270,832 MW vs Jan 2026 winter peak of 245,444 MW)'
    ],
    units: {
      national_grid: 'MegaWatts (MW net)',
      microgrid_telemetry: 'KiloWatts (kW)',
      conversion_ratio: '1 MW = 1,000 kW',
    },
  };
}

/**
 * Format CSV export of national grid data
 */
export function exportNationalGridToCsv(monthKey: string): string {
  const report = getNationalGridReport(monthKey);
  const rows = [
    'Source,Reporting_Month,Cumulative_Period,Region_ID,Region_Name,Entity_ID,Entity_Name,Name_Hindi,Peak_Demand_MW,Peak_Met_MW,Deficit_MW,Deficit_Pct,Is_Standalone,Notes',
  ];

  // All India Monthly
  rows.push(
    `CEA_Report,${report.reporting_month},${report.cumulative_period},ALL,All India,${report.all_india_monthly.id},"${report.all_india_monthly.name}","${report.all_india_monthly.name_hi || ''}",${report.all_india_monthly.peak_demand_mw},${report.all_india_monthly.peak_met_mw},${report.all_india_monthly.deficit_mw},${report.all_india_monthly.deficit_pct},false,"Synchronous national peak"`
  );

  // Regions & States
  for (const reg of report.regions) {
    rows.push(
      `CEA_Report,${report.reporting_month},${report.cumulative_period},${reg.region_id},"${reg.region_name}",${reg.regional_peak.id},"${reg.regional_peak.name}","${reg.regional_peak.name_hi || ''}",${reg.regional_peak.peak_demand_mw},${reg.regional_peak.peak_met_mw},${reg.regional_peak.deficit_mw},${reg.regional_peak.deficit_pct},false,"Regional Coincident Peak"`
    );
    for (const st of reg.states) {
      rows.push(
        `CEA_Report,${report.reporting_month},${report.cumulative_period},${reg.region_id},"${reg.region_name}",${st.id},"${st.name}","${st.name_hi || ''}",${st.peak_demand_mw},${st.peak_met_mw},${st.deficit_mw},${st.deficit_pct},${st.is_standalone ? 'true' : 'false'},"${st.notes || ''}"`
      );
    }
  }

  return rows.join('\n');
}
