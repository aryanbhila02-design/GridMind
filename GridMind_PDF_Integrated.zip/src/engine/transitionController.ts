/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — HackSphere 3.0 Exact Grid Transition Controller
 *
 * Official HackSphere 3.0 Microgrid Specification:
 * 1. Renewable Storage Mode:
 *    Triggered if predicted_demand_kw > 160 kW OR local hour in [18, 19, 20, 21, 22] (18:00 to 22:00 inclusive).
 * 2. Main Grid Mode:
 *    Triggered otherwise (predicted_demand_kw <= 160 kW AND hour outside [18..22]).
 * 3. Critical Overload Alert:
 *    Triggered if predicted_demand_kw >= 200 kW, independent of the selected grid mode.
 */

import type { GridMode } from '../types/microgrid.ts';

export interface TransitionDecision {
  timestamp: string;
  hour: number;
  predicted_demand_kw: number;
  grid_mode: GridMode;
  critical_overload: boolean;
  decision_reason: string;
}

/**
 * Extracts the 24-hour hour integer (0-23) from a timestamp string.
 * Supports ISO 8601 strings, 'YYYY-MM-DD HH:mm:ss', or time-only 'HH:mm'.
 */
export function extractHourFromTimestamp(timestamp: string): number {
  if (!timestamp || typeof timestamp !== 'string') {
    return 0;
  }

  const clean = timestamp.trim();

  // Try parsing time component directly first (handles both '2026-10-26 18:00:00' and '2026-10-26T18:00:00Z')
  const timeMatch = clean.match(/(?:T|\s)(\d{1,2}):(\d{2})(?::(\d{2}))?/);
  if (timeMatch && timeMatch[1] !== undefined) {
    const h = parseInt(timeMatch[1], 10);
    if (!isNaN(h) && h >= 0 && h <= 23) {
      return h;
    }
  }

  // Check if timestamp is simply 'HH:mm' or 'HH:mm:ss'
  const simpleMatch = clean.match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/);
  if (simpleMatch && simpleMatch[1] !== undefined) {
    const h = parseInt(simpleMatch[1], 10);
    if (!isNaN(h) && h >= 0 && h <= 23) {
      return h;
    }
  }

  // Fallback to standard Date object
  const parsed = new Date(clean);
  if (!isNaN(parsed.getTime())) {
    // Note: use getHours() for local or getUTCHours() if Z is present, but preserve explicit hour string if parsed
    return parsed.getHours();
  }

  return 0;
}

/**
 * Shared transition controller adhering strictly to HackSphere 3.0 requirements.
 */
export function evaluateGridTransition(
  timestamp: string,
  predicted_demand_kw: number
): TransitionDecision {
  const hour = extractHourFromTimestamp(timestamp);
  const isHighDemand = predicted_demand_kw > 160;
  const isEveningWindow = hour >= 18 && hour <= 22;
  const critical_overload = predicted_demand_kw >= 200;

  let grid_mode: GridMode;
  const reasons: string[] = [];

  if (isHighDemand || isEveningWindow) {
    grid_mode = 'Renewable Storage Mode';
    if (isHighDemand && isEveningWindow) {
      reasons.push(
        `Demand (${predicted_demand_kw.toFixed(1)} kW > 160 kW) and evening peak window (${hour}:00 in 18:00-22:00)`
      );
    } else if (isHighDemand) {
      reasons.push(
        `High demand threshold exceeded (${predicted_demand_kw.toFixed(1)} kW > 160 kW)`
      );
    } else {
      reasons.push(
        `Evening peak window active (${hour}:00 within 18:00-22:00 schedule)`
      );
    }
  } else {
    grid_mode = 'Main Grid Mode';
    reasons.push(
      `Nominal base demand (${predicted_demand_kw.toFixed(1)} kW ≤ 160 kW) outside evening peak (hour ${hour}:00)`
    );
  }

  if (critical_overload) {
    reasons.push(
      `CRITICAL OVERLOAD: Demand (${predicted_demand_kw.toFixed(1)} kW ≥ 200 kW) exceeds microgrid transformer capacity`
    );
  }

  return {
    timestamp,
    hour,
    predicted_demand_kw: Number(predicted_demand_kw.toFixed(2)),
    grid_mode,
    critical_overload,
    decision_reason: reasons.join(' | '),
  };
}
