/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Centralized Zoho Catalyst QuickML Client
 * HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine
 * 
 * Secure Server-Side Invocation of Zoho Catalyst QuickML REST Endpoint:
 * - Credentials sourced strictly from server-side environment variables
 * - No client-side credential transmission or exposure
 * - Standard Zoho Catalyst OAuth / Project headers
 * - Deterministic timeout and non-leaking error diagnostics
 * - Transparent response validation (never masks failures as successes)
 */

import type { TelemetryRow } from '../types/microgrid.ts';

export interface QuickMLInferenceResult {
  success: boolean;
  predictions?: number[];
  httpStatus?: number;
  latencyMs: number;
  error?: string;
  source: 'live_quickml' | 'unverified' | 'failed';
}

export interface ServerQuickMLConfig {
  endpointUrl: string;
  apiKey: string;
  projectId: string;
  catalystEnv: string;
  timeoutMs: number;
}

/**
 * Loads trusted server-side QuickML configuration from process.env
 */
export function getServerQuickMLConfig(): ServerQuickMLConfig {
  return {
    endpointUrl: (process.env.ZOHO_QUICKML_ENDPOINT || '').trim(),
    apiKey: (process.env.ZOHO_CATALYST_API_KEY || '').trim(),
    projectId: (process.env.ZOHO_PROJECT_ID || '').trim(),
    catalystEnv: (process.env.ZOHO_CATALYST_ENV || 'development').trim(),
    timeoutMs: Number(process.env.ZOHO_QUICKML_TIMEOUT_MS) || 8000,
  };
}

/**
 * Checks whether QuickML is configured with an endpoint URL
 */
export function isQuickMLConfigured(): boolean {
  const config = getServerQuickMLConfig();
  return Boolean(config.endpointUrl && config.endpointUrl.startsWith('http'));
}

/**
 * Invokes published Zoho Catalyst QuickML batch prediction endpoint.
 * Conforms to Catalyst QuickML REST payload structure.
 */
export async function invokeQuickMLBatch(
  rows: TelemetryRow[],
  customTimeoutMs?: number
): Promise<QuickMLInferenceResult> {
  const config = getServerQuickMLConfig();
  const start = Date.now();

  if (!config.endpointUrl || !config.endpointUrl.startsWith('http')) {
    return {
      success: false,
      latencyMs: 0,
      error: 'Zoho Catalyst QuickML endpoint is not configured in server environment (ZOHO_QUICKML_ENDPOINT).',
      source: 'unverified',
    };
  }

  // Prevent SSRF: allow only https/http to legitimate catalyst or external endpoints
  try {
    const parsed = new URL(config.endpointUrl);
    if (!['https:', 'http:'].includes(parsed.protocol)) {
      return {
        success: false,
        latencyMs: 0,
        error: 'Invalid protocol for QuickML endpoint. Only HTTPS/HTTP permitted.',
        source: 'failed',
      };
    }
  } catch {
    return {
      success: false,
      latencyMs: 0,
      error: 'Malformed QuickML endpoint URL.',
      source: 'failed',
    };
  }

  // Construct official feature payload expected by QuickML tabular regression
  const instances = rows.map(r => ({
    timestamp: r.timestamp,
    ambient_temp_c: Number(r.ambient_temp_c),
    humidity_pct: Number(r.humidity_pct),
    solar_irradiance_wm2: Number(r.solar_irradiance_wm2),
  }));

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  // Standard Catalyst OAuth token header
  if (config.apiKey) {
    headers['Authorization'] = config.apiKey.startsWith('Zoho-oauthtoken')
      ? config.apiKey
      : `Zoho-oauthtoken ${config.apiKey}`;
  }

  if (config.projectId) {
    headers['X-Catalyst-Project-Id'] = config.projectId;
  }

  const timeoutMs = customTimeoutMs || config.timeoutMs;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(config.endpointUrl, {
      method: 'POST',
      headers,
      body: JSON.stringify({ instances }),
      signal: controller.signal,
    });
    clearTimeout(timer);

    const latencyMs = Date.now() - start;

    if (!response.ok) {
      return {
        success: false,
        httpStatus: response.status,
        latencyMs,
        error: `QuickML service returned HTTP ${response.status} (${response.statusText}).`,
        source: 'failed',
      };
    }

    const resJson = await response.json();
    let preds: number[] = [];

    if (Array.isArray(resJson.predictions)) {
      preds = resJson.predictions.map((p: unknown) => Number(p));
    } else if (Array.isArray(resJson.data)) {
      preds = resJson.data.map((d: { target_demand_kw?: number; prediction?: number }) =>
        Number(d.target_demand_kw ?? d.prediction ?? d)
      );
    }

    // Validate predictions shape and numeric integrity
    if (preds.length === rows.length && preds.every(p => !isNaN(p) && isFinite(p))) {
      return {
        success: true,
        predictions: preds,
        httpStatus: response.status,
        latencyMs,
        source: 'live_quickml',
      };
    } else {
      return {
        success: false,
        httpStatus: response.status,
        latencyMs,
        error: `QuickML response payload received but could not be parsed into ${rows.length} valid numeric predictions.`,
        source: 'failed',
      };
    }
  } catch (err: unknown) {
    clearTimeout(timer);
    const latencyMs = Date.now() - start;
    const msg = err instanceof Error ? err.message : String(err);
    return {
      success: false,
      latencyMs,
      error: `QuickML request failed: ${msg.includes('abort') ? 'Request timed out' : msg}`,
      source: 'failed',
    };
  }
}
