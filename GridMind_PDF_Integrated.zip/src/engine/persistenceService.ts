/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Data Persistence Layer
 * HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine
 * 
 * Provides robust file-backed JSON persistence for:
 * 1. Uploaded & active telemetry rows
 * 2. Latest 24-hour demand forecast and metadata
 * 3. Grid event and alert audit logs
 * 4. User-configured battery & operational parameters
 * 
 * Features:
 * - Safe directory creation & atomic file updates
 * - Corrupted / missing file tolerance with fallback defaults
 * - Zero secret persistence (credentials are strictly excluded)
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import type {
  BatteryConfig,
  ForecastHourResult,
  GridEvent,
  TelemetryRow,
} from '../types/microgrid.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Store persistent data in /data directory at project root
const DATA_DIR = path.resolve(__dirname, '../../data');

const PATH_TELEMETRY = path.join(DATA_DIR, 'persisted_telemetry.json');
const PATH_FORECAST = path.join(DATA_DIR, 'persisted_forecast.json');
const PATH_EVENTS = path.join(DATA_DIR, 'persisted_events.json');
const PATH_SETTINGS = path.join(DATA_DIR, 'persisted_settings.json');

export interface PersistedForecastPayload {
  metadata: {
    timestamp: string;
    modelUsed: string;
    isQuickMlLive: boolean;
    forecastingMode: string;
    notes: string;
  };
  results: ForecastHourResult[];
}

export interface PersistedSettingsPayload {
  batteryConfig: BatteryConfig;
  lastUpdated: string;
}

/**
 * Ensures data directory exists
 */
function ensureDataDir(): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  } catch (err) {
    console.warn('[Persistence] Warning: Could not create data directory:', err);
  }
}

/**
 * Safely writes a JSON file atomically via a temporary file
 */
function safeWriteJson(filePath: string, data: unknown): boolean {
  ensureDataDir();
  const tempPath = `${filePath}.tmp.${Date.now()}`;
  try {
    const jsonStr = JSON.stringify(data, null, 2);
    fs.writeFileSync(tempPath, jsonStr, 'utf-8');
    fs.renameSync(tempPath, filePath);
    return true;
  } catch (err) {
    console.error(`[Persistence] Error writing ${filePath}:`, err);
    try {
      if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
    } catch {
      // Ignore cleanup error
    }
    return false;
  }
}

/**
 * Safely reads and parses a JSON file, returning defaultValue on error
 */
function safeReadJson<T>(filePath: string, defaultValue: T): T {
  try {
    if (!fs.existsSync(filePath)) {
      return defaultValue;
    }
    const content = fs.readFileSync(filePath, 'utf-8');
    if (!content.trim()) return defaultValue;
    return JSON.parse(content) as T;
  } catch (err) {
    console.warn(`[Persistence] Corrupted or unreadable file ${filePath}. Using fallback.`, err);
    return defaultValue;
  }
}

// -------------------------------------------------------------
// Public Persistence Methods
// -------------------------------------------------------------

export function savePersistedTelemetry(rows: TelemetryRow[]): boolean {
  return safeWriteJson(PATH_TELEMETRY, rows);
}

export function loadPersistedTelemetry(): TelemetryRow[] {
  return safeReadJson<TelemetryRow[]>(PATH_TELEMETRY, []);
}

export function savePersistedForecast(payload: PersistedForecastPayload): boolean {
  return safeWriteJson(PATH_FORECAST, payload);
}

export function loadPersistedForecast(): PersistedForecastPayload | null {
  return safeReadJson<PersistedForecastPayload | null>(PATH_FORECAST, null);
}

export function savePersistedEvents(events: GridEvent[]): boolean {
  // Cap at last 200 events to prevent unbounded growth
  const capped = events.slice(0, 200);
  return safeWriteJson(PATH_EVENTS, capped);
}

export function loadPersistedEvents(): GridEvent[] {
  return safeReadJson<GridEvent[]>(PATH_EVENTS, []);
}

export function savePersistedSettings(settings: PersistedSettingsPayload): boolean {
  return safeWriteJson(PATH_SETTINGS, settings);
}

export function loadPersistedSettings(): PersistedSettingsPayload | null {
  return safeReadJson<PersistedSettingsPayload | null>(PATH_SETTINGS, null);
}

export function isPersistenceLayerOperational(): boolean {
  try {
    ensureDataDir();
    const testFile = path.join(DATA_DIR, '.health_check_tmp');
    fs.writeFileSync(testFile, 'ok', 'utf-8');
    fs.unlinkSync(testFile);
    return true;
  } catch {
    return false;
  }
}
