/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Telemetry Validator and CSV Engine
 */

import type { TelemetryRow, ValidationError, ValidationSummary } from '../types/microgrid.ts';

export interface ParseCsvOptions {
  requireTarget?: boolean;
  interpolateSmallGaps?: boolean;
}

export function parseCsvText(csvText: string): { headers: string[]; rows: string[][] } {
  const lines = csvText
    .split(/\r?\n/)
    .map(line => line.trim())
    .filter(line => line.length > 0);

  if (lines.length === 0) {
    return { headers: [], rows: [] };
  }

  // Parse header
  const headers = lines[0].split(',').map(h => h.trim().replace(/^["']|["']$/g, ''));
  const rows = lines.slice(1).map(line => {
    // Basic comma separation taking quotes into account
    const values: string[] = [];
    let current = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"' || char === "'") {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        values.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    values.push(current.trim());
    return values.map(v => v.replace(/^["']|["']$/g, ''));
  });

  return { headers, rows };
}

/**
 * Validates and normalizes raw telemetry records.
 */
export function validateTelemetryCsv(
  csvText: string,
  options: ParseCsvOptions = {}
): {
  validRecords: TelemetryRow[];
  summary: ValidationSummary;
} {
  const { headers, rows } = parseCsvText(csvText);
  const errors: ValidationError[] = [];

  const requiredHeaders = ['timestamp', 'ambient_temp_c', 'humidity_pct', 'solar_irradiance_wm2'];
  const headerMap = new Map<string, number>();

  headers.forEach((h, idx) => {
    headerMap.set(h.toLowerCase(), idx);
  });

  const missingHeaders = requiredHeaders.filter(req => !headerMap.has(req));
  if (missingHeaders.length > 0) {
    errors.push({
      row: 1,
      field: 'header',
      message: `Missing required column(s): ${missingHeaders.join(', ')}. Official schema requires: timestamp, ambient_temp_c, humidity_pct, solar_irradiance_wm2`,
    });
  }

  const tsIdx = headerMap.get('timestamp') ?? -1;
  const tempIdx = headerMap.get('ambient_temp_c') ?? -1;
  const humIdx = headerMap.get('humidity_pct') ?? -1;
  const solIdx = headerMap.get('solar_irradiance_wm2') ?? -1;
  const targetIdx = headerMap.get('target_demand_kw') ?? -1;
  const hasTarget = targetIdx !== -1;

  if (options.requireTarget && !hasTarget) {
    errors.push({
      row: 1,
      field: 'target_demand_kw',
      message: 'Training data requires "target_demand_kw" target column',
    });
  }

  const validRecords: TelemetryRow[] = [];
  const seenTimestamps = new Set<string>();
  let duplicateCount = 0;
  let previousTimestampEpoch = 0;
  let isChronological = true;

  if (missingHeaders.length === 0) {
    rows.forEach((rowVals, rowNum) => {
      const lineNum = rowNum + 2; // +1 header, +1 1-based index
      const rawTs = rowVals[tsIdx] || '';
      const rawTemp = rowVals[tempIdx] || '';
      const rawHum = rowVals[humIdx] || '';
      const rawSol = rowVals[solIdx] || '';
      const rawTarget = hasTarget ? rowVals[targetIdx] : undefined;

      let rowValid = true;

      // 1. Timestamp validation
      if (!rawTs) {
        errors.push({
          row: lineNum,
          field: 'timestamp',
          message: 'Empty timestamp value',
        });
        rowValid = false;
      } else {
        const parsedDate = new Date(rawTs);
        if (isNaN(parsedDate.getTime())) {
          errors.push({
            row: lineNum,
            field: 'timestamp',
            message: `Invalid timestamp format: "${rawTs}". Expected standard ISO format (e.g. 2026-10-26T00:00:00)`,
            rawValue: rawTs,
          });
          rowValid = false;
        } else {
          // Check duplicates
          if (seenTimestamps.has(rawTs)) {
            duplicateCount++;
            errors.push({
              row: lineNum,
              field: 'timestamp',
              message: `Duplicate timestamp detected: "${rawTs}"`,
              rawValue: rawTs,
            });
            rowValid = false;
          } else {
            seenTimestamps.add(rawTs);
          }

          // Check chronological sequence
          const currentEpoch = parsedDate.getTime();
          if (previousTimestampEpoch > 0 && currentEpoch < previousTimestampEpoch) {
            isChronological = false;
          }
          previousTimestampEpoch = currentEpoch;
        }
      }

      // 2. Weather fields validation
      const temp = parseFloat(rawTemp);
      if (isNaN(temp)) {
        errors.push({
          row: lineNum,
          field: 'ambient_temp_c',
          message: `Non-numeric ambient_temp_c: "${rawTemp}"`,
          rawValue: rawTemp,
        });
        rowValid = false;
      } else if (temp < -60 || temp > 65) {
        errors.push({
          row: lineNum,
          field: 'ambient_temp_c',
          message: `Out of plausible range ambient_temp_c (-60°C to 65°C): ${temp}`,
          rawValue: rawTemp,
        });
        rowValid = false;
      }

      const hum = parseFloat(rawHum);
      if (isNaN(hum)) {
        errors.push({
          row: lineNum,
          field: 'humidity_pct',
          message: `Non-numeric humidity_pct: "${rawHum}"`,
          rawValue: rawHum,
        });
        rowValid = false;
      } else if (hum < 0 || hum > 100) {
        errors.push({
          row: lineNum,
          field: 'humidity_pct',
          message: `Out of percentage range humidity_pct (0-100%): ${hum}`,
          rawValue: rawHum,
        });
        rowValid = false;
      }

      const sol = parseFloat(rawSol);
      if (isNaN(sol)) {
        errors.push({
          row: lineNum,
          field: 'solar_irradiance_wm2',
          message: `Non-numeric solar_irradiance_wm2: "${rawSol}"`,
          rawValue: rawSol,
        });
        rowValid = false;
      } else if (sol < 0 || sol > 2000) {
        errors.push({
          row: lineNum,
          field: 'solar_irradiance_wm2',
          message: `Out of range solar_irradiance_wm2 (0-2000 W/m²): ${sol}`,
          rawValue: rawSol,
        });
        rowValid = false;
      }

      // 3. Optional target validation
      let target_demand_kw: number | undefined = undefined;
      if (hasTarget && rawTarget !== undefined && rawTarget !== '') {
        const parsedTarget = parseFloat(rawTarget);
        if (isNaN(parsedTarget)) {
          errors.push({
            row: lineNum,
            field: 'target_demand_kw',
            message: `Non-numeric target_demand_kw: "${rawTarget}"`,
            rawValue: rawTarget,
          });
          rowValid = false;
        } else if (parsedTarget < 0 || parsedTarget > 5000) {
          errors.push({
            row: lineNum,
            field: 'target_demand_kw',
            message: `Out of plausible microgrid load range: ${parsedTarget} kW`,
            rawValue: rawTarget,
          });
          rowValid = false;
        } else {
          target_demand_kw = parsedTarget;
        }
      }

      if (rowValid) {
        validRecords.push({
          timestamp: rawTs,
          ambient_temp_c: temp,
          humidity_pct: hum,
          solar_irradiance_wm2: sol,
          ...(target_demand_kw !== undefined ? { target_demand_kw } : {}),
        });
      }
    });
  }

  // Enforce chronological sorting of valid records if out-of-order was detected
  validRecords.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  const summary: ValidationSummary = {
    totalRows: rows.length,
    validRows: validRecords.length,
    rejectedRows: rows.length - validRecords.length,
    hasTargetDemand: hasTarget,
    startDate: validRecords[0]?.timestamp,
    endDate: validRecords[validRecords.length - 1]?.timestamp,
    errors,
    cleaningPolicy:
      'Strict schema validation: Malformed, non-numeric, or duplicate records are isolated with clear row-level audit trails. Valid records are chronologically ordered by timestamp without fabricating unmeasured data.',
    isChronological,
    duplicateCount,
  };

  return { validRecords, summary };
}

/**
 * Serializes prediction results into the official HackSphere 3.0 CSV evaluation format:
 * Exactly two columns in order:
 * timestamp,target_demand_kw
 */
export function exportPredictionsToCsv(
  predictions: { timestamp: string; target_demand_kw: number }[]
): string {
  const header = 'timestamp,target_demand_kw\n';
  const rows = predictions.map(p => `${p.timestamp},${Number(p.target_demand_kw.toFixed(2))}`).join('\n');
  return header + rows;
}

/**
 * Serializes telemetry rows back into standard CSV.
 */
export function exportTelemetryToCsv(records: TelemetryRow[]): string {
  const hasTarget = records.some(r => r.target_demand_kw !== undefined);
  const header = hasTarget
    ? 'timestamp,ambient_temp_c,humidity_pct,solar_irradiance_wm2,target_demand_kw\n'
    : 'timestamp,ambient_temp_c,humidity_pct,solar_irradiance_wm2\n';

  const lines = records.map(r => {
    const base = `${r.timestamp},${r.ambient_temp_c},${r.humidity_pct},${r.solar_irradiance_wm2}`;
    return hasTarget ? `${base},${r.target_demand_kw ?? ''}` : base;
  });

  return header + lines.join('\n');
}
