/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Prediction Explainability Engine
 * HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine
 * 
 * Implements:
 * 1. Permutation Feature Importance on held-out chronological validation telemetry
 * 2. Relative importance percentage calculation
 * 3. Domain rationale and influence directional mapping
 * 4. Critical distinction between feature reliance and causal mechanisms
 */

import type { ExplainabilityResult, FeatureImportanceScore, TelemetryRow } from '../types/microgrid.ts';

// Helper to compute simple linear regression / ridge weights on training data
function fitLinearModel(
  trainX: number[][],
  trainY: number[]
): { weights: number[]; bias: number } {
  const n = trainX.length;
  const d = trainX[0].length;

  // Add small ridge penalty alpha = 0.5 for stability
  // Normal equations: (X^T X + alpha*I) w = X^T (y - mean_y)
  const meanY = trainY.reduce((a, b) => a + b, 0) / n;
  const centeredY = trainY.map(y => y - meanY);

  const XtX: number[][] = Array.from({ length: d }, () => new Array(d).fill(0));
  const Xty: number[] = new Array(d).fill(0);

  for (let i = 0; i < n; i++) {
    for (let j = 0; j < d; j++) {
      Xty[j] += trainX[i][j] * centeredY[i];
      for (let k = 0; k < d; k++) {
        XtX[j][k] += trainX[i][j] * trainX[i][k];
      }
    }
  }

  // Add ridge lambda * I
  const lambda = 0.5;
  for (let j = 0; j < d; j++) {
    XtX[j][j] += lambda;
  }

  // Gaussian elimination solver for small d (d=4)
  const A = XtX.map((row, idx) => [...row, Xty[idx]]);
  for (let i = 0; i < d; i++) {
    let maxRow = i;
    for (let k = i + 1; k < d; k++) {
      if (Math.abs(A[k][i]) > Math.abs(A[maxRow][i])) maxRow = k;
    }
    const temp = A[i];
    A[i] = A[maxRow];
    A[maxRow] = temp;

    const pivot = A[i][i] || 1e-9;
    for (let c = i; c <= d; c++) A[i][c] /= pivot;

    for (let k = 0; k < d; k++) {
      if (k !== i) {
        const factor = A[k][i];
        for (let c = i; c <= d; c++) {
          A[k][c] -= factor * A[i][c];
        }
      }
    }
  }

  const weights = A.map(row => row[d]);
  return { weights, bias: meanY };
}

function predictLinear(x: number[], weights: number[], bias: number): number {
  let val = bias;
  for (let j = 0; j < weights.length; j++) {
    val += weights[j] * x[j];
  }
  return val;
}

function computeRmse(
  X: number[][],
  y: number[],
  weights: number[],
  bias: number
): number {
  if (X.length === 0) return 0;
  let sumSq = 0;
  for (let i = 0; i < X.length; i++) {
    const pred = predictLinear(X[i], weights, bias);
    sumSq += (pred - y[i]) ** 2;
  }
  return Math.sqrt(sumSq / X.length);
}

// Pseudo-random deterministic shuffle
function shuffleArray<T>(arr: T[], seed: number): T[] {
  const copy = [...arr];
  let s = seed;
  for (let i = copy.length - 1; i > 0; i--) {
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    const j = s % (i + 1);
    const tmp = copy[i];
    copy[i] = copy[j];
    copy[j] = tmp;
  }
  return copy;
}

export function computePermutationImportance(
  rows: TelemetryRow[],
  numShuffles = 5
): ExplainabilityResult {
  const labelledRows = rows.filter(
    r => r.target_demand_kw !== undefined && !isNaN(r.target_demand_kw)
  );

  if (labelledRows.length < 10) {
    throw new Error('Permutation feature importance requires at least 10 labelled telemetry rows.');
  }

  // Feature set: [ambient_temp_c, humidity_pct, solar_irradiance_wm2, hour_of_day]
  const featureDefinitions = [
    {
      feature: 'ambient_temp_c',
      label: 'Ambient Temperature (°C)',
      direction: 'positive' as const,
      domainRationale:
        'Higher ambient temperatures sharply increase cooling and thermal loads across residential and commercial HVAC units, driving demand upwards during daytime heat peaks.',
    },
    {
      feature: 'hour_of_day',
      label: 'Diurnal Hour (0–23h)',
      direction: 'non_linear' as const,
      domainRationale:
        'Controls diurnal operational schedules: early morning baseload, mid-afternoon cooling peaks, and evening lighting/cooking surges between 18:00 and 22:00.',
    },
    {
      feature: 'solar_irradiance_wm2',
      label: 'Solar Irradiance (W/m²)',
      direction: 'positive' as const,
      domainRationale:
        'Solar irradiance is strongly coincident with high afternoon industrial activity and ambient solar heat gain, while simultaneously enabling photovoltaic generation.',
    },
    {
      feature: 'humidity_pct',
      label: 'Relative Humidity (%)',
      direction: 'negative' as const,
      domainRationale:
        'High humidity alters enthalpy and air-density, typically correlating with overcast/rainy conditions that suppress outdoor thermal extremes and moderate peak air conditioning.',
    },
  ];

  const fullData: { x: number[]; y: number }[] = labelledRows.map(r => {
    const d = new Date(r.timestamp);
    const hour = isNaN(d.getUTCHours()) ? 12 : d.getUTCHours();
    return {
      x: [r.ambient_temp_c, r.humidity_pct, r.solar_irradiance_wm2, hour],
      y: r.target_demand_kw!,
    };
  });

  // Chronological 70% train / 30% held-out test split
  const trainSize = Math.max(5, Math.floor(fullData.length * 0.7));
  const trainData = fullData.slice(0, trainSize);
  const valData = fullData.slice(trainSize);

  const trainX = trainData.map(d => d.x);
  const trainY = trainData.map(d => d.y);
  const valX = valData.map(d => d.x);
  const valY = valData.map(d => d.y);

  // Train base model on training fold
  const { weights, bias } = fitLinearModel(trainX, trainY);

  // Compute uncorrupted baseline validation RMSE
  const baselineRmse = computeRmse(valX, valY, weights, bias);

  // Feature permutation on validation fold
  const rawImportanceScores: { featureIndex: number; deltaRmse: number }[] = [];

  for (let fIdx = 0; fIdx < featureDefinitions.length; fIdx++) {
    // Extract column fIdx
    const origCol = valX.map(row => row[fIdx]);
    let totalCorruptedRmse = 0;

    for (let s = 1; s <= numShuffles; s++) {
      const shuffledCol = shuffleArray(origCol, 42 + fIdx * 100 + s * 13);
      const corruptedX = valX.map((row, rowIdx) => {
        const newRow = [...row];
        newRow[fIdx] = shuffledCol[rowIdx];
        return newRow;
      });
      totalCorruptedRmse += computeRmse(corruptedX, valY, weights, bias);
    }

    const avgCorruptedRmse = totalCorruptedRmse / numShuffles;
    const deltaRmse = Math.max(0, avgCorruptedRmse - baselineRmse);
    rawImportanceScores.push({ featureIndex: fIdx, deltaRmse });
  }

  // Sum of positive delta RMSE for percentage calculation
  const sumDelta = rawImportanceScores.reduce((acc, curr) => acc + curr.deltaRmse, 0) || 1.0;

  const importances: FeatureImportanceScore[] = rawImportanceScores
    .map(item => {
      const def = featureDefinitions[item.featureIndex];
      const relPct = Number(((item.deltaRmse / sumDelta) * 100).toFixed(1));
      return {
        feature: def.feature,
        label: def.label,
        deltaRmse: Number(item.deltaRmse.toFixed(3)),
        relativeImportancePct: relPct,
        directionOfInfluence: def.direction,
        domainRationale: def.domainRationale,
      };
    })
    .sort((a, b) => b.deltaRmse - a.deltaRmse);

  return {
    baselineRmse: Number(baselineRmse.toFixed(2)),
    evaluatedOn: `Held-out chronological validation set (${valData.length} hours)`,
    sampleCount: valData.length,
    importances,
    methodology:
      'Breiman-Fisher Permutation Feature Importance: Evaluated on the held-out 30% chronological validation split over 5 stochastic column permutations. Measures the precise degradation in out-of-sample RMSE (ΔRMSE) when the predictor column is broken while holding all other features fixed.',
    causalityCaveat:
      'Reliance vs. Causality: Permutation importance quantifies model reliance on each feature given the empirical joint distribution. It does NOT prove direct physical causation. For example, high solar irradiance strongly co-occurs with daytime industrial shift operations; the model relies on solar readings as a proxy for operational schedules in addition to physical thermal gain.',
  };
}
