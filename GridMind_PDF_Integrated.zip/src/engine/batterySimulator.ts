/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Transparent Battery Energy Storage System (BESS) Simulator
 */

import type { BatteryConfig, GridMode } from '../types/microgrid.ts';

export interface BatterySimulationStepInput {
  demand_kw: number;
  solar_irradiance_wm2: number;
  grid_mode: GridMode;
  pv_installed_capacity_kw?: number; // microgrid PV peak capacity, defaults to 120 kW
}

export interface BatterySimulationStepOutput {
  initial_soc_pct: number;
  initial_soc_kwh: number;
  final_soc_pct: number;
  final_soc_kwh: number;
  battery_power_kw: number; // positive = discharging, negative = charging
  battery_energy_transferred_kwh: number;
  solar_generation_kw: number;
  solar_used_kw: number;
  solar_curtailed_kw: number;
  grid_import_kw: number;
  low_battery_warning: boolean;
  action_summary: string;
}

export const DEFAULT_BATTERY_CONFIG: BatteryConfig = {
  capacity_kwh: 500,
  initial_soc_pct: 65,
  max_charge_kw: 100,
  max_discharge_kw: 120,
  efficiency_pct: 92, // roundtrip efficiency percentage
  min_soc_pct: 15,
  low_soc_warning_pct: 20,
};

/**
 * Calculates estimated solar PV generation in kW from irradiance (W/m²).
 * Assumes a standard microgrid solar array (~120 kWp at 1000 W/m² with standard inverter efficiency 0.85).
 */
export function estimateSolarGenerationKw(
  solar_irradiance_wm2: number,
  pv_capacity_kw: number = 120
): number {
  if (solar_irradiance_wm2 <= 0) return 0;
  // standard solar irradiance peak is 1000 W/m2
  const ratio = Math.min(1.2, Math.max(0, solar_irradiance_wm2 / 1000));
  // System performance ratio ~0.88
  return Number((pv_capacity_kw * ratio * 0.88).toFixed(2));
}

export class BatterySimulator {
  private config: BatteryConfig;
  private current_soc_kwh: number;

  constructor(config: Partial<BatteryConfig> = {}) {
    this.config = { ...DEFAULT_BATTERY_CONFIG, ...config };
    const initial_kwh = (this.config.initial_soc_pct / 100) * this.config.capacity_kwh;
    this.current_soc_kwh = Math.max(0, Math.min(this.config.capacity_kwh, initial_kwh));
  }

  public getConfig(): BatteryConfig {
    return { ...this.config };
  }

  public setConfig(config: Partial<BatteryConfig>): void {
    this.config = { ...this.config, ...config };
    this.current_soc_kwh = Math.min(this.current_soc_kwh, this.config.capacity_kwh);
  }

  public resetSoc(soc_pct?: number): void {
    const targetPct = soc_pct !== undefined ? soc_pct : this.config.initial_soc_pct;
    this.current_soc_kwh = (targetPct / 100) * this.config.capacity_kwh;
  }

  public getCurrentSocPct(): number {
    return Number(((this.current_soc_kwh / this.config.capacity_kwh) * 100).toFixed(1));
  }

  public getSocPct(): number {
    return this.getCurrentSocPct();
  }

  public getCurrentSocKwh(): number {
    return Number(this.current_soc_kwh.toFixed(2));
  }

  public getSocKwh(): number {
    return this.getCurrentSocKwh();
  }

  /**
   * Simulates one 1-hour interval.
   * Energy conservation strictly preserved:
   * Demand = Grid Import + Battery Discharge + Solar Used
   */
  public step(input: BatterySimulationStepInput): BatterySimulationStepOutput {
    const initial_kwh = this.current_soc_kwh;
    const initial_pct = this.getCurrentSocPct();

    const pv_capacity = input.pv_installed_capacity_kw || 120;
    const solar_gen_kw = estimateSolarGenerationKw(input.solar_irradiance_wm2, pv_capacity);

    // Direct solar contribution directly satisfies demand first
    const solar_used_kw = Math.min(solar_gen_kw, input.demand_kw);
    const solar_surplus_kw = Math.max(0, solar_gen_kw - solar_used_kw);
    const net_demand_unmet_kw = Math.max(0, input.demand_kw - solar_used_kw);

    const min_kwh = (this.config.min_soc_pct / 100) * this.config.capacity_kwh;
    const max_kwh = this.config.capacity_kwh;
    const one_way_efficiency = Math.sqrt(this.config.efficiency_pct / 100);

    let battery_power_kw = 0; // >0 discharging, <0 charging
    let solar_curtailed_kw = 0;
    let grid_import_kw = 0;
    let action = '';

    if (input.grid_mode === 'Renewable Storage Mode') {
      // Priority in Renewable Storage Mode: Discharge battery to cover net demand
      const available_discharge_energy = Math.max(0, this.current_soc_kwh - min_kwh);
      // Discharging 1 kW delivers 1 * one_way_efficiency to load in 1 hour
      const max_demand_battery_can_cover = (available_discharge_energy * one_way_efficiency);
      const target_discharge = Math.min(
        this.config.max_discharge_kw,
        net_demand_unmet_kw,
        max_demand_battery_can_cover
      );

      if (target_discharge > 0) {
        battery_power_kw = target_discharge;
        const kwh_depleted = target_discharge / one_way_efficiency;
        this.current_soc_kwh = Math.max(min_kwh, this.current_soc_kwh - kwh_depleted);
        action = `Discharging ${target_discharge.toFixed(1)} kW to support Renewable Storage load`;
      } else {
        action = 'Idle (battery at reserve buffer or zero net load)';
      }

      // Any remaining net demand is supplied by the main grid
      grid_import_kw = Math.max(0, net_demand_unmet_kw - battery_power_kw);
      solar_curtailed_kw = 0; // All solar was used or zero surplus
    } else {
      // Main Grid Mode:
      // If solar surplus exists, charge battery from solar!
      if (solar_surplus_kw > 0 && this.current_soc_kwh < max_kwh) {
        const headroom_kwh = max_kwh - this.current_soc_kwh;
        // charging with P kW absorbs P * one_way_efficiency into storage
        const max_charge_rate_from_headroom = headroom_kwh / one_way_efficiency;
        const charge_power = Math.min(
          this.config.max_charge_kw,
          solar_surplus_kw,
          max_charge_rate_from_headroom
        );

        if (charge_power > 0) {
          battery_power_kw = -charge_power; // negative signifies charging
          const kwh_added = charge_power * one_way_efficiency;
          this.current_soc_kwh = Math.min(max_kwh, this.current_soc_kwh + kwh_added);
          solar_curtailed_kw = Math.max(0, solar_surplus_kw - charge_power);
          action = `Charging ${charge_power.toFixed(1)} kW from solar surplus`;
        } else {
          solar_curtailed_kw = solar_surplus_kw;
          action = 'Main grid serving base load; battery fully charged';
        }
      } else {
        action = 'Main grid supplying base demand; battery standing by';
      }

      // In main grid mode, unmet demand comes from the grid
      grid_import_kw = net_demand_unmet_kw;
    }

    // Strict boundary enforcement
    this.current_soc_kwh = Math.max(0, Math.min(max_kwh, this.current_soc_kwh));
    const final_pct = this.getCurrentSocPct();
    const final_kwh = this.getCurrentSocKwh();
    const low_battery = final_pct < this.config.low_soc_warning_pct;

    return {
      initial_soc_pct: initial_pct,
      initial_soc_kwh: initial_kwh,
      final_soc_pct: final_pct,
      final_soc_kwh: final_kwh,
      battery_power_kw: Number(battery_power_kw.toFixed(2)),
      battery_energy_transferred_kwh: Number(Math.abs(this.current_soc_kwh - initial_kwh).toFixed(2)),
      solar_generation_kw: Number(solar_gen_kw.toFixed(2)),
      solar_used_kw: Number(solar_used_kw.toFixed(2)),
      solar_curtailed_kw: Number(solar_curtailed_kw.toFixed(2)),
      grid_import_kw: Number(grid_import_kw.toFixed(2)),
      low_battery_warning: low_battery,
      action_summary: action,
    };
  }
}
