/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — What-If Energy Scenario Simulation Engine
 * HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine
 * 
 * Simulates:
 * 1. Side-by-side battery storage and solar integration scenarios
 * 2. Energy balance, curtailment, grid import, and critical overload mitigation
 * 3. Strict 'Hypothetical Scenario — Not a Live Grid State' labeling
 */

import type {
  BatteryConfig,
  ForecastHourResult,
  WhatIfScenarioSummary,
} from '../types/microgrid.ts';
import { BatterySimulator } from './batterySimulator.ts';
import { evaluateGridTransition } from './transitionController.ts';

export function runWhatIfScenarios(
  baseForecast: ForecastHourResult[],
  customConfigs: { name: string; config: BatteryConfig }[]
): WhatIfScenarioSummary[] {
  return customConfigs.map((scenario, idx) => {
    const sim = new BatterySimulator(scenario.config);
    let totalSolarGen = 0;
    let totalSolarUsed = 0;
    let totalSolarCurtailed = 0;
    let totalGridImport = 0;
    let totalDischargedKwh = 0;
    let criticalOverloads = 0;
    let minSoc = 100;
    let maxSoc = 0;
    let peakDemand = 0;

    for (const h of baseForecast) {
      const demand = h.predicted_demand_kw;
      if (demand > peakDemand) peakDemand = demand;

      const decision = evaluateGridTransition(h.timestamp, demand);

      if (decision.critical_overload) {
        criticalOverloads++;
      }

      // Step battery
      const step = sim.step({
        demand_kw: demand,
        solar_irradiance_wm2: h.solar_irradiance_wm2,
        grid_mode: decision.grid_mode,
      });

      totalSolarGen += step.solar_generation_kw;
      totalSolarUsed += step.solar_used_kw;
      totalSolarCurtailed += step.solar_curtailed_kw;
      totalGridImport += step.grid_import_kw;

      if (step.battery_power_kw > 0) {
        totalDischargedKwh += step.battery_power_kw;
      }

      const soc = step.final_soc_pct;
      if (soc < minSoc) minSoc = soc;
      if (soc > maxSoc) maxSoc = soc;
    }

    const selfConsumptionPct =
      totalSolarGen > 0 ? (totalSolarUsed / totalSolarGen) * 100 : 0;

    const cycles = totalDischargedKwh / (scenario.config.capacity_kwh || 1);

    return {
      id: `whatif-${idx}-${Date.now().toString(36)}`,
      scenarioName: scenario.name,
      isHypothetical: true,
      batteryConfig: { ...scenario.config },
      totalSolarGeneratedKwh: Number(totalSolarGen.toFixed(1)),
      totalSolarUsedKwh: Number(totalSolarUsed.toFixed(1)),
      totalSolarCurtailedKwh: Number(totalSolarCurtailed.toFixed(1)),
      totalGridImportKwh: Number(totalGridImport.toFixed(1)),
      renewableSelfConsumptionPct: Number(selfConsumptionPct.toFixed(1)),
      criticalOverloadsCount: criticalOverloads,
      batteryCyclesEquivalent: Number(cycles.toFixed(2)),
      minSocObservedPct: Number(minSoc.toFixed(1)),
      maxSocObservedPct: Number(maxSoc.toFixed(1)),
      peakDemandSeenKw: Number(peakDemand.toFixed(1)),
    };
  });
}
