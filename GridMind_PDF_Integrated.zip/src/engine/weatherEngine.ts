/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Open-Meteo Weather-Aware Telemetry Engine
 * HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine
 * 
 * Fetches real hourly forecasts from Open-Meteo API and maps them
 * strictly to the HackSphere 3.0 TelemetryRow format.
 */

import type { TelemetryRow, WeatherForecastSource } from '../types/microgrid.ts';

export async function fetchLiveWeatherTelemetry(
  latitude = 28.6139, // Default: New Delhi / HackSphere Region
  longitude = 77.2090
): Promise<WeatherForecastSource> {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&hourly=temperature_2m,relative_humidity_2m,shortwave_radiation,direct_normal_irradiance,diffuse_radiation&forecast_days=2&timezone=auto`;

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 6000);

    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeout);

    if (!res.ok) {
      throw new Error(`Open-Meteo API returned HTTP status ${res.status}`);
    }

    const data = await res.json();
    if (!data.hourly || !Array.isArray(data.hourly.time)) {
      throw new Error('Malformed Open-Meteo response structure');
    }

    const times: string[] = data.hourly.time;
    const temps: number[] = data.hourly.temperature_2m || [];
    const hums: number[] = data.hourly.relative_humidity_2m || [];
    const rads: number[] = data.hourly.shortwave_radiation || [];
    const dnirads: number[] = data.hourly.direct_normal_irradiance || [];
    const diffrads: number[] = data.hourly.diffuse_radiation || [];

    // Take next 24 consecutive hours starting from now/next hour
    const nowIso = new Date().toISOString();
    let startIdx = times.findIndex(t => t >= nowIso.slice(0, 13));
    if (startIdx < 0) startIdx = 0;
    const endIdx = Math.min(startIdx + 24, times.length);

    const rows: TelemetryRow[] = [];
    for (let i = startIdx; i < endIdx; i++) {
      const solar =
        rads[i] !== undefined && rads[i] > 0
          ? rads[i]
          : Math.max(0, (dnirads[i] || 0) + (diffrads[i] || 0));

      rows.push({
        timestamp: new Date(times[i]).toISOString(),
        ambient_temp_c: Number((temps[i] ?? 22.0).toFixed(1)),
        humidity_pct: Number((hums[i] ?? 60.0).toFixed(0)),
        solar_irradiance_wm2: Number(Math.max(0, solar).toFixed(1)),
      });
    }

    return {
      source: 'Open-Meteo',
      latitude,
      longitude,
      timezone: data.timezone || 'auto',
      generatedAt: new Date().toISOString(),
      rows,
    };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    // Graceful fallback to diurnal synthetic telemetry
    const now = new Date();
    const fallbackRows: TelemetryRow[] = [];
    for (let h = 0; h < 24; h++) {
      const d = new Date(now.getTime() + h * 3600000);
      const hour = d.getUTCHours();
      const temp = 22 + 8 * Math.sin((Math.PI * (hour - 8)) / 12);
      const hum = 60 - 20 * Math.sin((Math.PI * (hour - 8)) / 12);
      const solar = hour >= 6 && hour <= 18 ? 850 * Math.sin((Math.PI * (hour - 6)) / 12) : 0;
      fallbackRows.push({
        timestamp: d.toISOString(),
        ambient_temp_c: Number(temp.toFixed(1)),
        humidity_pct: Number(hum.toFixed(0)),
        solar_irradiance_wm2: Number(solar.toFixed(1)),
      });
    }

    return {
      source: 'Bundled Telemetry Fallback',
      latitude,
      longitude,
      timezone: 'UTC',
      generatedAt: new Date().toISOString(),
      rows: fallbackRows,
    };
  }
}
