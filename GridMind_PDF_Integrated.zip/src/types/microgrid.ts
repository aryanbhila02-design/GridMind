/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind - HackSphere 3.0 Type Definitions
 */

export type GridMode = 'Main Grid Mode' | 'Renewable Storage Mode';

export type ForecastingMode =
  | 'live_quickml'               // Genuine prediction from published QuickML endpoint
  | 'local_baseline_demo'        // Local Rule-Based Baseline (Demonstration Mode)
  | 'quickml_failed_fallback';   // QuickML attempted, failed; fallback used with prominent notice

export type QuickMLConnectionStatus =
  | 'not_configured'             // Endpoint URL empty
  | 'config_incomplete'          // Missing token or project ID
  | 'connection_failed'          // Request timed out, returned 4xx/5xx, or invalid payload
  | 'connected_verified'         // Health check or single inference returned valid numeric prediction
  | 'live_verified';             // Live 24h batch verified against schema

export interface TelemetryRow {
  timestamp: string;
  ambient_temp_c: number;
  humidity_pct: number;
  solar_irradiance_wm2: number;
  target_demand_kw?: number; // Present in training data, omitted in test input
}

export interface ValidationError {
  row: number;
  timestamp?: string;
  field: string;
  message: string;
  rawValue?: string;
}

export interface ValidationSummary {
  totalRows: number;
  validRows: number;
  rejectedRows: number;
  hasTargetDemand: boolean;
  startDate?: string;
  endDate?: string;
  errors: ValidationError[];
  cleaningPolicy: string;
  isChronological: boolean;
  duplicateCount: number;
  datasetRole?: 'official_training' | 'official_test_input' | 'bundled_demo' | 'custom_upload';
}

export interface ForecastHourResult {
  timestamp: string;
  hour: number;
  ambient_temp_c: number;
  humidity_pct: number;
  solar_irradiance_wm2: number;
  predicted_demand_kw: number;
  actual_demand_kw?: number;
  grid_mode: GridMode;
  critical_overload: boolean;
  decision_reason: string;
  battery_soc_pct: number;
  battery_soc_kwh: number;
  battery_power_kw: number; // positive = discharging to load, negative = charging
  grid_import_kw: number;
  solar_used_kw: number;
  solar_curtailed_kw: number;
}

export interface BatteryConfig {
  capacity_kwh: number;        // e.g. 500 kWh
  initial_soc_pct: number;     // e.g. 65%
  max_charge_kw: number;       // e.g. 100 kW
  max_discharge_kw: number;    // e.g. 120 kW
  efficiency_pct: number;      // e.g. 92% roundtrip
  min_soc_pct: number;         // e.g. 15% reserve buffer
  low_soc_warning_pct: number; // e.g. 20%
}

export interface GridEvent {
  id: string;
  timestamp: string;
  type: 'MODE_CHANGE' | 'CRITICAL_OVERLOAD' | 'LOW_BATTERY' | 'FORECAST_RUN' | 'DATA_UPLOAD' | 'QUICKML_STATUS';
  severity: 'info' | 'warning' | 'critical';
  title: string;
  detail: string;
  demand_kw?: number;
  mode?: GridMode;
}

export interface ModelBenchmark {
  modelName: string;
  modelType: string;
  rmse: number | null;
  mae: number | null;
  r2: number | null;
  peakErrorPct: number | null;
  validationMethod: string;
  isProductionCandidate: boolean;
  isMeasured: boolean;
  statusNote: string;
}

export interface QuickMLConfig {
  endpointUrl: string;
  apiKey: string;
  projectId: string;
  catalystEnv: 'development' | 'production';
  timeoutMs: number;
  isConnected: boolean;
  connectionStatus: QuickMLConnectionStatus;
  lastTestedAt?: string;
  statusMessage?: string;
}

// -------------------------------------------------------------
// P1: ML Research Lab Types
// -------------------------------------------------------------

export interface TrainingLossPoint {
  epoch: number;
  trainLoss: number;
  valLoss?: number;
}

export interface GradientDescentResult {
  weights: number[]; // [temp, humidity, solar, sin_hour, cos_hour]
  bias: number;
  featureNames: string[];
  featureMeans: number[];
  featureStds: number[];
  trainRmse: number;
  valRmse: number;
  r2: number;
  lossHistory: TrainingLossPoint[];
  converged: boolean;
  epochsRun: number;
  learningRate: number;
  batchSize: number;
  durationMs: number;
}

export interface PerceptronResult {
  weights: number[]; // [temp, solar, hour] or similar normalized features
  bias: number;
  featureNames: string[];
  thresholdKw: number; // e.g. 160 kW separating high demand vs normal
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  truePositives: number;
  trueNegatives: number;
  falsePositives: number;
  falseNegatives: number;
  epochsRun: number;
  isLinearlySeparable: boolean;
  boundaryEquation: string; // e.g. "w1*x1 + w2*x2 + b = 0"
  pedagogicalNote: string;
}

export interface NeuralNetResult {
  architecture: string; // e.g. "5 -> 16 (ReLU) -> 8 (ReLU) -> 1 (Linear)"
  trainRmse: number;
  valRmse: number;
  trainMae: number;
  valMae: number;
  r2: number;
  lossHistory: TrainingLossPoint[];
  epochsRun: number;
  learningRate: number;
  batchSize: number;
  durationMs: number;
  finiteDiffGradError: number; // numerical vs analytical backpropagation diff
  weightsSummary: {
    layer: string;
    shape: string;
    meanWeight: number;
    stdWeight: number;
  }[];
}

export interface ModelExperimentRecord {
  id: string;
  timestamp: string;
  modelType: 'Ridge' | 'GradientDescent' | 'Perceptron' | 'MLP' | 'Baseline';
  modelName: string;
  hyperparameters: Record<string, string | number>;
  metrics: {
    rmse?: number;
    mae?: number;
    r2?: number;
    accuracy?: number;
  };
  durationMs: number;
  status: 'completed' | 'failed';
  notes: string;
}

// -------------------------------------------------------------
// P2: Explainability & Peak Intelligence Types
// -------------------------------------------------------------

export interface FeatureImportanceScore {
  feature: string;
  label: string;
  deltaRmse: number;
  relativeImportancePct: number;
  directionOfInfluence: 'positive' | 'negative' | 'non_linear';
  domainRationale: string;
}

export interface ExplainabilityResult {
  baselineRmse: number;
  evaluatedOn: string;
  sampleCount: number;
  importances: FeatureImportanceScore[];
  methodology: string;
  causalityCaveat: string;
}

export interface PeakIntelligenceSummary {
  peakDemandKw: number;
  peakHour: number;
  peakTimestamp: string;
  baseLoadKw: number;
  baseHour: number;
  averageDemandKw: number;
  loadFactor: number;
  hoursOver160Kw: number;
  hoursCriticalOverload200Kw: number;
  maxRampRateKwPerHour: number;
  peakWindowHours: number[];
  storagePeakReductionKw: number;
  curtailedSolarKwh: number;
}

// -------------------------------------------------------------
// P3: Conformal Prediction Uncertainty & Weather Types
// -------------------------------------------------------------

export interface UncertaintyIntervalPoint {
  timestamp: string;
  hour: number;
  predictedDemandKw: number;
  lower80Kw: number;
  upper80Kw: number;
  lower90Kw: number;
  upper90Kw: number;
  lower95Kw: number;
  upper95Kw: number;
  actualDemandKw?: number;
  isWithin90Pct: boolean;
}

export interface UncertaintyAnalysisResult {
  calibrationSampleCount: number;
  calibrationRmse: number;
  coverage90Pct: number; // Empirical coverage achieved
  quantile90Kw: number;
  quantile95Kw: number;
  quantile80Kw: number;
  intervals: UncertaintyIntervalPoint[];
  methodDescription: string;
}

export interface WeatherForecastSource {
  source: 'Open-Meteo' | 'Bundled Telemetry Fallback';
  latitude: number;
  longitude: number;
  timezone: string;
  generatedAt: string;
  rows: TelemetryRow[];
}

// -------------------------------------------------------------
// P4: What-If Energy Simulation Types
// -------------------------------------------------------------

export interface WhatIfScenarioSummary {
  id: string;
  scenarioName: string;
  isHypothetical: true;
  batteryConfig: BatteryConfig;
  totalSolarGeneratedKwh: number;
  totalSolarUsedKwh: number;
  totalSolarCurtailedKwh: number;
  totalGridImportKwh: number;
  renewableSelfConsumptionPct: number;
  criticalOverloadsCount: number;
  batteryCyclesEquivalent: number;
  minSocObservedPct: number;
  maxSocObservedPct: number;
  peakDemandSeenKw: number;
}

export interface ResearchPaperReference {
  id: string;
  title: string;
  authors: string;
  year: number;
  venueOrUrl: string;
  coreProblem: string;
  keyInnovation: string;
  relevanceToGridMind: string;
  category: 'Time Series' | 'Microgrid Control' | 'Deep Learning' | 'Conformal Prediction' | 'Battery Storage';
}
