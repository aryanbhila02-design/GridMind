/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — 24-Hour Microgrid Demand Visualization
 * Features exact reference lines at 160 kW and 200 kW, colored alert bands,
 * and hover tooltip inspection.
 */

import React, { useState } from 'react';
import { ForecastHourResult } from '../types/microgrid';

interface DemandChartProps {
  data: ForecastHourResult[];
  showActuals?: boolean;
}

export const DemandChart: React.FC<DemandChartProps> = ({ data, showActuals = false }) => {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  if (!data || data.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center bg-slate-900/40 border border-slate-800 rounded-lg text-slate-400 text-sm">
        No forecast data available
      </div>
    );
  }

  // Chart Dimensions
  const svgWidth = 840;
  const svgHeight = 280;
  const padding = { top: 24, right: 30, bottom: 40, left: 55 };
  const graphWidth = svgWidth - padding.left - padding.right;
  const graphHeight = svgHeight - padding.top - padding.bottom;

  // Scales
  const maxDemand = Math.max(240, ...data.map(d => d.predicted_demand_kw));
  const minDemand = 0;

  const getX = (index: number) => {
    if (data.length <= 1) return padding.left;
    return padding.left + (index / (data.length - 1)) * graphWidth;
  };

  const getY = (val: number) => {
    return padding.top + graphHeight - ((val - minDemand) / (maxDemand - minDemand)) * graphHeight;
  };

  // Generate SVG Path for predicted demand
  const points = data.map((d, i) => `${getX(i)},${getY(d.predicted_demand_kw)}`);
  const pathD = `M ${points.join(' L ')}`;
  const areaD = `${pathD} L ${getX(data.length - 1)},${getY(0)} L ${getX(0)},${getY(0)} Z`;

  // Path for actual demand if present
  const hasActuals = showActuals && data.some(d => d.actual_demand_kw !== undefined);
  let actualsPathD = '';
  if (hasActuals) {
    const actPoints = data
      .filter(d => d.actual_demand_kw !== undefined)
      .map((d, i) => `${getX(i)},${getY(d.actual_demand_kw!)}`);
    actualsPathD = `M ${actPoints.join(' L ')}`;
  }

  // Y-axis tick values
  const yTicks = [0, 50, 100, 160, 200, 240];

  return (
    <div className="w-full relative">
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3 text-xs">
        <div className="flex items-center gap-4 text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-cyan-400 inline-block"></span>
            <span className="text-slate-300 font-medium">Predicted Demand (kW)</span>
          </div>
          {hasActuals && (
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-emerald-400 inline-block border-t border-dashed"></span>
              <span className="text-slate-300 font-medium">Observed Actual</span>
            </div>
          )}
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-0.5 bg-amber-400/80 inline-block"></span>
            <span>160 kW Renewable Storage Threshold</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-0.5 bg-rose-500 inline-block"></span>
            <span>200 kW Critical Overload Limit</span>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <svg
          viewBox={`0 0 ${svgWidth} ${svgHeight}`}
          className="w-full h-auto select-none font-mono text-[10px]"
        >
          <defs>
            <linearGradient id="demandGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
            </linearGradient>
            <linearGradient id="overloadZone" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.12" />
              <stop offset="100%" stopColor="#f43f5e" stopOpacity="0.02" />
            </linearGradient>
          </defs>

          {/* Critical Overload Zone (> 200 kW) */}
          <rect
            x={padding.left}
            y={getY(maxDemand)}
            width={graphWidth}
            height={getY(200) - getY(maxDemand)}
            fill="url(#overloadZone)"
          />

          {/* Horizontal Grid lines */}
          {yTicks.map(val => (
            <g key={val}>
              <line
                x1={padding.left}
                y1={getY(val)}
                x2={svgWidth - padding.right}
                y2={getY(val)}
                stroke={val === 160 ? '#f59e0b' : val === 200 ? '#f43f5e' : '#1e293b'}
                strokeWidth={val === 160 || val === 200 ? 1.5 : 1}
                strokeDasharray={val === 160 || val === 200 ? '4 3' : undefined}
                strokeOpacity={val === 160 || val === 200 ? 0.8 : 0.6}
              />
              <text
                x={padding.left - 8}
                y={getY(val) + 3}
                fill={val === 160 ? '#fbbf24' : val === 200 ? '#fb7185' : '#64748b'}
                textAnchor="end"
                className="font-medium"
              >
                {val} kW
              </text>
            </g>
          ))}

          {/* Evening Window Highlight (18:00 - 22:00) */}
          {data.map((d, i) => {
            if (d.hour >= 18 && d.hour <= 22) {
              const xStart = Math.max(padding.left, getX(i) - (graphWidth / (data.length - 1)) / 2);
              const xEnd = Math.min(svgWidth - padding.right, getX(i) + (graphWidth / (data.length - 1)) / 2);
              return (
                <rect
                  key={`evening-${i}`}
                  x={xStart}
                  y={padding.top}
                  width={xEnd - xStart}
                  height={graphHeight}
                  fill="#0284c7"
                  fillOpacity="0.06"
                />
              );
            }
            return null;
          })}

          {/* Area under curve */}
          <path d={areaD} fill="url(#demandGradient)" />

          {/* Line Path */}
          <path
            d={pathD}
            fill="none"
            stroke="#22d3ee"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Actuals Path */}
          {hasActuals && (
            <path
              d={actualsPathD}
              fill="none"
              stroke="#34d399"
              strokeWidth="2"
              strokeDasharray="4 4"
            />
          )}

          {/* Data Points */}
          {data.map((d, i) => {
            const cx = getX(i);
            const cy = getY(d.predicted_demand_kw);
            const isHovered = hoveredIndex === i;
            const isOverload = d.critical_overload;
            const isStorage = d.grid_mode === 'Renewable Storage Mode';

            return (
              <g key={`pt-${i}`} className="cursor-pointer" onMouseEnter={() => setHoveredIndex(i)} onMouseLeave={() => setHoveredIndex(null)}>
                {/* Invisible hover trigger area */}
                <rect
                  x={cx - 14}
                  y={padding.top}
                  width={28}
                  height={graphHeight}
                  fill="transparent"
                />

                {/* Vertical hover indicator */}
                {isHovered && (
                  <line
                    x1={cx}
                    y1={padding.top}
                    x2={cx}
                    y2={padding.top + graphHeight}
                    stroke="#38bdf8"
                    strokeWidth="1"
                    strokeDasharray="2 2"
                  />
                )}

                {/* Point circle */}
                <circle
                  cx={cx}
                  cy={cy}
                  r={isHovered ? 5.5 : isOverload ? 4.5 : 3}
                  fill={isOverload ? '#f43f5e' : isStorage ? '#38bdf8' : '#0284c7'}
                  stroke={isOverload ? '#ffe4e6' : '#082f49'}
                  strokeWidth={isHovered ? 2 : 1}
                />
              </g>
            );
          })}

          {/* X-axis labels */}
          {data.map((d, i) => {
            // Label every 2-3 hours for clean spacing
            if (i % 2 === 0 || i === data.length - 1) {
              const cx = getX(i);
              return (
                <text
                  key={`xlab-${i}`}
                  x={cx}
                  y={padding.top + graphHeight + 18}
                  fill="#94a3b8"
                  textAnchor="middle"
                >
                  {`${d.hour.toString().padStart(2, '0')}:00`}
                </text>
              );
            }
            return null;
          })}
        </svg>
      </div>

      {/* Floating Hover Tooltip */}
      {hoveredIndex !== null && data[hoveredIndex] && (
        <div
          className="absolute z-10 pointer-events-none bg-slate-900/95 border border-slate-700/80 rounded-md p-2.5 shadow-xl backdrop-blur-sm text-xs font-sans"
          style={{
            left: `${Math.min(78, Math.max(12, (hoveredIndex / (data.length - 1)) * 100))}%`,
            top: '20px',
            transform: 'translateX(-50%)',
          }}
        >
          <div className="flex items-center justify-between gap-3 font-mono border-b border-slate-800 pb-1.5 mb-1.5">
            <span className="font-semibold text-slate-200">
              {data[hoveredIndex].hour}:00 ({data[hoveredIndex].timestamp.split('T')[0]})
            </span>
            <span
              className={`text-[10px] px-1.5 py-0.5 rounded ${
                data[hoveredIndex].grid_mode === 'Renewable Storage Mode'
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-800/60'
                  : 'bg-slate-800 text-slate-300'
              }`}
            >
              {data[hoveredIndex].grid_mode}
            </span>
          </div>

          <div className="space-y-1 font-mono text-[11px]">
            <div className="flex justify-between gap-4">
              <span className="text-slate-400">Demand:</span>
              <span className="font-bold text-cyan-300 tabular-nums">
                {data[hoveredIndex].predicted_demand_kw} kW
              </span>
            </div>
            {data[hoveredIndex].actual_demand_kw !== undefined && (
              <div className="flex justify-between gap-4">
                <span className="text-slate-400">Actual:</span>
                <span className="font-semibold text-emerald-400 tabular-nums">
                  {data[hoveredIndex].actual_demand_kw} kW
                </span>
              </div>
            )}
            <div className="flex justify-between gap-4">
              <span className="text-slate-400">Solar Irradiance:</span>
              <span className="text-amber-300 tabular-nums">
                {data[hoveredIndex].solar_irradiance_wm2} W/m²
              </span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-slate-400">Ambient Temp:</span>
              <span className="text-slate-200 tabular-nums">
                {data[hoveredIndex].ambient_temp_c}°C
              </span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-slate-400">Battery SOC:</span>
              <span className="text-emerald-400 tabular-nums">
                {data[hoveredIndex].battery_soc_pct}% ({data[hoveredIndex].battery_soc_kwh} kWh)
              </span>
            </div>
            {data[hoveredIndex].critical_overload && (
              <div className="mt-1 pt-1 border-t border-rose-900/50 text-rose-400 font-semibold text-[10px] flex items-center gap-1">
                <span>⚠️ CRITICAL OVERLOAD (&gt;200 kW)</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
