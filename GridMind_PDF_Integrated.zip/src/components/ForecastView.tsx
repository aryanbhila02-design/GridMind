/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — 24-Hour Electricity Demand Detailed Forecast View
 */

import React, { useState } from 'react';
import {
  Download,
  Filter,
  Search,
  Sun,
  Thermometer,
  Droplets,
  Zap,
  AlertTriangle,
  ArrowUpDown,
  CheckCircle2,
} from 'lucide-react';
import { ForecastHourResult } from '../types/microgrid';
import { DemandChart } from './DemandChart';
import { exportPredictionsToCsv } from '../engine/telemetryValidator';

interface ForecastViewProps {
  forecastData: ForecastHourResult[];
  modelUsed: string;
}

export const ForecastView: React.FC<ForecastViewProps> = ({ forecastData, modelUsed }) => {
  const [filterMode, setFilterMode] = useState<'all' | 'renewable' | 'grid' | 'overload'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortField, setSortField] = useState<'hour' | 'demand' | 'temp' | 'solar'>('hour');
  const [sortAsc, setSortAsc] = useState(true);

  // Filter & Sort
  const filteredData = forecastData.filter(d => {
    if (filterMode === 'renewable' && d.grid_mode !== 'Renewable Storage Mode') return false;
    if (filterMode === 'grid' && d.grid_mode !== 'Main Grid Mode') return false;
    if (filterMode === 'overload' && !d.critical_overload) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        d.hour.toString().includes(q) ||
        d.grid_mode.toLowerCase().includes(q) ||
        d.decision_reason.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const sortedData = [...filteredData].sort((a, b) => {
    let diff = 0;
    if (sortField === 'hour') diff = a.hour - b.hour;
    else if (sortField === 'demand') diff = a.predicted_demand_kw - b.predicted_demand_kw;
    else if (sortField === 'temp') diff = a.ambient_temp_c - b.ambient_temp_c;
    else if (sortField === 'solar') diff = a.solar_irradiance_wm2 - b.solar_irradiance_wm2;
    return sortAsc ? diff : -diff;
  });

  const handleDownloadCsv = () => {
    const csv = exportPredictionsToCsv(
      forecastData.map(d => ({ timestamp: d.timestamp, target_demand_kw: d.predicted_demand_kw }))
    );
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `microgrid_24h_predictions_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadJson = () => {
    const jsonStr = JSON.stringify(forecastData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `microgrid_forecast_export.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Forecast Chart Panel */}
      <div className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
          <div>
            <h2 className="text-sm font-semibold text-white tracking-tight">
              24-Hour Horizon Load Trajectory
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Engineered regression predicting hourly demand from ambient temperature, humidity, and solar irradiance.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadCsv}
              className="px-3 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Predictions CSV</span>
            </button>
            <button
              onClick={handleDownloadJson}
              className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5 text-slate-400" />
              <span>JSON</span>
            </button>
          </div>
        </div>

        <DemandChart data={forecastData} showActuals={true} />
      </div>

      {/* Hourly Data Table & Controls */}
      <div className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
          {/* Filter tabs */}
          <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-lg border border-slate-800">
            <button
              onClick={() => setFilterMode('all')}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                filterMode === 'all'
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-800/60'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Hours ({forecastData.length})
            </button>
            <button
              onClick={() => setFilterMode('renewable')}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                filterMode === 'renewable'
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-800/60'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Renewable Storage
            </button>
            <button
              onClick={() => setFilterMode('grid')}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                filterMode === 'grid'
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-800/60'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Main Grid
            </button>
            <button
              onClick={() => setFilterMode('overload')}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                filterMode === 'overload'
                  ? 'bg-rose-950 text-rose-300 border border-rose-800'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Overload Alerts (≥200 kW)
            </button>
          </div>

          {/* Search bar */}
          <div className="relative w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
            <input
              type="text"
              placeholder="Search hour or keyword..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-hidden focus:border-cyan-500"
            />
          </div>
        </div>

        {/* Full Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-sans text-[11px]">
                <th
                  onClick={() => {
                    if (sortField === 'hour') setSortAsc(!sortAsc);
                    else { setSortField('hour'); setSortAsc(true); }
                  }}
                  className="py-2.5 px-3 cursor-pointer hover:text-slate-200"
                >
                  <div className="flex items-center gap-1">
                    <span>Hour</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => {
                    if (sortField === 'demand') setSortAsc(!sortAsc);
                    else { setSortField('demand'); setSortAsc(false); }
                  }}
                  className="py-2.5 px-3 text-right cursor-pointer hover:text-slate-200"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Predicted Demand</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  onClick={() => {
                    if (sortField === 'temp') setSortAsc(!sortAsc);
                    else { setSortField('temp'); setSortAsc(false); }
                  }}
                  className="py-2.5 px-3 text-right cursor-pointer hover:text-slate-200"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Ambient Temp</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-2.5 px-3 text-right">Humidity</th>
                <th
                  onClick={() => {
                    if (sortField === 'solar') setSortAsc(!sortAsc);
                    else { setSortField('solar'); setSortAsc(false); }
                  }}
                  className="py-2.5 px-3 text-right cursor-pointer hover:text-slate-200"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Solar Irradiance</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-2.5 px-3">Operating Mode</th>
                <th className="py-2.5 px-3">Alert</th>
                <th className="py-2.5 px-3 text-right">Battery SOC</th>
                <th className="py-2.5 px-3 font-sans">Decision Logic</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {sortedData.map(r => (
                <tr key={`tbl-${r.hour}`} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-2.5 px-3 font-bold text-slate-200">
                    {r.hour.toString().padStart(2, '0')}:00
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-cyan-300 tabular-nums">
                    {r.predicted_demand_kw} kW
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-300 tabular-nums">
                    {r.ambient_temp_c}°C
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-400 tabular-nums">
                    {r.humidity_pct}%
                  </td>
                  <td className="py-2.5 px-3 text-right text-amber-300 tabular-nums">
                    {r.solar_irradiance_wm2} W/m²
                  </td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded ${
                        r.grid_mode === 'Renewable Storage Mode'
                          ? 'bg-cyan-950 text-cyan-300 border border-cyan-800/60'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {r.grid_mode}
                    </span>
                  </td>
                  <td className="py-2.5 px-3">
                    {r.critical_overload ? (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 flex items-center gap-1 w-max">
                        <AlertTriangle className="w-3 h-3" /> Overload
                      </span>
                    ) : (
                      <span className="text-[10px] text-emerald-400">Normal</span>
                    )}
                  </td>
                  <td className="py-2.5 px-3 text-right text-emerald-300 tabular-nums">
                    {r.battery_soc_pct}%
                  </td>
                  <td className="py-2.5 px-3 font-sans text-slate-400 text-[11px] truncate max-w-xs">
                    {r.decision_reason}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
