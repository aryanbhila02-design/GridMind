/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — BESS Battery Storage & What-If Scenario View
 * HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine
 * 
 * Features:
 * - Real-time State of Charge (SoC) tracking & 15% reserve buffer monitoring
 * - 24-Hour Battery power charge/discharge and grid import metrics
 * - What-If Side-by-Side Simulation (Baseline vs Scaled vs Degraded)
 * - Strict 'Hypothetical Scenario — Not a Live Grid State' labeling
 */

import React, { useState, useEffect } from 'react';
import {
  BatteryCharging,
  Battery,
  Zap,
  Sun,
  ShieldCheck,
  AlertTriangle,
  Sliders,
  CheckCircle2,
  TrendingDown,
  RefreshCw,
  GitBranch,
  HelpCircle,
} from 'lucide-react';
import type { BatteryConfig, ForecastHourResult, WhatIfScenarioSummary } from '../types/microgrid.ts';
import { BatteryChart } from './BatteryChart.tsx';

interface BatteryViewProps {
  batteryConfig: BatteryConfig;
  forecastData: ForecastHourResult[];
}

export const BatteryView: React.FC<BatteryViewProps> = ({
  batteryConfig,
  forecastData,
}) => {
  const [whatIfScenarios, setWhatIfScenarios] = useState<WhatIfScenarioSummary[]>([]);
  const [loadingScenarios, setLoadingScenarios] = useState<boolean>(false);

  // Fetch what-if simulation from backend
  const runWhatIf = () => {
    setLoadingScenarios(true);
    fetch('/api/ml/what-if', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    })
      .then(res => res.json())
      .then(data => {
        if (data.scenarios) {
          setWhatIfScenarios(data.scenarios);
        }
      })
      .catch(() => {})
      .finally(() => {
        setLoadingScenarios(false);
      });
  };

  useEffect(() => {
    runWhatIf();
  }, [batteryConfig, forecastData]);

  // Calculate live cumulative metrics across 24h
  const totalDischargedKwh = forecastData.reduce(
    (sum, r) => (r.battery_power_kw > 0 ? sum + r.battery_power_kw : sum),
    0
  );
  const totalChargedKwh = forecastData.reduce(
    (sum, r) => (r.battery_power_kw < 0 ? sum + Math.abs(r.battery_power_kw) : sum),
    0
  );
  const totalSolarUsedKwh = forecastData.reduce((sum, r) => sum + r.solar_used_kw, 0);
  const totalSolarCurtailedKwh = forecastData.reduce((sum, r) => sum + r.solar_curtailed_kw, 0);
  const totalGridImportKwh = forecastData.reduce((sum, r) => sum + r.grid_import_kw, 0);

  const currentPoint = forecastData[0] || {
    battery_soc_pct: batteryConfig.initial_soc_pct,
    battery_soc_kwh: (batteryConfig.initial_soc_pct / 100) * batteryConfig.capacity_kwh,
    battery_power_kw: 0,
  };

  return (
    <div className="space-y-6 max-w-6xl">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-100 flex items-center gap-2">
          <BatteryCharging className="w-6 h-6 text-cyan-400" />
          Battery Energy Storage System (BESS)
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          Simulating microgrid electrochemical storage dynamics, state-of-charge (SoC), C-rate limits, and what-if capacity scenarios.
        </p>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <span className="text-xs text-slate-400">Current SoC</span>
          <div className="text-2xl font-bold font-mono text-cyan-400 mt-1">
            {currentPoint.battery_soc_pct.toFixed(1)}%
          </div>
          <span className="text-[11px] text-slate-500 mt-0.5 block">
            {currentPoint.battery_soc_kwh.toFixed(1)} / {batteryConfig.capacity_kwh} kWh
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <span className="text-xs text-slate-400">24h Total Discharge</span>
          <div className="text-2xl font-bold font-mono text-amber-400 mt-1">
            {totalDischargedKwh.toFixed(1)} <span className="text-xs font-normal text-slate-400">kWh</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-0.5 block">
            Peak shave offset
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <span className="text-xs text-slate-400">Solar Energy Stored</span>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
            {totalChargedKwh.toFixed(1)} <span className="text-xs font-normal text-slate-400">kWh</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-0.5 block">
            From daytime photovoltaic surplus
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <span className="text-xs text-slate-400">Solar Curtailed</span>
          <div className="text-2xl font-bold font-mono text-rose-400 mt-1">
            {totalSolarCurtailedKwh.toFixed(1)} <span className="text-xs font-normal text-slate-400">kWh</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-0.5 block">
            Surplus exceeding BESS C-rate
          </span>
        </div>
      </div>

      {/* Main SoC Chart */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
        <h3 className="font-semibold text-slate-200 text-sm mb-4">
          24-Hour State-of-Charge & Power Profile
        </h3>
        <BatteryChart data={forecastData} />
      </div>

      {/* P4: What-If Energy Scenario Simulation Section */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 pb-3 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <GitBranch className="w-5 h-5 text-purple-400" />
              <h3 className="font-semibold text-slate-200 text-sm">
                What-If Storage Capacity Simulation (P4)
              </h3>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Simulating alternative battery sizing against the current 24-hour load and solar profile.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {/* Required prominent Hypothetical badge */}
            <span className="text-[11px] px-3 py-1 rounded-full font-sans font-semibold bg-amber-500/10 text-amber-300 border border-amber-500/30 flex items-center gap-1.5 shadow-sm">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              Hypothetical Scenario — Not a Live Grid State
            </span>

            <button
              onClick={runWhatIf}
              disabled={loadingScenarios}
              className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg flex items-center gap-1 cursor-pointer border border-slate-700"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingScenarios ? 'animate-spin' : ''}`} />
              Re-simulate
            </button>
          </div>
        </div>

        {/* Side-by-Side Comparison Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {whatIfScenarios.map((sc, idx) => (
            <div
              key={sc.id || idx}
              className={`p-4 rounded-xl border flex flex-col justify-between space-y-4 ${
                idx === 0
                  ? 'bg-slate-950 border-cyan-500/30 ring-1 ring-cyan-500/20'
                  : 'bg-slate-950/60 border-slate-800'
              }`}
            >
              <div>
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-slate-200 text-sm">{sc.scenarioName}</h4>
                  {idx === 0 && (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                      Active
                    </span>
                  )}
                </div>
                <div className="text-xs font-mono text-slate-400 mt-1">
                  Cap: {sc.batteryConfig.capacity_kwh} kWh | Rate: ±{sc.batteryConfig.max_discharge_kw} kW
                </div>
              </div>

              <div className="space-y-2 text-xs font-mono">
                <div className="flex justify-between py-1 border-b border-slate-900">
                  <span className="text-slate-400">Solar Self-Consumption</span>
                  <span className="text-emerald-400 font-bold">{sc.renewableSelfConsumptionPct}%</span>
                </div>

                <div className="flex justify-between py-1 border-b border-slate-900">
                  <span className="text-slate-400">Curtailed Solar</span>
                  <span className="text-rose-400 font-bold">{sc.totalSolarCurtailedKwh} kWh</span>
                </div>

                <div className="flex justify-between py-1 border-b border-slate-900">
                  <span className="text-slate-400">Grid Import Required</span>
                  <span className="text-cyan-400 font-bold">{sc.totalGridImportKwh} kWh</span>
                </div>

                <div className="flex justify-between py-1 border-b border-slate-900">
                  <span className="text-slate-400">Critical Overloads</span>
                  <span className={`font-bold ${sc.criticalOverloadsCount > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                    {sc.criticalOverloadsCount} events
                  </span>
                </div>

                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Battery Cycles</span>
                  <span className="text-purple-400 font-bold">{sc.batteryCyclesEquivalent}</span>
                </div>
              </div>

              <div className="text-[10px] text-slate-500 pt-1 border-t border-slate-900 text-center font-sans italic">
                Hypothetical Scenario Simulation
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
