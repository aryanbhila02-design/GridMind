/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Event History & Transition Log View
 */

import React, { useState, useEffect } from 'react';
import {
  History,
  AlertTriangle,
  Info,
  AlertCircle,
  Download,
  Search,
} from 'lucide-react';
import { GridEvent } from '../types/microgrid';

interface EventsViewProps {
  initialEvents: GridEvent[];
}

export const EventsView: React.FC<EventsViewProps> = ({ initialEvents }) => {
  const [events, setEvents] = useState<GridEvent[]>(initialEvents);
  const [severityFilter, setSeverityFilter] = useState<'all' | 'info' | 'warning' | 'critical'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetch('/api/grid/events')
      .then(res => res.json())
      .then(data => {
        if (data.events && Array.isArray(data.events)) {
          setEvents(data.events);
        }
      })
      .catch(() => {});
  }, []);

  const filteredEvents = events.filter(e => {
    if (severityFilter !== 'all' && e.severity !== severityFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        e.title.toLowerCase().includes(q) ||
        e.detail.toLowerCase().includes(q) ||
        e.timestamp.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const exportEventsCsv = () => {
    const header = 'id,timestamp,type,severity,title,detail\n';
    const lines = filteredEvents.map(
      e => `"${e.id}","${e.timestamp}","${e.type}","${e.severity}","${e.title}","${e.detail.replace(/"/g, '""')}"`
    );
    const blob = new Blob([header + lines.join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `microgrid_event_history_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-semibold text-white tracking-tight mb-1 flex items-center gap-2">
            <History className="w-4 h-4 text-cyan-400" />
            <span>Microgrid Transition & Safety Event Audit Log</span>
          </h2>
          <p className="text-xs text-slate-400 max-w-2xl">
            Real-time chronological telemetry log of operating mode changes, critical overload alerts (≥200 kW),
            battery threshold triggers, and model forecast executions.
          </p>
        </div>

        <button
          onClick={exportEventsCsv}
          className="px-3 py-1.5 text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
        >
          <Download className="w-3.5 h-3.5 text-slate-400" />
          <span>Export Event Log CSV</span>
        </button>
      </div>

      <div className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-lg border border-slate-800">
            <button
              onClick={() => setSeverityFilter('all')}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                severityFilter === 'all'
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-800/60'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Events ({events.length})
            </button>
            <button
              onClick={() => setSeverityFilter('critical')}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                severityFilter === 'critical'
                  ? 'bg-rose-950 text-rose-300 border border-rose-800'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Critical Overloads
            </button>
            <button
              onClick={() => setSeverityFilter('warning')}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                severityFilter === 'warning'
                  ? 'bg-amber-950 text-amber-300 border border-amber-800'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Warnings
            </button>
            <button
              onClick={() => setSeverityFilter('info')}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                severityFilter === 'info'
                  ? 'bg-slate-800 text-slate-200'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              System Info
            </button>
          </div>

          <div className="relative w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
            <input
              type="text"
              placeholder="Search event title or message..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-hidden focus:border-cyan-500"
            />
          </div>
        </div>

        <div className="space-y-2.5">
          {filteredEvents.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">
              No matching events found for current filter.
            </div>
          ) : (
            filteredEvents.map(e => {
              const isCrit = e.severity === 'critical';
              const isWarn = e.severity === 'warning';
              const icon = isCrit ? (
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              ) : isWarn ? (
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              ) : (
                <Info className="w-4 h-4 text-cyan-400 shrink-0" />
              );

              return (
                <div
                  key={e.id}
                  className={`p-3.5 rounded-lg border flex items-start gap-3 transition-colors ${
                    isCrit
                      ? 'bg-rose-950/30 border-rose-900/60'
                      : isWarn
                      ? 'bg-amber-950/20 border-amber-900/50'
                      : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-900/40'
                  }`}
                >
                  <div className="mt-0.5">{icon}</div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-slate-200 truncate">
                        {e.title}
                      </span>
                      <span className="text-[10px] font-mono text-slate-500 shrink-0">
                        {new Date(e.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                      {e.detail}
                    </p>

                    <div className="flex items-center gap-2 mt-2 text-[10px] text-slate-500 font-mono">
                      <span>Type: {e.type}</span>
                      <span>·</span>
                      <span className={isCrit ? 'text-rose-400 font-semibold' : ''}>
                        Severity: {e.severity.toUpperCase()}
                      </span>
                      {e.demand_kw !== undefined && (
                        <>
                          <span>·</span>
                          <span className="text-cyan-300">Demand: {e.demand_kw} kW</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
