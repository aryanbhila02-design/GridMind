/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Battery State of Charge (SOC) & Power Flow Chart
 */

import React, { useState } from 'react';
import { ForecastHourResult } from '../types/microgrid';

interface BatteryChartProps {
  data: ForecastHourResult[];
}

export const BatteryChart: React.FC<BatteryChartProps> = ({ data }) => {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  if (!data || data.length === 0) {
    return (
      <div className="h-48 flex items-center justify-center bg-slate-900/40 border border-slate-800 rounded-lg text-slate-400 text-sm">
        No battery telemetry available
      </div>
    );
  }

  const svgWidth = 840;
  const svgHeight = 220;
  const padding = { top: 20, right: 30, bottom: 35, left: 50 };
  const graphWidth = svgWidth - padding.left - padding.right;
  const graphHeight = svgHeight - padding.top - padding.bottom;

  const getX = (index: number) => {
    if (data.length <= 1) return padding.left;
    return padding.left + (index / (data.length - 1)) * graphWidth;
  };

  const getYSoc = (val: number) => {
    // 0% to 100%
    return padding.top + graphHeight - (Math.max(0, Math.min(100, val)) / 100) * graphHeight;
  };

  const socPoints = data.map((d, i) => `${getX(i)},${getYSoc(d.battery_soc_pct)}`);
  const socPathD = `M ${socPoints.join(' L ')}`;
  const socAreaD = `${socPathD} L ${getX(data.length - 1)},${getYSoc(0)} L ${getX(0)},${getYSoc(0)} Z`;

  return (
    <div className="w-full relative">
      <div className="flex flex-wrap items-center justify-between gap-2 mb-2 text-xs">
        <div className="flex items-center gap-4 text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-emerald-400 inline-block"></span>
            <span className="text-slate-300 font-medium">Battery SOC (%)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-0.5 bg-amber-500/80 inline-block border-t border-dashed"></span>
            <span>20% Low Reserve Limit</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2 bg-cyan-500/40 inline-block rounded-xs"></span>
            <span>Power Flow (Discharge / Charge)</span>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <svg
          viewBox={`0 0 ${svgWidth} ${svgHeight}`}
          className="w-full h-auto select-none font-mono text-[10px]"
        >
          <defs>
            <linearGradient id="socGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#10b981" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Grid lines for SOC */}
          {[0, 20, 50, 80, 100].map(val => (
            <g key={val}>
              <line
                x1={padding.left}
                y1={getYSoc(val)}
                x2={svgWidth - padding.right}
                y2={getYSoc(val)}
                stroke={val === 20 ? '#d97706' : '#1e293b'}
                strokeWidth={val === 20 ? 1.5 : 1}
                strokeDasharray={val === 20 ? '4 3' : undefined}
                strokeOpacity={val === 20 ? 0.8 : 0.5}
              />
              <text
                x={padding.left - 8}
                y={getYSoc(val) + 3}
                fill={val === 20 ? '#f59e0b' : '#64748b'}
                textAnchor="end"
              >
                {val}%
              </text>
            </g>
          ))}

          {/* Power flow bars in background */}
          {data.map((d, i) => {
            const cx = getX(i);
            const barWidth = Math.max(4, graphWidth / (data.length * 2.2));
            // Power kw scale (-100 to +120) mapped to bar
            const power = d.battery_power_kw;
            const isDischarging = power > 0;
            const barH = Math.min(graphHeight * 0.45, (Math.abs(power) / 120) * (graphHeight * 0.45));
            const barY = isDischarging
              ? padding.top + graphHeight / 2 - barH
              : padding.top + graphHeight / 2;

            return (
              <rect
                key={`pbar-${i}`}
                x={cx - barWidth / 2}
                y={barY}
                width={barWidth}
                height={Math.max(2, barH)}
                fill={isDischarging ? '#06b6d4' : '#3b82f6'}
                fillOpacity="0.3"
                rx="1"
              />
            );
          })}

          {/* SOC Area & Line */}
          <path d={socAreaD} fill="url(#socGradient)" />
          <path
            d={socPathD}
            fill="none"
            stroke="#10b981"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Interactive Points */}
          {data.map((d, i) => {
            const cx = getX(i);
            const cy = getYSoc(d.battery_soc_pct);
            const isHovered = hoveredIndex === i;
            const isLow = d.battery_soc_pct < 20;

            return (
              <g
                key={`soc-pt-${i}`}
                className="cursor-pointer"
                onMouseEnter={() => setHoveredIndex(i)}
                onMouseLeave={() => setHoveredIndex(null)}
              >
                <rect
                  x={cx - 12}
                  y={padding.top}
                  width={24}
                  height={graphHeight}
                  fill="transparent"
                />
                {isHovered && (
                  <line
                    x1={cx}
                    y1={padding.top}
                    x2={cx}
                    y2={padding.top + graphHeight}
                    stroke="#10b981"
                    strokeWidth="1"
                    strokeDasharray="2 2"
                  />
                )}
                <circle
                  cx={cx}
                  cy={cy}
                  r={isHovered ? 5 : isLow ? 4 : 2.5}
                  fill={isLow ? '#ef4444' : '#10b981'}
                  stroke="#022c22"
                  strokeWidth={isHovered ? 2 : 1}
                />
              </g>
            );
          })}

          {/* X Axis labels */}
          {data.map((d, i) => {
            if (i % 2 === 0 || i === data.length - 1) {
              return (
                <text
                  key={`soc-xlab-${i}`}
                  x={getX(i)}
                  y={padding.top + graphHeight + 16}
                  fill="#94a3b8"
                  textAnchor="middle"
                >
                  {`${d.hour.toString().padStart(2, '0')}:00`}
                </text>
              );
            }
            return null;
          })}
        </svg>
      </div>

      {hoveredIndex !== null && data[hoveredIndex] && (
        <div
          className="absolute z-10 pointer-events-none bg-slate-900/95 border border-slate-700/80 rounded p-2 shadow-lg text-[11px] font-mono"
          style={{
            left: `${Math.min(80, Math.max(10, (hoveredIndex / (data.length - 1)) * 100))}%`,
            top: '15px',
            transform: 'translateX(-50%)',
          }}
        >
          <div className="font-semibold text-slate-200 border-b border-slate-800 pb-1 mb-1">
            {data[hoveredIndex].hour}:00
          </div>
          <div className="text-emerald-400 font-bold">
            SOC: {data[hoveredIndex].battery_soc_pct}% ({data[hoveredIndex].battery_soc_kwh} kWh)
          </div>
          <div className="text-cyan-300">
            Flow: {data[hoveredIndex].battery_power_kw > 0
              ? `Discharging ${data[hoveredIndex].battery_power_kw} kW`
              : data[hoveredIndex].battery_power_kw < 0
              ? `Charging ${Math.abs(data[hoveredIndex].battery_power_kw)} kW`
              : 'Idle (0 kW)'}
          </div>
        </div>
      )}
    </div>
  );
};
