/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Smart Grid Controller & What-If Rule Simulator
 */

import React, { useState } from 'react';
import {
  Sliders,
  Clock,
  Sun,
  Thermometer,
  Droplets,
  AlertTriangle,
  CheckCircle2,
} from 'lucide-react';
import { evaluateGridTransition } from '../engine/transitionController';
import { predictLocalDemandKw } from '../engine/forecastingEngine';
import { BatterySimulator } from '../engine/batterySimulator';

export const GridControllerView: React.FC = () => {
  const [hour, setHour] = useState<number>(19);
  const [temp, setTemp] = useState<number>(26.5);
  const [humidity, setHumidity] = useState<number>(65);
  const [solar, setSolar] = useState<number>(50);

  const simulatedTimestamp = `2026-10-27T${hour.toString().padStart(2, '0')}:00:00`;
  const simulatedDemand = predictLocalDemandKw({
    timestamp: simulatedTimestamp,
    ambient_temp_c: temp,
    humidity_pct: humidity,
    solar_irradiance_wm2: solar,
  });

  const transitionDecision = evaluateGridTransition(simulatedTimestamp, simulatedDemand);
  const sim = new BatterySimulator();
  const batteryStep = sim.step({
    demand_kw: simulatedDemand,
    solar_irradiance_wm2: solar,
    grid_mode: transitionDecision.grid_mode,
  });

  const applyPreset = (preset: 'evening_peak' | 'solar_midday' | 'night_base' | 'heatwave_overload') => {
    if (preset === 'evening_peak') {
      setHour(19);
      setTemp(25.0);
      setHumidity(70);
      setSolar(0);
    } else if (preset === 'solar_midday') {
      setHour(12);
      setTemp(30.0);
      setHumidity(45);
      setSolar(950);
    } else if (preset === 'night_base') {
      setHour(3);
      setTemp(18.0);
      setHumidity(80);
      setSolar(0);
    } else if (preset === 'heatwave_overload') {
      setHour(15);
      setTemp(41.0);
      setHumidity(75);
      setSolar(850);
    }
  };

  return (
    <div className="space-y-6">
      {/* Simulation Advisory Banner */}
      <div className="bg-amber-950/40 border border-amber-800/80 rounded-xl px-4 py-2.5 flex items-center justify-between text-xs text-amber-300">
        <div className="flex items-center gap-2">
          <span className="px-2 py-0.5 rounded bg-amber-900/80 border border-amber-700/80 text-[10px] font-bold uppercase font-mono tracking-wider">
            Hypothetical Scenario — Not a Live Grid State
          </span>
          <span className="text-amber-200/90 hidden md:inline">
            Simulation & decision support only. No physical electrical actuators or grid switches are commanded.
          </span>
        </div>
      </div>

      <div className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-5">
        <h2 className="text-sm font-semibold text-white tracking-tight mb-2 flex items-center gap-2">
          <Sliders className="w-4 h-4 text-cyan-400" />
          <span>Interactive Grid Transition Controller & What-If Simulator</span>
        </h2>
        <p className="text-xs text-slate-400 leading-relaxed max-w-4xl">
          Test real-time transition signals across temperature, humidity, solar irradiance, and diurnal schedule.
          Decisions are governed strictly by HackSphere 3.0 rules:
          <span className="text-cyan-300 font-mono"> Renewable Storage Mode</span> when demand &gt; 160 kW OR local hour is between 18:00 and 22:00;
          <span className="text-slate-300 font-mono"> Main Grid Mode</span> otherwise; and
          <span className="text-rose-400 font-mono"> Critical Overload Alert</span> whenever demand ≥ 200 kW.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Input sliders (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900/80 border border-slate-800/80 rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <span className="text-xs font-semibold text-slate-200">
              Environmental & Temporal Inputs
            </span>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] text-slate-500 mr-1">Presets:</span>
              <button
                onClick={() => applyPreset('evening_peak')}
                className="px-2 py-1 text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 rounded transition-colors"
              >
                Evening Peak
              </button>
              <button
                onClick={() => applyPreset('solar_midday')}
                className="px-2 py-1 text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 rounded transition-colors"
              >
                Midday Solar
              </button>
              <button
                onClick={() => applyPreset('night_base')}
                className="px-2 py-1 text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 rounded transition-colors"
              >
                Night Base
              </button>
              <button
                onClick={() => applyPreset('heatwave_overload')}
                className="px-2 py-1 text-[10px] bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 rounded transition-colors"
              >
                Heatwave Overload
              </button>
            </div>
          </div>

          {/* Slider 1: Hour of Day */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <label htmlFor="hour-input" className="text-slate-300 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-cyan-400" />
                <span>Hour of Day (24-Hour Time)</span>
              </label>
              <span className="font-mono font-bold text-cyan-300 tabular-nums">
                {hour.toString().padStart(2, '0')}:00 {hour >= 18 && hour <= 22 ? '(Evening Window)' : ''}
              </span>
            </div>
            <input
              id="hour-input"
              type="range"
              min="0"
              max="23"
              step="1"
              value={hour}
              onChange={e => setHour(parseInt(e.target.value, 10))}
              className="w-full accent-cyan-400 bg-slate-950 h-2 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>00:00</span>
              <span className="text-cyan-400">18:00 - 22:00 (Peak Window)</span>
              <span>23:00</span>
            </div>
          </div>

          {/* Slider 2: Ambient Temp */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <label htmlFor="temp-input" className="text-slate-300 flex items-center gap-1.5">
                <Thermometer className="w-3.5 h-3.5 text-amber-400" />
                <span>Ambient Temperature</span>
              </label>
              <span className="font-mono font-bold text-amber-300 tabular-nums">
                {temp}°C
              </span>
            </div>
            <input
              id="temp-input"
              type="range"
              min="-5"
              max="45"
              step="0.5"
              value={temp}
              onChange={e => setTemp(parseFloat(e.target.value))}
              className="w-full accent-amber-400 bg-slate-950 h-2 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>-5°C (Heating)</span>
              <span>22°C (Base Comfort)</span>
              <span>45°C (HVAC Surge)</span>
            </div>
          </div>

          {/* Slider 3: Solar Irradiance */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <label htmlFor="solar-input" className="text-slate-300 flex items-center gap-1.5">
                <Sun className="w-3.5 h-3.5 text-yellow-400" />
                <span>Solar Irradiance</span>
              </label>
              <span className="font-mono font-bold text-yellow-300 tabular-nums">
                {solar} W/m²
              </span>
            </div>
            <input
              id="solar-input"
              type="range"
              min="0"
              max="1200"
              step="10"
              value={solar}
              onChange={e => setSolar(parseInt(e.target.value, 10))}
              className="w-full accent-yellow-400 bg-slate-950 h-2 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>0 W/m² (Night)</span>
              <span>500 W/m² (Cloudy)</span>
              <span>1000+ W/m² (Clear Sky)</span>
            </div>
          </div>

          {/* Slider 4: Humidity */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <label htmlFor="humidity-input" className="text-slate-300 flex items-center gap-1.5">
                <Droplets className="w-3.5 h-3.5 text-teal-400" />
                <span>Relative Humidity</span>
              </label>
              <span className="font-mono font-bold text-teal-300 tabular-nums">
                {humidity}%
              </span>
            </div>
            <input
              id="humidity-input"
              type="range"
              min="10"
              max="100"
              step="1"
              value={humidity}
              onChange={e => setHumidity(parseInt(e.target.value, 10))}
              className="w-full accent-teal-400 bg-slate-950 h-2 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>10% (Dry)</span>
              <span>50% (Comfort)</span>
              <span>100% (Saturated)</span>
            </div>
          </div>
        </div>

        {/* Right: Controller Decision Card (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900/80 border border-slate-800/80 rounded-xl p-5 flex flex-col justify-between space-y-4">
          <div>
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Microgrid Dispatch Decision
            </div>

            <div
              className={`p-4 rounded-xl border flex flex-col gap-2 ${
                transitionDecision.grid_mode === 'Renewable Storage Mode'
                  ? 'bg-cyan-950/50 border-cyan-700/80 text-cyan-200'
                  : 'bg-slate-950/80 border-slate-800 text-slate-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium uppercase text-slate-400">Target Mode</span>
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                    transitionDecision.grid_mode === 'Renewable Storage Mode'
                      ? 'bg-cyan-900 text-cyan-200'
                      : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  DISPATCH SIGNAL
                </span>
              </div>
              <div className="text-xl font-bold tracking-tight">
                {transitionDecision.grid_mode}
              </div>
            </div>

            <div
              className={`mt-3 p-3 rounded-lg border flex items-center justify-between text-xs font-mono ${
                transitionDecision.critical_overload
                  ? 'bg-rose-950/60 border-rose-800 text-rose-300'
                  : 'bg-slate-950/40 border-slate-800/60 text-emerald-400'
              }`}
            >
              <div className="flex items-center gap-2">
                {transitionDecision.critical_overload ? (
                  <AlertTriangle className="w-4 h-4 text-rose-400" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                )}
                <span>
                  {transitionDecision.critical_overload
                    ? 'CRITICAL OVERLOAD ACTIVE (≥ 200 kW)'
                    : 'Transformer Load Safe (< 200 kW)'}
                </span>
              </div>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-2 gap-3 mt-4 text-xs font-mono">
              <div className="bg-slate-950/60 border border-slate-800/60 rounded-lg p-3">
                <span className="text-[10px] text-slate-400 block font-sans">Predicted Load</span>
                <span className="text-lg font-bold text-cyan-300 tabular-nums">
                  {simulatedDemand.toFixed(1)} kW
                </span>
              </div>
              <div className="bg-slate-950/60 border border-slate-800/60 rounded-lg p-3">
                <span className="text-[10px] text-slate-400 block font-sans">Grid Import</span>
                <span className="text-lg font-bold text-slate-200 tabular-nums">
                  {batteryStep.grid_import_kw.toFixed(1)} kW
                </span>
              </div>
              <div className="bg-slate-950/60 border border-slate-800/60 rounded-lg p-3">
                <span className="text-[10px] text-slate-400 block font-sans">Battery Dispatch</span>
                <span className="text-lg font-bold text-emerald-400 tabular-nums">
                  {batteryStep.battery_power_kw > 0
                    ? `+${batteryStep.battery_power_kw.toFixed(1)} kW`
                    : `${batteryStep.battery_power_kw.toFixed(1)} kW`}
                </span>
              </div>
              <div className="bg-slate-950/60 border border-slate-800/60 rounded-lg p-3">
                <span className="text-[10px] text-slate-400 block font-sans">Solar Generation</span>
                <span className="text-lg font-bold text-amber-300 tabular-nums">
                  {batteryStep.solar_generation_kw.toFixed(1)} kW
                </span>
              </div>
            </div>
          </div>

          <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
            <div className="text-[10px] uppercase font-semibold text-slate-400 mb-1">
              Official Rule Engine Audit Reason
            </div>
            <div className="text-xs text-cyan-300 font-mono leading-relaxed">
              {transitionDecision.decision_reason}
            </div>
          </div>
        </div>
      </div>

      {/* Logic Rule Branch Inspector */}
      <div className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-5">
        <h3 className="text-xs font-semibold text-slate-200 mb-3">
          HackSphere 3.0 Rule Engine Audit Tree
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
          <div
            className={`p-3.5 rounded-lg border ${
              simulatedDemand > 160
                ? 'bg-cyan-950/50 border-cyan-600 text-cyan-200'
                : 'bg-slate-950/40 border-slate-800 text-slate-400'
            }`}
          >
            <div className="flex items-center justify-between font-sans font-semibold mb-1">
              <span>Rule 1: Demand &gt; 160 kW</span>
              <span className={simulatedDemand > 160 ? 'text-cyan-400' : 'text-slate-600'}>
                {simulatedDemand > 160 ? 'TRIGGERED' : 'NOT MET'}
              </span>
            </div>
            <p className="text-[11px] font-sans text-slate-400 mt-1">
              Current: {simulatedDemand.toFixed(1)} kW {simulatedDemand > 160 ? '> 160 kW' : '≤ 160 kW'}
            </p>
            <div className="text-[10px] text-cyan-400 mt-2 font-mono">
              Action → Renewable Storage Mode
            </div>
          </div>

          <div
            className={`p-3.5 rounded-lg border ${
              hour >= 18 && hour <= 22
                ? 'bg-cyan-950/50 border-cyan-600 text-cyan-200'
                : 'bg-slate-950/40 border-slate-800 text-slate-400'
            }`}
          >
            <div className="flex items-center justify-between font-sans font-semibold mb-1">
              <span>Rule 2: Hour in [18:00..22:00]</span>
              <span className={hour >= 18 && hour <= 22 ? 'text-cyan-400' : 'text-slate-600'}>
                {hour >= 18 && hour <= 22 ? 'TRIGGERED' : 'NOT MET'}
              </span>
            </div>
            <p className="text-[11px] font-sans text-slate-400 mt-1">
              Current: Hour {hour}:00 {hour >= 18 && hour <= 22 ? '(Inside peak)' : '(Outside peak)'}
            </p>
            <div className="text-[10px] text-cyan-400 mt-2 font-mono">
              Action → Renewable Storage Mode
            </div>
          </div>

          <div
            className={`p-3.5 rounded-lg border ${
              simulatedDemand >= 200
                ? 'bg-rose-950/60 border-rose-600 text-rose-200'
                : 'bg-slate-950/40 border-slate-800 text-slate-400'
            }`}
          >
            <div className="flex items-center justify-between font-sans font-semibold mb-1">
              <span>Rule 3: Demand ≥ 200 kW</span>
              <span className={simulatedDemand >= 200 ? 'text-rose-400' : 'text-slate-600'}>
                {simulatedDemand >= 200 ? 'TRIGGERED' : 'SAFE'}
              </span>
            </div>
            <p className="text-[11px] font-sans text-slate-400 mt-1">
              Current: {simulatedDemand.toFixed(1)} kW {simulatedDemand >= 200 ? '≥ 200 kW' : '< 200 kW'}
            </p>
            <div className="text-[10px] text-rose-400 mt-2 font-mono">
              Action → Critical Overload Alert
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
