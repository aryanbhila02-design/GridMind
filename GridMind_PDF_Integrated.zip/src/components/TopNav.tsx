/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Top Navigation Bar
 */

import React from 'react';
import { Play, RefreshCw, UploadCloud, AlertTriangle } from 'lucide-react';
import { NavView } from './Sidebar';

interface TopNavProps {
  currentView: NavView;
  onSelectView: (view: NavView) => void;
  onRefreshForecast: () => void;
  isForecasting: boolean;
  currentMode: string;
  criticalAlertCount: number;
  lastForecastTimestamp?: string;
  isQuickMlLive: boolean;
}

export const TopNav: React.FC<TopNavProps> = ({
  currentView,
  onSelectView,
  onRefreshForecast,
  isForecasting,
  currentMode,
  criticalAlertCount,
  lastForecastTimestamp,
  isQuickMlLive,
}) => {
  const viewTitles: Record<NavView, string> = {
    overview: 'Overview Dashboard',
    forecast: '24-Hour Electricity Demand Forecast',
    controller: 'Smart Grid Dispatch & Transition Rules',
    battery: 'Battery Energy Storage System (BESS)',
    mllab: 'ML Research Lab & Model Engineering',
    explainability: 'Prediction Explainability & Feature Reliance (P2)',
    uncertainty: 'Forecast Uncertainty & Conformal Bounds (P3)',
    peak: 'Peak Demand Intelligence & Feeder Analytics',
    nationalgrid: 'National Grid Benchmark & Bulk Power Supply (electric Data.pdf)',
    upload: 'Telemetry CSV Ingestion & Validation',
    analytics: 'Model Evaluation & TimeSeriesSplit Benchmark',
    events: 'System Event History & Transition Log',
    config: 'Zoho Catalyst & QuickML System Configuration',
  };

  const formattedTime = lastForecastTimestamp
    ? new Date(lastForecastTimestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    : '--:--';

  return (
    <header className="h-16 px-6 bg-slate-950/80 border-b border-slate-800/80 backdrop-blur-md flex items-center justify-between gap-6 shrink-0 z-10">
      {/* Zone 1: Context Breadcrumb */}
      <div className="flex items-center gap-2 min-w-0">
        <span className="text-xs text-slate-400 font-medium hidden sm:inline">Microgrid</span>
        <span className="text-xs text-slate-600 hidden sm:inline">/</span>
        <h1 className="text-sm font-semibold text-white tracking-tight truncate">
          {viewTitles[currentView]}
        </h1>
      </div>

      {/* Zone 2: Status Indicators */}
      <div className="hidden lg:flex items-center gap-4 text-xs font-mono">
        <div className="flex items-center gap-2 px-2.5 py-1 rounded bg-slate-900 border border-slate-800">
          <span className="text-slate-400">Current Mode:</span>
          <span
            className={`font-semibold ${
              currentMode === 'Renewable Storage Mode' ? 'text-cyan-400' : 'text-slate-200'
            }`}
          >
            {currentMode}
          </span>
        </div>

        {criticalAlertCount > 0 && (
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-rose-950/50 border border-rose-800/80 text-rose-300">
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
            <span className="font-semibold">{criticalAlertCount} Overload Alert{criticalAlertCount > 1 ? 's' : ''}</span>
          </div>
        )}

        <div className="flex items-center gap-2 text-slate-400">
          <span>Synced:</span>
          <span className="text-slate-200 tabular-nums">{formattedTime}</span>
        </div>
      </div>

      {/* Zone 3: Primary Actions */}
      <div className="flex items-center gap-2.5 shrink-0">
        <button
          onClick={() => onSelectView('upload')}
          className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-700/80 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap"
        >
          <UploadCloud className="w-3.5 h-3.5 text-slate-400" />
          <span className="hidden sm:inline">Upload CSV</span>
        </button>

        <button
          onClick={onRefreshForecast}
          disabled={isForecasting}
          className="px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-gradient-to-r from-cyan-400 to-teal-400 hover:from-cyan-300 hover:to-teal-300 rounded-lg shadow-sm transition-all flex items-center gap-1.5 disabled:opacity-50 whitespace-nowrap"
        >
          {isForecasting ? (
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Play className="w-3.5 h-3.5 fill-current" />
          )}
          <span>{isForecasting ? 'Forecasting...' : 'Run 24h Forecast'}</span>
        </button>
      </div>
    </header>
  );
};
