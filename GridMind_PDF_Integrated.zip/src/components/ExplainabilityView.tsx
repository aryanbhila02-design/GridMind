/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Prediction Explainability View
 * HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine
 * 
 * Features:
 * - Breiman-Fisher Permutation Feature Importance evaluated on held-out validation data
 * - Delta RMSE degradation ranking and relative importance percentages
 * - Physical domain rationale for weather and temporal drivers
 * - Critical scientific distinction between model reliance and causal mechanisms
 */

import React, { useState, useEffect } from 'react';
import {
  Compass,
  TrendingUp,
  RefreshCw,
  AlertTriangle,
  Info,
  ShieldAlert,
  Sun,
  Thermometer,
  Droplets,
  Clock,
  ArrowRight,
} from 'lucide-react';
import type { ExplainabilityResult } from '../types/microgrid.ts';

export const ExplainabilityView: React.FC = () => {
  const [data, setData] = useState<ExplainabilityResult | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchExplainability = () => {
    setLoading(true);
    setError(null);
    fetch('/api/ml/explainability')
      .then(res => res.json())
      .then(json => {
        if (json.success) {
          setData(json);
        } else {
          setError(json.error || 'Failed to compute feature importance.');
        }
      })
      .catch(err => {
        setError(err.message || 'Network error fetching explainability data.');
      })
      .finally(() => {
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchExplainability();
  }, []);

  const getFeatureIcon = (feature: string) => {
    if (feature.includes('temp')) return <Thermometer className="w-4 h-4 text-rose-400" />;
    if (feature.includes('solar')) return <Sun className="w-4 h-4 text-amber-400" />;
    if (feature.includes('humidity')) return <Droplets className="w-4 h-4 text-cyan-400" />;
    return <Clock className="w-4 h-4 text-purple-400" />;
  };

  return (
    <div className="space-y-6 max-w-6xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-100 flex items-center gap-2">
            <Compass className="w-6 h-6 text-cyan-400" />
            Prediction Explainability & Feature Reliance
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Quantifying predictor reliance via Breiman-Fisher out-of-sample permutation feature importance on held-out telemetry.
          </p>
        </div>
        <button
          onClick={fetchExplainability}
          disabled={loading}
          className="self-start sm:self-auto py-2 px-3.5 bg-slate-800 hover:bg-slate-700 disabled:bg-slate-900 text-slate-200 text-xs font-medium rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          Recalculate Importances
        </button>
      </div>

      {/* Scientific Distinction Callout */}
      <div className="p-4 bg-amber-950/30 border border-amber-500/30 rounded-xl flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <h4 className="text-sm font-semibold text-amber-300">
            Reliance vs. Physical Causality Notice
          </h4>
          <p className="text-xs text-slate-300 leading-relaxed">
            {data?.causalityCaveat ||
              'Permutation importance measures how much model accuracy degrades when a single predictor column is randomly shuffled on held-out validation data. It measures statistical feature reliance given the joint distribution, which correlates with but does not guarantee direct physical causation.'}
          </p>
        </div>
      </div>

      {loading ? (
        <div className="h-64 flex flex-col items-center justify-center text-slate-400 bg-slate-900 border border-slate-800 rounded-xl">
          <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin mb-3" />
          <p className="text-sm">Permuting feature columns and calculating out-of-sample ΔRMSE...</p>
        </div>
      ) : error ? (
        <div className="p-4 bg-rose-950/40 border border-rose-500/30 text-rose-300 rounded-xl text-sm">
          {error}
        </div>
      ) : data ? (
        <div className="space-y-6">
          {/* Top Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <span className="text-xs text-slate-400">Baseline Validation RMSE</span>
              <div className="text-2xl font-bold font-mono text-cyan-400 mt-1">
                {data.baselineRmse} <span className="text-xs font-normal text-slate-400">kW</span>
              </div>
              <span className="text-[11px] text-slate-500 mt-0.5 block">Uncorrupted feature matrix</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <span className="text-xs text-slate-400">Evaluation Partition</span>
              <div className="text-lg font-bold text-slate-200 mt-1 truncate">
                {data.sampleCount} hours
              </div>
              <span className="text-[11px] text-slate-500 mt-0.5 block">30% held-out chronological split</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <span className="text-xs text-slate-400">Dominant Predictor</span>
              <div className="text-lg font-bold text-purple-400 mt-1 truncate">
                {data.importances[0]?.label.split('(')[0] || 'N/A'}
              </div>
              <span className="text-[11px] text-slate-500 mt-0.5 block">
                {data.importances[0]?.relativeImportancePct}% relative contribution
              </span>
            </div>
          </div>

          {/* Feature Importance Rankings Table & Bars */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5">
            <h3 className="font-semibold text-slate-200 text-sm flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              Permutation Importance Ranking (ΔRMSE Impact)
            </h3>

            <div className="space-y-4">
              {data.importances.map(item => (
                <div key={item.feature} className="p-4 bg-slate-950 rounded-xl border border-slate-800/80 space-y-2">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                        {getFeatureIcon(item.feature)}
                      </div>
                      <div>
                        <h4 className="text-sm font-semibold text-slate-200">{item.label}</h4>
                        <span className="font-mono text-xs text-slate-400">{item.feature}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 text-right">
                      <div>
                        <span className="text-xs text-slate-400 block">Error Increase (ΔRMSE)</span>
                        <span className="font-mono text-sm font-bold text-rose-400">
                          +{item.deltaRmse} kW
                        </span>
                      </div>
                      <div className="w-20 text-right">
                        <span className="text-xs text-slate-400 block">Relative Share</span>
                        <span className="font-mono text-sm font-bold text-cyan-400">
                          {item.relativeImportancePct}%
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="bg-slate-900 h-2.5 rounded-full overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-cyan-500 to-purple-500 h-full rounded-full transition-all duration-500"
                      style={{ width: `${Math.max(5, item.relativeImportancePct)}%` }}
                    />
                  </div>

                  {/* Domain Rationale */}
                  <div className="text-xs text-slate-400 pt-1 leading-relaxed">
                    <span className="font-medium text-slate-300">Domain Mechanism:</span> {item.domainRationale}
                  </div>
                </div>
              ))}
            </div>

            {/* Methodology Note */}
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800/80 text-xs text-slate-400 leading-relaxed">
              <span className="font-semibold text-slate-300">Methodology:</span> {data.methodology}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};
