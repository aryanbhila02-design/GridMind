# GridMind — Smart Energy Microgrid & Demand Forecasting Engine

**HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine**  
*Full-Stack Energy Intelligence Platform for Zoho Catalyst AppSail & QuickML*

---

## 1. Project Overview

**GridMind** is an end-to-end intelligent energy microgrid decision support, 24-hour demand forecasting, and machine learning research platform developed for **HackSphere 3.0**. 

The system accepts hourly weather and telemetry inputs, forecasts electricity demand over a 24-hour horizon, deterministically evaluates grid dispatch operating modes according to official HackSphere 3.0 rules, simulates battery electrochemical storage (BESS), and generates critical overload alerts.

> **Operational Scope & Decision Support Notice**: GridMind is a software-level decision-support and simulation engine. It does not directly command physical switchgear or high-voltage electrical actuators.

---

## 2. Core Architecture & Technologies

- **Frontend**: React 19, TypeScript, Vite 8, Tailwind CSS, Lucide icons.
- **Backend API**: Express 4 running under Node.js 22 with ESM support and Vite dev middleware.
- **Machine Learning Engine**:
  - Production Inference: Zoho Catalyst QuickML Tabular Regression REST endpoint client.
  - Production Fallback: L2 Regularized Ridge Regression trained on official telemetry with TimeSeriesSplit ($k=5$).
  - ML Research Lab: Pure TypeScript implementations of Gradient Descent, Single Perceptron binary classification, and Deep Multilayer Perceptron (MLP) with analytical backpropagation and finite-difference gradient verification.
  - Explainability: Breiman-Fisher out-of-sample Permutation Feature Importance.
  - Uncertainty: Calibrated distribution-free Conformal Prediction intervals (80%, 90%, 95%).
- **Data Persistence**: File-backed atomic JSON persistence for telemetry, forecasts, events, and battery settings surviving server restarts.
- **Evaluation Contract**: Standalone dual-interface `predict.py` supporting Python function `predict(df)` and CLI pipeline.

---

## 3. Official HackSphere 3.0 Controller Rules

The energy transition controller deterministically evaluates every forecast hour $t$:

1. **Renewable Storage Mode**:
   $$\text{Mode} = \text{Renewable Storage Mode} \iff \text{Demand}_t > 160\text{ kW} \quad\lor\quad \text{Hour}_t \in [18, 19, 20, 21, 22]$$
2. **Main Grid Mode**:
   $$\text{Mode} = \text{Main Grid Mode} \iff \text{Demand}_t \le 160\text{ kW} \quad\land\quad \text{Hour}_t \notin [18, 19, 20, 21, 22]$$
3. **Critical Overload Alert**:
   $$\text{Alert} = \text{True} \iff \text{Demand}_t \ge 200\text{ kW}$$

---

## 4. Telemetry Schema & Datasets

### Official Training Dataset (`train_telemetry.csv`):
- **Observations**: 72 continuous hourly rows (3 complete 24-hour diurnal cycles: 2026-10-20T00:00:00 to 2026-10-22T23:00:00).
- **Features**: `ambient_temp_c` (mean 23.17°C), `humidity_pct` (mean 63.81%), `solar_irradiance_wm2` (mean 360.56 W/m²).
- **Target**: `target_demand_kw` (min 78.20 kW, max 213.20 kW, mean 146.66 kW).
- **Target Leakage Safeguard**: The prediction target is strictly excluded from feature inputs during inference.

### Official Unlabelled Test Input (`sample_test_input.csv`):
- 24 continuous hourly rows (2026-10-27T00:00:00 to 2026-10-27T23:00:00).
- Columns: `timestamp,ambient_temp_c,humidity_pct,solar_irradiance_wm2`.

### Prediction Output Format (`predictions.csv`):
```csv
timestamp,target_demand_kw
2026-10-27T00:00:00,110.00
2026-10-27T01:00:00,95.00
...
```

---

## 5. Security & Secret Management (Phase 2 Compliant)

1. **Zero Client Secrets**: No API keys, OAuth tokens, or sensitive credentials exist in frontend state, local storage, or browser requests.
2. **Server-Side Environment**: QuickML credentials (`ZOHO_QUICKML_ENDPOINT`, `ZOHO_CATALYST_API_KEY`, `ZOHO_PROJECT_ID`) are read exclusively on the server.
3. **SSRF Protection**: `/api/quickml/test-connection` tests only the server's configured environment endpoint, ignoring client-supplied URLs.
4. **Header Cleanliness**: Only standard `Authorization: Zoho-oauthtoken ...` and `X-Catalyst-Project-Id` headers are transmitted (no invented headers).

---

## 6. Model Training & Evaluation Workflow

### Chronological TimeSeriesSplit Cross-Validation:
- Tested across 5 chronological walk-forward splits on `train_telemetry.csv`.
- Trained Ridge Regression Metrics:
  - **Overall Held-Out Chronological CV**: RMSE = **10.04 kW**, MAE = **7.56 kW**, $R^2$ = **0.865**.
- **Transparent Source Designation**:
  - `live_quickml`: Live verified prediction from published QuickML endpoint.
  - `local_baseline_demo`: Trained Ridge Regression fallback model evaluated on official telemetry.
  - `quickml_failed_fallback`: Transparent notice when QuickML is configured but times out or returns non-200.

---

## 7. Dual Python Prediction Contracts (`predict.py`)

### Interface A — Starter Kit Function Contract:
```python
from predict import predict
# input_df: pandas DataFrame or list of row dicts
preds = predict(input_df) # Returns list or numpy array of floats
```

### Interface B — CLI Pipeline Contract:
```bash
python3 predict.py --input sample_test_input.csv --output sample_predictions.csv
```

### Automated Evaluation Suite:
```bash
python3 test_eval.py sample_test_input.csv sample_predictions.csv
```

---

## 8. Data Persistence Architecture (Phase 6)

GridMind persists state across restarts using file-backed atomic JSON storage in `data/`:
- `persisted_telemetry.json`: Active/uploaded telemetry rows.
- `persisted_forecast.json`: Latest 24-hour forecast results and metadata.
- `persisted_events.json`: Historical audit events and critical alerts.
- `persisted_settings.json`: User-configured BESS capacity, C-rate, and reserve parameters.

---

## 9. API Reference

| Endpoint | Method | Purpose |
| :--- | :--- | :--- |
| `/api/health` | GET | Comprehensive real-time health (QuickML, dataset rows, persistence, forecast source). |
| `/api/grid/status` | GET | Current operating mode, peak demand, overload count, battery SoC. |
| `/api/forecast/latest` | GET | Latest 24-hour forecast with battery steps and grid decisions. |
| `/api/forecast` | POST | Re-evaluates 24-hour forecast using server-side QuickML or trained Ridge fallback. |
| `/api/telemetry/upload` | POST | Ingests CSV telemetry with schema validation and error reporting. |
| `/api/evaluate` | POST | Runs TimeSeriesSplit chronological walk-forward evaluation. |
| `/api/quickml/test-connection` | POST | Tests server QuickML endpoint with SSRF protection. |
| `/api/quickml/config` | GET | Safe status of QuickML (host, environment, status; no secrets). |
| `/api/battery/config` | POST | Updates and persists BESS capacity and power limits. |
| `/api/ml/train-gradient-descent` | POST | Trains Gradient Descent Regressor with live loss trajectory. |
| `/api/ml/train-perceptron` | POST | Trains Single Perceptron Classifier for binary load thresholding. |
| `/api/ml/train-neural-net` | POST | Trains Deep MLP with backprop and finite-difference gradient check. |
| `/api/ml/explainability` | GET | Computes Permutation Feature Importance ($\Delta$RMSE). |
| `/api/ml/uncertainty` | GET | Calculates Conformal Prediction intervals (80%, 90%, 95%). |
| `/api/ml/peak-intelligence` | GET | Calculates diurnal peak, base load, load factor, and ramp rates. |
| `/api/ml/what-if` | POST | Simulates side-by-side battery capacity scenarios. |
| `/api/weather/forecast` | GET | Queries Open-Meteo hourly weather with schema mapping. |

---

## 10. Local Development & Testing Instructions

### 1. Install Dependencies:
```bash
npm install
```

### 2. Run Automated Unit Tests (14 comprehensive test suites):
```bash
npm test
```

### 3. Run TypeScript Linting:
```bash
npm run lint
```

### 4. Build for Production:
```bash
npm run build
```

### 5. Verify Python Contracts:
```bash
python3 test_eval.py sample_test_input.csv sample_predictions.csv
```

### 6. Start Development Server:
```bash
npm run dev
```

---

## 11. Zoho Catalyst AppSail Deployment

```bash
# 1. Install Catalyst CLI
npm install -g zcatalyst-cli

# 2. Login to your Zoho account
catalyst login

# 3. Test locally with Catalyst emulator
catalyst app:run

# 4. Deploy full stack to AppSail
catalyst deploy --only appsail
```

---

## 12. Known Limitations & Credential Status

- **Zoho Catalyst QuickML Live Endpoint**: In demonstration mode, GridMind operates using the local trained Ridge Regression model evaluated on the official 72-hour dataset. When published QuickML credentials are provided in the server environment, GridMind seamlessly invokes the live service.
- **Physical Control**: GridMind provides dispatch recommendations and simulation; it does not directly actuate high-voltage physical switchgear.
