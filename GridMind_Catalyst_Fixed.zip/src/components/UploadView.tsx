/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Telemetry Upload, CSV Validation & Prediction Export View
 */

import React, { useState } from 'react';
import {
  UploadCloud,
  FileText,
  CheckCircle2,
  AlertTriangle,
  Download,
  Play,
  RotateCcw,
  Sparkles,
  FileCheck,
} from 'lucide-react';
import { TelemetryRow, ValidationSummary } from '../types/microgrid';
import { validateTelemetryCsv, exportPredictionsToCsv } from '../engine/telemetryValidator';
import { generateSynthetic24HourTelemetry } from '../engine/forecastingEngine';

interface UploadViewProps {
  onTelemetryLoaded: (records: TelemetryRow[]) => void;
  onRunForecastWithTelemetry: (records: TelemetryRow[]) => void;
  isForecasting: boolean;
}

export const UploadView: React.FC<UploadViewProps> = ({
  onTelemetryLoaded,
  onRunForecastWithTelemetry,
  isForecasting,
}) => {
  const [csvContent, setCsvContent] = useState<string>('');
  const [validationSummary, setValidationSummary] = useState<ValidationSummary | null>(null);
  const [validRecords, setValidRecords] = useState<TelemetryRow[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [activeFileName, setActiveFileName] = useState<string>('');

  const processCsv = (rawText: string, filename: string = 'telemetry.csv') => {
    setActiveFileName(filename);
    setCsvContent(rawText);
    const { validRecords: valid, summary } = validateTelemetryCsv(rawText);
    setValidRecords(valid);
    setValidationSummary(summary);
    if (valid.length > 0) {
      onTelemetryLoaded(valid);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      const text = ev.target?.result as string;
      processCsv(text, file.name);
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      const text = ev.target?.result as string;
      processCsv(text, file.name);
    };
    reader.readAsText(file);
  };

  const loadSampleFile = async (type: 'test' | 'train') => {
    try {
      const res = await fetch(`/api/sample-data/${type}`);
      if (res.ok) {
        const text = await res.text();
        if (text.trim().toLowerCase().startsWith('<!doctype') || text.trim().startsWith('<html')) {
          throw new Error('Received HTML fallback instead of CSV dataset');
        }
        processCsv(text, type === 'test' ? 'sample_test_input.csv' : 'train_telemetry.csv');
      } else {
        throw new Error('Sample data endpoint returned ' + res.status);
      }
    } catch {
      // Fallback: generate synthetic if fetch fails
      const synthetic = generateSynthetic24HourTelemetry();
      const csvStr =
        'timestamp,ambient_temp_c,humidity_pct,solar_irradiance_wm2\n' +
        synthetic.map(r => `${r.timestamp},${r.ambient_temp_c},${r.humidity_pct},${r.solar_irradiance_wm2}`).join('\n');
      processCsv(csvStr, 'synthetic_telemetry.csv');
    }
  };

  const handleGenerateSynthetic = () => {
    const synthetic = generateSynthetic24HourTelemetry();
    const csvStr =
      'timestamp,ambient_temp_c,humidity_pct,solar_irradiance_wm2\n' +
      synthetic.map(r => `${r.timestamp},${r.ambient_temp_c},${r.humidity_pct},${r.solar_irradiance_wm2}`).join('\n');
    processCsv(csvStr, 'synthetic_24h_telemetry.csv');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-5">
        <h2 className="text-sm font-semibold text-white tracking-tight mb-2 flex items-center gap-2">
          <UploadCloud className="w-4 h-4 text-cyan-400" />
          <span>Telemetry Ingestion & Strict Data Contract Validator</span>
        </h2>
        <p className="text-xs text-slate-400 leading-relaxed max-w-4xl">
          Upload microgrid hourly weather and energy telemetry conforming to the HackSphere 3.0 schema:
          <span className="text-slate-200 font-mono"> timestamp, ambient_temp_c, humidity_pct, solar_irradiance_wm2</span> (and optional <span className="text-slate-200 font-mono">target_demand_kw</span> for historical training).
          Strict chronological order, range validation, and row integrity checks are performed.
        </p>
      </div>

      {/* Upload Zone & Quick Sample Loaders */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Drop zone (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          <div
            onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center text-center transition-all bg-slate-900/40 cursor-pointer ${
              isDragging
                ? 'border-cyan-400 bg-cyan-950/20'
                : 'border-slate-800 hover:border-slate-700 hover:bg-slate-900/60'
            }`}
          >
            <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center text-cyan-400 mb-3 shadow-inner">
              <UploadCloud className="w-6 h-6" />
            </div>

            <h3 className="text-sm font-semibold text-slate-200 mb-1">
              Drag and drop your telemetry CSV file here
            </h3>
            <p className="text-xs text-slate-400 mb-4 max-w-md">
              Files are parsed and validated client-side against the official HackSphere 3.0 microgrid telemetry contract.
            </p>

            <div className="flex items-center gap-3">
              <label className="px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg cursor-pointer transition-colors shadow-sm">
                Browse CSV File
                <input type="file" accept=".csv" onChange={handleFileUpload} className="hidden" />
              </label>
              <button
                onClick={() => {
                  const header = 'timestamp,ambient_temp_c,humidity_pct,solar_irradiance_wm2\n';
                  const now = new Date();
                  const sampleRows = Array.from({ length: 24 }).map((_, i) => {
                    const dt = new Date(now.getTime() + i * 3600000);
                    const ts = dt.toISOString().slice(0, 19);
                    return `${ts},25.0,60.0,${i >= 6 && i <= 18 ? 600 : 0}`;
                  }).join('\n');
                  const blob = new Blob([header + sampleRows], { type: 'text/csv' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = 'telemetry_template.csv';
                  a.click();
                  URL.revokeObjectURL(url);
                }}
                className="px-3.5 py-2 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5 text-slate-400" />
                <span>Download Sample Template</span>
              </button>
            </div>
          </div>
        </div>

        {/* Quick Sample Action Cards (4 cols) */}
        <div className="lg:col-span-4 bg-slate-900/80 border border-slate-800/80 rounded-xl p-5 space-y-3">
          <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
            Quick-Load Test Datasets
          </h3>

          <button
            onClick={() => loadSampleFile('test')}
            className="w-full p-3 text-left rounded-lg bg-slate-950 border border-slate-800 hover:border-cyan-800 hover:bg-cyan-950/20 transition-all flex items-start gap-3"
          >
            <FileText className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-xs font-semibold text-slate-200">Load sample_test_input.csv</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Official 24-hour unlabelled test input</div>
            </div>
          </button>

          <button
            onClick={() => loadSampleFile('train')}
            className="w-full p-3 text-left rounded-lg bg-slate-950 border border-slate-800 hover:border-emerald-800 hover:bg-emerald-950/20 transition-all flex items-start gap-3"
          >
            <FileCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-xs font-semibold text-slate-200">Load train_telemetry.csv</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Historical 72-hour dataset with target demand</div>
            </div>
          </button>

          <button
            onClick={handleGenerateSynthetic}
            className="w-full p-3 text-left rounded-lg bg-slate-950 border border-slate-800 hover:border-amber-800 hover:bg-amber-950/20 transition-all flex items-start gap-3"
          >
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-xs font-semibold text-slate-200">Generate Synthetic 24h</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Realistic diurnal weather simulator</div>
            </div>
          </button>
        </div>
      </div>

      {/* Validation Summary Card */}
      {validationSummary && (
        <div className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-white">Validation Results:</span>
                <span className="text-xs text-cyan-300 font-mono">{activeFileName}</span>
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {validationSummary.cleaningPolicy}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onRunForecastWithTelemetry(validRecords)}
                disabled={isForecasting || validRecords.length === 0}
                className="px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Run 24h Forecast ({validRecords.length} Rows)</span>
              </button>
            </div>
          </div>

          {/* Validation Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
            <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg">
              <span className="text-[10px] text-slate-400 block font-sans">Total Rows</span>
              <span className="text-base font-bold text-slate-200">{validationSummary.totalRows}</span>
            </div>
            <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg">
              <span className="text-[10px] text-slate-400 block font-sans">Valid Accepted</span>
              <span className="text-base font-bold text-emerald-400">{validationSummary.validRows}</span>
            </div>
            <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg">
              <span className="text-[10px] text-slate-400 block font-sans">Rejected / Malformed</span>
              <span className={`text-base font-bold ${validationSummary.rejectedRows > 0 ? 'text-rose-400' : 'text-slate-500'}`}>
                {validationSummary.rejectedRows}
              </span>
            </div>
            <div className="bg-slate-950 border border-slate-800 p-3 rounded-lg">
              <span className="text-[10px] text-slate-400 block font-sans">Chronological Order</span>
              <span className={`text-base font-bold ${validationSummary.isChronological ? 'text-emerald-400' : 'text-amber-400'}`}>
                {validationSummary.isChronological ? 'Strict' : 'Re-Sorted'}
              </span>
            </div>
          </div>

          {/* Error List if any */}
          {validationSummary.errors.length > 0 && (
            <div className="p-3 bg-rose-950/30 border border-rose-900/60 rounded-lg space-y-1.5">
              <div className="text-xs font-semibold text-rose-300 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Data Quality Findings ({validationSummary.errors.length})</span>
              </div>
              <ul className="text-[11px] font-mono text-rose-200/90 list-disc list-inside space-y-0.5 max-h-36 overflow-y-auto">
                {validationSummary.errors.slice(0, 10).map((err, idx) => (
                  <li key={idx}>
                    Row {err.row}: {err.message}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Valid Telemetry Data Preview Table */}
          {validRecords.length > 0 && (
            <div className="mt-4">
              <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                <span>Accepted Telemetry Records Preview (First 10 rows):</span>
                <span>Time range: {validationSummary.startDate?.split('T')[0]} to {validationSummary.endDate?.split('T')[0]}</span>
              </div>
              <div className="overflow-x-auto border border-slate-800 rounded-lg max-h-64">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="sticky top-0 bg-slate-950 border-b border-slate-800 text-slate-400 font-sans text-[11px]">
                    <tr>
                      <th className="py-2 px-3">#</th>
                      <th className="py-2 px-3">Timestamp</th>
                      <th className="py-2 px-3 text-right">Ambient Temp (°C)</th>
                      <th className="py-2 px-3 text-right">Humidity (%)</th>
                      <th className="py-2 px-3 text-right">Solar Irradiance (W/m²)</th>
                      {validationSummary.hasTargetDemand && (
                        <th className="py-2 px-3 text-right text-emerald-400">Target Demand (kW)</th>
                      )}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 bg-slate-900/40">
                    {validRecords.slice(0, 10).map((r, i) => (
                      <tr key={i} className="hover:bg-slate-800/30">
                        <td className="py-1.5 px-3 text-slate-500">{i + 1}</td>
                        <td className="py-1.5 px-3 text-slate-300">{r.timestamp}</td>
                        <td className="py-1.5 px-3 text-right text-slate-200 tabular-nums">{r.ambient_temp_c}</td>
                        <td className="py-1.5 px-3 text-right text-slate-400 tabular-nums">{r.humidity_pct}</td>
                        <td className="py-1.5 px-3 text-right text-amber-300 tabular-nums">{r.solar_irradiance_wm2}</td>
                        {validationSummary.hasTargetDemand && (
                          <td className="py-1.5 px-3 text-right text-emerald-400 font-bold tabular-nums">
                            {r.target_demand_kw ?? '--'}
                          </td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
