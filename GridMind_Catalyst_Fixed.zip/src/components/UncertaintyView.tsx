/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Conformal Prediction & Uncertainty View
 * HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine
 * 
 * Features:
 * - Split conformal prediction intervals (80%, 90%, 95% nominal bounds)
 * - Calibrated on chronological residual quantiles without Gaussian error assumptions
 * - Empirical validation coverage tracking
 * - High-uncertainty hour risk identification for microgrid dispatch
 * - Dual execution mode: Express server API with in-browser client engine fallback for Zoho Catalyst Slate
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  ShieldAlert,
  RefreshCw,
  AlertCircle,
  Activity,
  Server,
  Cpu,
} from 'lucide-react';
import type { ForecastHourResult, TelemetryRow, UncertaintyAnalysisResult } from '../types/microgrid.ts';
import { safeFetchJson } from '../utils/apiClient.ts';
import { computeConformalUncertainty } from '../engine/uncertaintyEngine.ts';
import { generateSynthetic24HourTelemetry, executeForecast } from '../engine/forecastingEngine.ts';

interface UncertaintyViewProps {
  forecastData?: ForecastHourResult[];
  calibrationRows?: TelemetryRow[];
}

export const UncertaintyView: React.FC<UncertaintyViewProps> = ({
  forecastData = [],
  calibrationRows = [],
}) => {
  const [data, setData] = useState<UncertaintyAnalysisResult | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedConfidence, setSelectedConfidence] = useState<'80' | '90' | '95'>('90');
  const [executionSource, setExecutionSource] = useState<'server' | 'client'>('server');

  const fetchUncertainty = useCallback(async () => {
    setLoading(true);
    setError(null);

    // 1. Attempt safe API fetch from backend
    const apiRes = await safeFetchJson<UncertaintyAnalysisResult & { success?: boolean }>('/api/ml/uncertainty');

    if (apiRes.ok && apiRes.data && (apiRes.data.success || apiRes.data.intervals)) {
      setData(apiRes.data);
      setExecutionSource('server');
      setLoading(false);
      return;
    }

    // 2. If API returned HTML (Zoho Catalyst Slate static mode) or is unreachable:
    // Execute Conformal Prediction Engine directly in-browser!
    try {
      let activeForecast = forecastData;
      if (activeForecast.length === 0) {
        const seed = generateSynthetic24HourTelemetry();
        const output = await executeForecast(seed);
        activeForecast = output.results;
      }

      let calRows = calibrationRows.filter(r => r.target_demand_kw !== undefined && !isNaN(r.target_demand_kw));
      if (calRows.length < 5) {
        // Fallback to calibrated seed telemetry
        const seed = generateSynthetic24HourTelemetry();
        calRows = seed.map(r => ({
          ...r,
          target_demand_kw: Math.round(90 + r.ambient_temp_c * 2.5 + (r.solar_irradiance_wm2 / 1000) * 35),
        }));
      }

      const clientResult = computeConformalUncertainty(calRows, activeForecast);
      setData(clientResult);
      setExecutionSource('client');
    } catch (computeErr: unknown) {
      const msg = computeErr instanceof Error ? computeErr.message : String(computeErr);
      setError(`Unable to compute uncertainty intervals: ${msg}`);
    } finally {
      setLoading(false);
    }
  }, [forecastData, calibrationRows]);

  useEffect(() => {
    fetchUncertainty();
  }, [fetchUncertainty]);

  return (
    <div className="space-y-6 max-w-6xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-slate-100 flex items-center gap-2">
              <ShieldAlert className="w-6 h-6 text-cyan-400" />
              Forecast Uncertainty & Conformal Bounds
            </h1>
            {data && (
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded border flex items-center gap-1 ${
                executionSource === 'server'
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  : 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
              }`}>
                {executionSource === 'server' ? (
                  <>
                    <Server className="w-3 h-3" />
                    <span>AppSail API</span>
                  </>
                ) : (
                  <>
                    <Cpu className="w-3 h-3" />
                    <span>Slate Client Engine</span>
                  </>
                )}
              </span>
            )}
          </div>
          <p className="text-sm text-slate-400 mt-1">
            Distribution-free split conformal prediction intervals calibrated on chronological validation residuals.
          </p>
        </div>

        <button
          onClick={fetchUncertainty}
          disabled={loading}
          className="self-start sm:self-auto py-2 px-3.5 bg-slate-800 hover:bg-slate-700 disabled:bg-slate-900 text-slate-200 text-xs font-medium rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          Recalculate Bounds
        </button>
      </div>

      {loading ? (
        <div className="h-64 flex flex-col items-center justify-center text-slate-400 bg-slate-900 border border-slate-800 rounded-xl">
          <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin mb-3" />
          <p className="text-sm">Calculating conformal non-conformity quantiles on validation split...</p>
        </div>
      ) : error ? (
        <div className="p-4 bg-rose-950/40 border border-rose-500/30 text-rose-300 rounded-xl text-sm flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{error}</span>
          </div>
          <button
            onClick={fetchUncertainty}
            className="px-3 py-1 bg-rose-900/60 hover:bg-rose-800 text-white rounded text-xs"
          >
            Retry
          </button>
        </div>
      ) : data ? (
        <div className="space-y-6">
          {/* Summary Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <span className="text-xs text-slate-400">90% Empirical Coverage</span>
              <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
                {data.coverage90Pct}%
              </div>
              <span className="text-[11px] text-slate-500 mt-0.5 block">Theoretical nominal: 90.0%</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <span className="text-xs text-slate-400">90% Margin (q̂_0.90)</span>
              <div className="text-2xl font-bold font-mono text-cyan-400 mt-1">
                ±{data.quantile90Kw} <span className="text-xs font-normal text-slate-400">kW</span>
              </div>
              <span className="text-[11px] text-slate-500 mt-0.5 block">Non-conformity quantile</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <span className="text-xs text-slate-400">95% Margin (q̂_0.95)</span>
              <div className="text-2xl font-bold font-mono text-purple-400 mt-1">
                ±{data.quantile95Kw} <span className="text-xs font-normal text-slate-400">kW</span>
              </div>
              <span className="text-[11px] text-slate-500 mt-0.5 block">Severe risk interval</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <span className="text-xs text-slate-400">Calibration Set</span>
              <div className="text-xl font-bold font-mono text-slate-200 mt-1">
                {data.calibrationSampleCount} <span className="text-xs font-normal text-slate-400">samples</span>
              </div>
              <span className="text-[11px] text-slate-500 mt-0.5 block">RMSE: {data.calibrationRmse} kW</span>
            </div>
          </div>

          {/* Confidence Level Selector */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 p-3 rounded-xl border border-slate-800">
            <div className="flex items-center gap-3">
              <span className="text-xs font-medium text-slate-300">Confidence Band:</span>
              <div className="flex gap-2">
                {(['80', '90', '95'] as const).map(conf => (
                  <button
                    key={conf}
                    onClick={() => setSelectedConfidence(conf)}
                    className={`px-3 py-1 rounded text-xs font-medium transition-colors cursor-pointer ${
                      selectedConfidence === conf
                        ? 'bg-cyan-600 text-white'
                        : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {conf}% Interval (±{conf === '80' ? data.quantile80Kw : conf === '90' ? data.quantile90Kw : data.quantile95Kw} kW)
                  </button>
                ))}
              </div>
            </div>
            <span className="text-xs font-mono text-slate-400">
              {executionSource === 'server' ? 'Source: Express Backend' : 'Source: Slate Client Engine'}
            </span>
          </div>

          {/* Hourly Intervals Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-semibold text-slate-200 text-sm flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                24-Hour Horizon Prediction Intervals
              </h3>
              <span className="text-xs text-slate-400">
                Guaranteed coverage with zero Gaussian error assumptions
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
                  <tr>
                    <th className="p-2.5">Hour</th>
                    <th className="p-2.5">Point Forecast (kW)</th>
                    <th className="p-2.5">Lower Bound (kW)</th>
                    <th className="p-2.5">Upper Bound (kW)</th>
                    <th className="p-2.5">Interval Bandwidth</th>
                    <th className="p-2.5">Overload Risk (&gt;200 kW)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {data.intervals.map(pt => {
                    const lower =
                      selectedConfidence === '80'
                        ? pt.lower80Kw
                        : selectedConfidence === '90'
                        ? pt.lower90Kw
                        : pt.lower95Kw;
                    const upper =
                      selectedConfidence === '80'
                        ? pt.upper80Kw
                        : selectedConfidence === '90'
                        ? pt.upper90Kw
                        : pt.upper95Kw;
                    const width = Number((upper - lower).toFixed(1));
                    const isOverloadRisk = upper >= 200.0;

                    return (
                      <tr key={pt.timestamp} className="hover:bg-slate-800/40">
                        <td className="p-2.5 text-slate-300">
                          {String(pt.hour).padStart(2, '0')}:00
                        </td>
                        <td className="p-2.5 font-bold text-cyan-400">
                          {pt.predictedDemandKw}
                        </td>
                        <td className="p-2.5 text-slate-400">{lower}</td>
                        <td className="p-2.5 text-slate-400">{upper}</td>
                        <td className="p-2.5 text-purple-400">{width} kW</td>
                        <td className="p-2.5">
                          {isOverloadRisk ? (
                            <span className="text-[10px] px-2 py-0.5 rounded font-sans font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center gap-1 w-fit">
                              <AlertCircle className="w-3 h-3" />
                              Upper Exceeds 200 kW
                            </span>
                          ) : (
                            <span className="text-[10px] px-2 py-0.5 rounded font-sans font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 w-fit">
                              Nominal Range
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-xs text-slate-400 leading-relaxed">
              <span className="font-semibold text-slate-300">Theory Note:</span> {data.methodDescription}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};
