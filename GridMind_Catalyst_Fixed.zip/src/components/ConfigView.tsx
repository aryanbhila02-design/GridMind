/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Secure System Configuration & Catalyst Status View
 * HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine
 * 
 * Strict Security Architecture (Phase 2):
 * - No API keys or secrets stored or editable in the browser
 * - Safe status monitoring of server-side QuickML environment variables
 * - Direct SSRF-safe connection test to verified server configuration
 * - Battery parameter configuration with persistent storage
 */

import React, { useState, useEffect } from 'react';
import {
  Settings,
  Cpu,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Terminal,
  Zap,
  Sliders,
  Database,
  Lock,
} from 'lucide-react';
import type { BatteryConfig, QuickMLConfig } from '../types/microgrid.ts';
import { safeFetchJson } from '../utils/apiClient.ts';

interface ConfigViewProps {
  batteryConfig: BatteryConfig;
  onSaveBatteryConfig: (config: BatteryConfig) => void;
  metadata: {
    modelUsed: string;
    isQuickMlLive: boolean;
    forecastingMode: string;
    timestamp: string;
  };
}

export const ConfigView: React.FC<ConfigViewProps> = ({
  batteryConfig,
  onSaveBatteryConfig,
  metadata,
}) => {
  // QuickML Server Status
  const [quickmlStatus, setQuickmlStatus] = useState<{
    isConfigured: boolean;
    hostDomain: string;
    catalystEnv: string;
    connectionStatus: string;
    lastTestedAt: string | null;
    statusMessage: string;
  }>({
    isConfigured: false,
    hostDomain: '',
    catalystEnv: 'development',
    connectionStatus: 'not_configured',
    lastTestedAt: null,
    statusMessage: 'Loading status...',
  });

  // Battery Form State
  const [battCapacity, setBattCapacity] = useState(batteryConfig.capacity_kwh);
  const [battInitialSoc, setBattInitialSoc] = useState(batteryConfig.initial_soc_pct);
  const [battMaxCharge, setBattMaxCharge] = useState(batteryConfig.max_charge_kw);
  const [battMaxDischarge, setBattMaxDischarge] = useState(batteryConfig.max_discharge_kw);
  const [battMinSoc, setBattMinSoc] = useState(batteryConfig.min_soc_pct);
  const [battEfficiency, setBattEfficiency] = useState(batteryConfig.efficiency_pct);

  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{
    connected: boolean;
    latencyMs: number;
    message: string;
    status?: string;
  } | null>(null);

  const [savedSuccess, setSavedSuccess] = useState(false);

  // Fetch server-side QuickML config status
  const fetchStatus = async () => {
    const res = await safeFetchJson<{
      isConfigured: boolean;
      hostDomain: string;
      catalystEnv: string;
      connectionStatus: string;
      lastTestedAt: string | null;
      statusMessage: string;
    }>('/api/quickml/config');

    if (res.ok && res.data) {
      setQuickmlStatus(res.data);
    } else if (res.isHtmlResponse) {
      setQuickmlStatus({
        isConfigured: false,
        hostDomain: 'Slate Static Mode',
        catalystEnv: 'production (slate)',
        connectionStatus: 'not_configured',
        lastTestedAt: null,
        statusMessage: 'Zoho Catalyst Slate static frontend active. Backend API routed separately or via API Gateway.',
      });
    }
  };

  useEffect(() => {
    fetchStatus();
  }, []);

  // SSRF-safe connection test: server uses its own environment configuration
  const handleTestConnection = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await safeFetchJson<{
        connected: boolean;
        latencyMs: number;
        message: string;
        status?: string;
      }>('/api/quickml/test-connection', {
        method: 'POST',
      });

      if (res.ok && res.data) {
        setTestResult(res.data);
        fetchStatus();
      } else {
        setTestResult({
          connected: false,
          latencyMs: 0,
          message: res.error || 'Server endpoint unreachable on static hosting without API Gateway proxy.',
        });
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      setTestResult({
        connected: false,
        latencyMs: 0,
        message: message || 'Network connection test failed',
      });
    } finally {
      setTesting(false);
    }
  };

  // Save Battery Parameters to server persistence
  const handleSaveBattery = async (e: React.FormEvent) => {
    e.preventDefault();
    const updated: BatteryConfig = {
      capacity_kwh: Number(battCapacity),
      initial_soc_pct: Number(battInitialSoc),
      max_charge_kw: Number(battMaxCharge),
      max_discharge_kw: Number(battMaxDischarge),
      min_soc_pct: Number(battMinSoc),
      efficiency_pct: Number(battEfficiency),
      low_soc_warning_pct: 20,
    };

    try {
      const res = await safeFetchJson('/api/battery/config', {
        method: 'POST',
        body: JSON.stringify({ config: updated }),
      });

      onSaveBatteryConfig(updated);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch {
      onSaveBatteryConfig(updated);
    }
  };

  return (
    <div className="space-y-6 max-w-6xl">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-100 flex items-center gap-2">
          <Settings className="w-6 h-6 text-cyan-400" />
          System Configuration & Environment
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          Server-side Zoho Catalyst credentials status, safe operational thresholds, and battery storage parameters.
        </p>
      </div>

      {/* Security Architecture Badge */}
      <div className="p-4 bg-emerald-950/30 border border-emerald-500/30 rounded-xl flex items-start gap-3">
        <Lock className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
        <div>
          <h4 className="text-sm font-semibold text-emerald-300">
            Zero-Secret Client Architecture (Phase 2 Compliant)
          </h4>
          <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
            API keys and tokens are strictly excluded from client-side state, browser storage, and network payloads.
            All external QuickML requests originate exclusively from the server-side runtime via protected environment variables.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Section 1: Zoho Catalyst QuickML Server Status */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Cpu className="w-5 h-5 text-cyan-400" />
              <h3 className="font-semibold text-slate-200">Zoho Catalyst QuickML Status</h3>
            </div>
            <span
              className={`text-xs px-2.5 py-1 rounded-full font-medium flex items-center gap-1.5 ${
                quickmlStatus.connectionStatus === 'connected_verified'
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                  : quickmlStatus.isConfigured
                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}
            >
              {quickmlStatus.connectionStatus === 'connected_verified'
                ? 'Verified Connected'
                : quickmlStatus.isConfigured
                ? 'Config Incomplete'
                : 'Not Configured (Demo Mode)'}
            </span>
          </div>

          <div className="space-y-3 text-sm">
            <div className="flex justify-between items-center py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Endpoint Configured</span>
              <span className="font-medium text-slate-200">
                {quickmlStatus.isConfigured ? 'Yes (Server Environment)' : 'No (Using Local Trained Ridge Fallback)'}
              </span>
            </div>

            <div className="flex justify-between items-center py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Endpoint Host</span>
              <span className="font-mono text-xs text-slate-300">
                {quickmlStatus.hostDomain || 'quickml.catalyst.zoho.com (default)'}
              </span>
            </div>

            <div className="flex justify-between items-center py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Catalyst Environment</span>
              <span className="capitalize text-slate-200 font-medium">{quickmlStatus.catalystEnv}</span>
            </div>

            <div className="flex justify-between items-center py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Active Forecasting Mode</span>
              <span className="font-mono text-xs text-cyan-400">{metadata.forecastingMode}</span>
            </div>

            <div className="flex justify-between items-center py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Last Successful Forecast</span>
              <span className="text-xs text-slate-300">
                {metadata.timestamp ? new Date(metadata.timestamp).toLocaleTimeString() : 'N/A'}
              </span>
            </div>
          </div>

          {/* Connection Test Action */}
          <div className="pt-2">
            <button
              onClick={handleTestConnection}
              disabled={testing}
              className="w-full py-2.5 px-4 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-800 text-white font-medium rounded-lg text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${testing ? 'animate-spin' : ''}`} />
              {testing ? 'Testing Server Endpoint...' : 'Test Server QuickML Connection'}
            </button>
          </div>

          {/* Test Result Feedback */}
          {testResult && (
            <div
              className={`p-3.5 rounded-lg text-xs leading-relaxed border ${
                testResult.connected
                  ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                  : 'bg-amber-950/40 border-amber-500/30 text-amber-300'
              }`}
            >
              <div className="flex items-center gap-2 font-semibold mb-1">
                {testResult.connected ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                )}
                {testResult.connected ? 'Endpoint Live & Verified' : 'QuickML Notice'}
                {testResult.latencyMs > 0 && (
                  <span className="text-slate-400 font-normal">({testResult.latencyMs}ms)</span>
                )}
              </div>
              <p className="text-slate-300">{testResult.message}</p>
            </div>
          )}

          {/* Setup Guide Accordion */}
          <div className="p-3.5 bg-slate-950/50 rounded-lg border border-slate-800 text-xs text-slate-400 space-y-1.5">
            <div className="font-semibold text-slate-300 flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              Configuring QuickML via Environment Variables
            </div>
            <p>
              In production or local development, set the following keys in your server runtime:
            </p>
            <div className="bg-slate-900 p-2 rounded font-mono text-[11px] text-slate-300 space-y-0.5 border border-slate-800">
              <div>ZOHO_QUICKML_ENDPOINT=https://quickml.catalyst.zoho.com/...</div>
              <div>ZOHO_CATALYST_API_KEY=Zoho-oauthtoken_...</div>
              <div>ZOHO_PROJECT_ID=10000000...</div>
            </div>
          </div>
        </div>

        {/* Section 2: Battery Storage Physical Parameters */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Sliders className="w-5 h-5 text-amber-400" />
              <h3 className="font-semibold text-slate-200">BESS Storage Configuration</h3>
            </div>
            <span className="text-xs text-slate-400 flex items-center gap-1">
              <Database className="w-3 h-3 text-cyan-400" />
              Persisted to Disk
            </span>
          </div>

          <form onSubmit={handleSaveBattery} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Total Capacity (kWh)
                </label>
                <input
                  type="number"
                  min="50"
                  max="5000"
                  value={battCapacity}
                  onChange={e => setBattCapacity(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Initial State of Charge (%)
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={battInitialSoc}
                  onChange={e => setBattInitialSoc(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Max Charge Rate (kW)
                </label>
                <input
                  type="number"
                  min="10"
                  max="1000"
                  value={battMaxCharge}
                  onChange={e => setBattMaxCharge(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Max Discharge Rate (kW)
                </label>
                <input
                  type="number"
                  min="10"
                  max="1000"
                  value={battMaxDischarge}
                  onChange={e => setBattMaxDischarge(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Minimum Reserve Buffer (%)
                </label>
                <input
                  type="number"
                  min="5"
                  max="30"
                  value={battMinSoc}
                  onChange={e => setBattMinSoc(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Roundtrip Efficiency (%)
                </label>
                <input
                  type="number"
                  min="70"
                  max="98"
                  value={battEfficiency}
                  onChange={e => setBattEfficiency(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-100 font-medium rounded-lg text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Zap className="w-4 h-4 text-amber-400" />
                Save & Persist Storage Parameters
              </button>
            </div>

            {savedSuccess && (
              <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                Battery parameters successfully updated and persisted across restarts.
              </div>
            )}
          </form>

          {/* Operational Boundaries Notice */}
          <div className="p-3 bg-slate-950/40 rounded-lg border border-slate-800/80 text-xs text-slate-400 space-y-1">
            <div className="font-semibold text-slate-300">HackSphere 3.0 Operational Boundaries:</div>
            <div>• Renewable Storage Mode engaged if demand &gt; 160 kW or hour ∈ [18:00..22:00]</div>
            <div>• Critical Overload threshold fixed at ≥ 200 kW (transformer protection)</div>
          </div>
        </div>
      </div>
    </div>
  );
};
