/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Peak Demand Intelligence View
 * HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine
 * 
 * Features:
 * - Real-time calculation of peak kW, base load, and grid load factor
 * - Threshold tracking: hours > 160 kW (storage dispatch) and hours >= 200 kW (critical overload)
 * - Maximum grid ramp-rate (kW/h) detection
 * - Battery peak shaving quantification and solar curtailment audit
 * - Dual execution mode: Express server API with in-browser client engine fallback for Zoho Catalyst Slate
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  Flame,
  Zap,
  TrendingUp,
  BatteryCharging,
  Clock,
  ArrowUpRight,
  ShieldCheck,
  RefreshCw,
  Server,
  Cpu,
  Info,
} from 'lucide-react';
import type { ForecastHourResult, PeakIntelligenceSummary } from '../types/microgrid.ts';
import { safeFetchJson } from '../utils/apiClient.ts';
import { computePeakIntelligence } from '../engine/peakIntelligenceEngine.ts';
import { generateSynthetic24HourTelemetry, executeForecast } from '../engine/forecastingEngine.ts';

interface PeakIntelligenceViewProps {
  forecastData?: ForecastHourResult[];
}

export const PeakIntelligenceView: React.FC<PeakIntelligenceViewProps> = ({ forecastData = [] }) => {
  const [summary, setSummary] = useState<PeakIntelligenceSummary | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [executionSource, setExecutionSource] = useState<'server' | 'client'>('server');

  const fetchPeakData = useCallback(async () => {
    setLoading(true);
    setError(null);

    // 1. Attempt safe API fetch from backend
    const apiRes = await safeFetchJson<{ success?: boolean; summary: PeakIntelligenceSummary }>('/api/ml/peak-intelligence');

    if (apiRes.ok && apiRes.data?.summary) {
      setSummary(apiRes.data.summary);
      setExecutionSource('server');
      setLoading(false);
      return;
    }

    // 2. If API returned HTML (Zoho Catalyst Slate static mode) or is unreachable:
    // Execute Peak Demand Intelligence Engine directly in-browser!
    try {
      let activeForecast = forecastData;
      if (activeForecast.length === 0) {
        const seed = generateSynthetic24HourTelemetry();
        const output = await executeForecast(seed);
        activeForecast = output.results;
      }

      const clientSummary = computePeakIntelligence(activeForecast);
      setSummary(clientSummary);
      setExecutionSource('client');
    } catch (computeErr: unknown) {
      const msg = computeErr instanceof Error ? computeErr.message : String(computeErr);
      setError(`Unable to compute peak intelligence: ${msg}`);
    } finally {
      setLoading(false);
    }
  }, [forecastData]);

  useEffect(() => {
    fetchPeakData();
  }, [fetchPeakData]);

  return (
    <div className="space-y-6 max-w-6xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-slate-100 flex items-center gap-2">
              <Flame className="w-6 h-6 text-amber-400" />
              Peak Demand Intelligence & Feeder Analytics
            </h1>
            {summary && (
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded border flex items-center gap-1 ${
                executionSource === 'server'
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  : 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
              }`}>
                {executionSource === 'server' ? (
                  <>
                    <Server className="w-3 h-3" />
                    <span>AppSail API</span>
                  </>
                ) : (
                  <>
                    <Cpu className="w-3 h-3" />
                    <span>Slate Client Engine</span>
                  </>
                )}
              </span>
            )}
          </div>
          <p className="text-sm text-slate-400 mt-1">
            Analyzing diurnal peak surges, steep ramp rates, threshold exceedance, and storage shaving efficacy.
          </p>
        </div>

        <button
          onClick={fetchPeakData}
          disabled={loading}
          className="self-start sm:self-auto py-2 px-3.5 bg-slate-800 hover:bg-slate-700 disabled:bg-slate-900 text-slate-200 text-xs font-medium rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          Refresh Analytics
        </button>
      </div>

      {loading ? (
        <div className="h-64 flex flex-col items-center justify-center text-slate-400 bg-slate-900 border border-slate-800 rounded-xl">
          <RefreshCw className="w-8 h-8 text-amber-400 animate-spin mb-3" />
          <p className="text-sm">Evaluating 24-hour dispatch curve for peak characteristics...</p>
        </div>
      ) : error ? (
        <div className="p-4 bg-rose-950/40 border border-rose-500/30 text-rose-300 rounded-xl text-sm flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{error}</span>
          </div>
          <button
            onClick={fetchPeakData}
            className="px-3 py-1 bg-rose-900/60 hover:bg-rose-800 text-white rounded text-xs"
          >
            Retry
          </button>
        </div>
      ) : summary ? (
        <div className="space-y-6">
          {/* Key Metrics Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Peak Demand</span>
                <Clock className="w-3.5 h-3.5 text-amber-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-amber-400 mt-1">
                {summary.peakDemandKw} <span className="text-xs font-normal text-slate-400">kW</span>
              </div>
              <span className="text-[11px] text-slate-500 mt-0.5 block">
                Occurs at hour {String(summary.peakHour).padStart(2, '0')}:00
              </span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Base Facility Load</span>
                <Zap className="w-3.5 h-3.5 text-cyan-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-cyan-400 mt-1">
                {summary.baseLoadKw} <span className="text-xs font-normal text-slate-400">kW</span>
              </div>
              <span className="text-[11px] text-slate-500 mt-0.5 block">
                Minimum at {String(summary.baseHour).padStart(2, '0')}:00
              </span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Grid Load Factor</span>
                <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
                {summary.loadFactor}
              </div>
              <span className="text-[11px] text-slate-500 mt-0.5 block">
                Average ({summary.averageDemandKw} kW) / Peak
              </span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Max Ramp Rate</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-purple-400" />
              </div>
              <div className="text-2xl font-bold font-mono text-purple-400 mt-1">
                {summary.maxRampRateKwPerHour} <span className="text-xs font-normal text-slate-400">kW/h</span>
              </div>
              <span className="text-[11px] text-slate-500 mt-0.5 block">Maximum steepness delta</span>
            </div>
          </div>

          {/* Threshold Compliance & Grid Rules Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <h3 className="font-semibold text-slate-200 text-sm flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-cyan-400" />
                  HackSphere 3.0 Threshold Auditing
                </h3>
                <span className="text-xs font-mono text-slate-400">
                  {executionSource === 'server' ? 'Source: Express Backend' : 'Source: Slate Client Engine'}
                </span>
              </div>

              <div className="space-y-3">
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-xs text-slate-300 font-medium">Hours Exceeding 160 kW</span>
                    <p className="text-[11px] text-slate-500">Triggers Renewable Storage Mode dispatch</p>
                  </div>
                  <div className="text-lg font-bold font-mono text-amber-400">
                    {summary.hoursOver160Kw} <span className="text-xs font-normal text-slate-400">hours</span>
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-xs text-slate-300 font-medium">Hours in Critical Overload (≥ 200 kW)</span>
                    <p className="text-[11px] text-slate-500">Exceeds microgrid transformer rating</p>
                  </div>
                  <div className="text-lg font-bold font-mono text-rose-400">
                    {summary.hoursCriticalOverload200Kw} <span className="text-xs font-normal text-slate-400">hours</span>
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-xs text-slate-300 font-medium">Solar Energy Curtailed</span>
                    <p className="text-[11px] text-slate-500">Generation exceeding battery capacity</p>
                  </div>
                  <div className="text-lg font-bold font-mono text-cyan-400">
                    {summary.curtailedSolarKwh} <span className="text-xs font-normal text-slate-400">kWh</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <h3 className="font-semibold text-slate-200 text-sm flex items-center gap-2">
                  <BatteryCharging className="w-4 h-4 text-emerald-400" />
                  Peak Shaving Performance
                </h3>
              </div>

              <div className="p-4 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
                <span className="text-xs text-slate-400">Maximum Battery Shaving Relief</span>
                <div className="text-2xl font-bold font-mono text-emerald-400">
                  {summary.storagePeakReductionKw} <span className="text-xs font-normal text-slate-400">kW</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Peak shaving represents the maximum simultaneous battery discharge actively offsetting peak feeder demand during the critical evening window.
                </p>
              </div>

              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-xs text-slate-400 space-y-1 font-mono">
                <div className="text-slate-300 font-sans font-semibold">Peak Window Hours Identified:</div>
                <div className="text-cyan-400">
                  {summary.peakWindowHours.length > 0
                    ? summary.peakWindowHours.map(h => `${String(h).padStart(2, '0')}:00`).join(', ')
                    : 'No hours exceeded 160 kW.'}
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};
