/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Comprehensive Unit Tests for RFC 4180 CSV Engine & Telemetry Validator (Phase 11)
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { parseCsvText, validateTelemetryCsv } from '../engine/telemetryValidator.ts';

test('CSV Parser: Handles standard comma separation', () => {
  const csv = 'timestamp,ambient_temp_c,humidity_pct,solar_irradiance_wm2\n2026-10-27T00:00:00,19.2,74,0';
  const { headers, rows, parseErrors } = parseCsvText(csv);
  assert.equal(parseErrors.length, 0);
  assert.deepEqual(headers, ['timestamp', 'ambient_temp_c', 'humidity_pct', 'solar_irradiance_wm2']);
  assert.equal(rows.length, 1);
  assert.deepEqual(rows[0], ['2026-10-27T00:00:00', '19.2', '74', '0']);
});

test('CSV Parser: Handles commas inside quoted fields (RFC 4180)', () => {
  const csv = 'timestamp,city,ambient_temp_c\n"2026-10-27T00:00:00","New Delhi, India",19.2';
  const { headers, rows } = parseCsvText(csv);
  assert.deepEqual(headers, ['timestamp', 'city', 'ambient_temp_c']);
  assert.equal(rows.length, 1);
  assert.equal(rows[0][1], 'New Delhi, India');
});

test('CSV Parser: Handles escaped double quotes ("") (RFC 4180)', () => {
  const csv = 'id,name,value\n1,"Panel ""A"" High Efficiency",100';
  const { rows } = parseCsvText(csv);
  assert.equal(rows.length, 1);
  assert.equal(rows[0][1], 'Panel "A" High Efficiency');
});

test('CSV Parser: Handles both CRLF and LF line endings', () => {
  const csvCrlf = 'timestamp,ambient_temp_c\r\n2026-10-27T00:00:00,19.2\r\n2026-10-27T01:00:00,18.5\r\n';
  const resCrlf = parseCsvText(csvCrlf);
  assert.equal(resCrlf.rows.length, 2);

  const csvLf = 'timestamp,ambient_temp_c\n2026-10-27T00:00:00,19.2\n2026-10-27T01:00:00,18.5\n';
  const resLf = parseCsvText(csvLf);
  assert.equal(resLf.rows.length, 2);
});

test('CSV Parser: Handles UTF-8 BOM character (\\uFEFF)', () => {
  const csvBom = '\uFEFFtimestamp,ambient_temp_c\n2026-10-27T00:00:00,19.2';
  const { headers } = parseCsvText(csvBom);
  assert.equal(headers[0], 'timestamp');
});

test('CSV Validator: Detects duplicate headers', () => {
  const csvDup = 'timestamp,ambient_temp_c,timestamp\n2026-10-27T00:00:00,19.2,2026-10-27T00:00:00';
  const { summary } = validateTelemetryCsv(csvDup);
  assert.ok(summary.errors.some(e => e.message.includes('Duplicate header')));
});

test('CSV Validator: Reports missing required columns', () => {
  const csvBad = 'timestamp,ambient_temp_c\n2026-10-27T00:00:00,19.2';
  const { summary, validRecords } = validateTelemetryCsv(csvBad);
  assert.equal(validRecords.length, 0);
  assert.ok(summary.errors.some(e => e.message.includes('Missing required column(s)')));
});

test('CSV Validator: Isolates invalid rows without dropping valid rows', () => {
  const csvMixed = `timestamp,ambient_temp_c,humidity_pct,solar_irradiance_wm2
2026-10-27T00:00:00,19.2,74,0
2026-10-27T01:00:00,INVALID,78,0
2026-10-27T02:00:00,17.8,82,0`;

  const { validRecords, summary } = validateTelemetryCsv(csvMixed);
  assert.equal(summary.totalRows, 3);
  assert.equal(summary.validRows, 2);
  assert.equal(summary.rejectedRows, 1);
  assert.equal(validRecords.length, 2);
  assert.equal(validRecords[0].timestamp, '2026-10-27T00:00:00');
  assert.equal(validRecords[1].timestamp, '2026-10-27T02:00:00');
});
