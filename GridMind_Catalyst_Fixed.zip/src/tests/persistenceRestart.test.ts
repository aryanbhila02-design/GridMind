/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Comprehensive Unit Tests for Persistence Storage and Lifecycle Surviving Restarts (Phase 13)
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  savePersistedTelemetry,
  loadPersistedTelemetry,
  savePersistedForecast,
  loadPersistedForecast,
  savePersistedEvents,
  loadPersistedEvents,
  savePersistedSettings,
  loadPersistedSettings,
  isPersistenceLayerOperational,
} from '../engine/persistenceService.ts';
import type { TelemetryRow, GridEvent, BatteryConfig } from '../types/microgrid.ts';

test('Persistence Engine: Operational health check passes', () => {
  const isOp = isPersistenceLayerOperational();
  assert.equal(isOp, true, 'Persistence layer must be operational');
});

test('Persistence Engine: Settings survive save and reload without data corruption', () => {
  const customConfig: BatteryConfig = {
    capacity_kwh: 920,
    initial_soc_pct: 75,
    max_charge_kw: 180,
    max_discharge_kw: 220,
    efficiency_pct: 95,
    min_soc_pct: 18,
    low_soc_warning_pct: 22,
  };

  const success = savePersistedSettings({
    batteryConfig: customConfig,
    lastUpdated: new Date().toISOString(),
  });
  assert.equal(success, true);

  const loaded = loadPersistedSettings();
  assert.ok(loaded);
  assert.equal(loaded?.batteryConfig.capacity_kwh, 920);
  assert.equal(loaded?.batteryConfig.initial_soc_pct, 75);
  assert.equal(loaded?.batteryConfig.max_charge_kw, 180);
});

test('Persistence Engine: Telemetry rows survive save and reload', () => {
  const sampleRows: TelemetryRow[] = [
    {
      timestamp: '2026-10-27T00:00:00',
      ambient_temp_c: 19.2,
      humidity_pct: 74,
      solar_irradiance_wm2: 0,
      target_demand_kw: 90.42,
    },
    {
      timestamp: '2026-10-27T01:00:00',
      ambient_temp_c: 18.5,
      humidity_pct: 78,
      solar_irradiance_wm2: 0,
      target_demand_kw: 90.11,
    },
  ];

  const success = savePersistedTelemetry(sampleRows);
  assert.equal(success, true);

  const loaded = loadPersistedTelemetry();
  assert.equal(loaded.length, 2);
  assert.equal(loaded[0].timestamp, '2026-10-27T00:00:00');
  assert.equal(loaded[0].target_demand_kw, 90.42);
});

test('Persistence Engine: Event log accumulates without silent deletion of history', () => {
  const testEvent: GridEvent = {
    id: `evt-test-${Date.now()}`,
    timestamp: new Date().toISOString(),
    type: 'MODE_CHANGE',
    severity: 'info',
    title: 'Automated Dispatch Check',
    detail: 'Persistence validation event.',
  };

  const existing = loadPersistedEvents();
  const updated = [testEvent, ...existing];
  savePersistedEvents(updated);

  const reloaded = loadPersistedEvents();
  assert.ok(reloaded.length >= 1);
  assert.equal(reloaded[0].id, testEvent.id);
  assert.equal(reloaded[0].title, 'Automated Dispatch Check');
});
