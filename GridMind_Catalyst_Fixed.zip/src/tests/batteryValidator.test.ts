/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Comprehensive Unit Tests for Battery Configuration Validator (Phase 6)
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { validateBatteryConfig } from '../engine/batteryValidator.ts';
import { DEFAULT_BATTERY_CONFIG } from '../engine/batterySimulator.ts';
import type { BatteryConfig } from '../types/microgrid.ts';

test('Battery Validator: Valid full configuration passes', () => {
  const input: BatteryConfig = {
    capacity_kwh: 800,
    initial_soc_pct: 65,
    max_charge_kw: 150,
    max_discharge_kw: 200,
    efficiency_pct: 94,
    min_soc_pct: 15,
    low_soc_warning_pct: 20,
  };
  const result = validateBatteryConfig(input, DEFAULT_BATTERY_CONFIG);
  assert.equal(result.isValid, true);
  assert.deepEqual(result.config, input);
  assert.deepEqual(result.errors, {});
});

test('Battery Validator: Explicit zero for power limits is preserved, not replaced with default', () => {
  const input = {
    max_charge_kw: 0,
    max_discharge_kw: 0,
  };
  const result = validateBatteryConfig(input, DEFAULT_BATTERY_CONFIG);
  assert.equal(result.isValid, true);
  assert.equal(result.config?.max_charge_kw, 0, 'Explicit 0 max_charge_kw must be 0, not default');
  assert.equal(result.config?.max_discharge_kw, 0, 'Explicit 0 max_discharge_kw must be 0, not default');
  assert.equal(result.config?.capacity_kwh, DEFAULT_BATTERY_CONFIG.capacity_kwh, 'Omitted fields retain existing values');
});

test('Battery Validator: Rejects capacity <= 0', () => {
  const resZero = validateBatteryConfig({ capacity_kwh: 0 }, DEFAULT_BATTERY_CONFIG);
  assert.equal(resZero.isValid, false);
  assert.ok(resZero.errors.capacity_kwh, 'Should return error for capacity_kwh: 0');

  const resNeg = validateBatteryConfig({ capacity_kwh: -500 }, DEFAULT_BATTERY_CONFIG);
  assert.equal(resNeg.isValid, false);
  assert.ok(resNeg.errors.capacity_kwh, 'Should return error for negative capacity');
});

test('Battery Validator: Rejects non-finite values (NaN, Infinity)', () => {
  const resNaN = validateBatteryConfig({ capacity_kwh: NaN }, DEFAULT_BATTERY_CONFIG);
  assert.equal(resNaN.isValid, false);
  assert.ok(resNaN.errors.capacity_kwh);

  const resInf = validateBatteryConfig({ max_charge_kw: Infinity }, DEFAULT_BATTERY_CONFIG);
  assert.equal(resInf.isValid, false);
  assert.ok(resInf.errors.max_charge_kw);
});

test('Battery Validator: Rejects initial_soc_pct < min_soc_pct', () => {
  const result = validateBatteryConfig(
    { initial_soc_pct: 10, min_soc_pct: 20 },
    DEFAULT_BATTERY_CONFIG
  );
  assert.equal(result.isValid, false);
  assert.ok(result.errors.initial_soc_pct, 'Initial SOC below minimum reserve must be rejected');
});

test('Battery Validator: Rejects percentages outside 0..100 and efficiency outside 1..100', () => {
  const resSocHigh = validateBatteryConfig({ initial_soc_pct: 120 }, DEFAULT_BATTERY_CONFIG);
  assert.equal(resSocHigh.isValid, false);
  assert.ok(resSocHigh.errors.initial_soc_pct);

  const resEffZero = validateBatteryConfig({ efficiency_pct: 0 }, DEFAULT_BATTERY_CONFIG);
  assert.equal(resEffZero.isValid, false);
  assert.ok(resEffZero.errors.efficiency_pct);
});

test('Battery Validator: Rejects non-object inputs', () => {
  const resNull = validateBatteryConfig(null, DEFAULT_BATTERY_CONFIG);
  assert.equal(resNull.isValid, false);

  const resStr = validateBatteryConfig('invalid', DEFAULT_BATTERY_CONFIG);
  assert.equal(resStr.isValid, false);
});
