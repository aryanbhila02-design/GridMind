/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Comprehensive Unit Tests for Controller Thresholds & Peak Intelligence (Phase 10)
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateGridTransition } from '../engine/transitionController.ts';
import { computePeakIntelligence } from '../engine/peakIntelligenceEngine.ts';
import { predictLocalDemandKw } from '../engine/forecastingEngine.ts';
import type { ForecastHourResult, TelemetryRow } from '../types/microgrid.ts';

// -------------------------------------------------------------
// 1. EXACT BOUNDARY CHECKS AROUND 160 kW AND 200 kW
// -------------------------------------------------------------

test('Boundary: 159.99 kW outside evening window (12:00) selects Main Grid Mode', () => {
  const res = evaluateGridTransition('2026-10-27T12:00:00', 159.99);
  assert.equal(res.grid_mode, 'Main Grid Mode');
  assert.equal(res.critical_overload, false);
});

test('Boundary: Exactly 160.00 kW outside evening window (12:00) selects Main Grid Mode', () => {
  const res = evaluateGridTransition('2026-10-27T12:00:00', 160.00);
  assert.equal(res.grid_mode, 'Main Grid Mode', 'Demand must be strictly > 160 kW to trigger Renewable Storage Mode');
  assert.equal(res.critical_overload, false);
});

test('Boundary: 160.01 kW outside evening window (12:00) triggers Renewable Storage Mode', () => {
  const res = evaluateGridTransition('2026-10-27T12:00:00', 160.01);
  assert.equal(res.grid_mode, 'Renewable Storage Mode');
  assert.equal(res.critical_overload, false);
});

test('Boundary: 199.99 kW does not trigger Critical Overload Alert', () => {
  const res = evaluateGridTransition('2026-10-27T12:00:00', 199.99);
  assert.equal(res.critical_overload, false);
});

test('Boundary: Exactly 200.00 kW triggers Critical Overload Alert', () => {
  const res = evaluateGridTransition('2026-10-27T12:00:00', 200.00);
  assert.equal(res.critical_overload, true);
  assert.equal(res.grid_mode, 'Renewable Storage Mode');
});

test('Boundary: 200.01 kW triggers Critical Overload Alert', () => {
  const res = evaluateGridTransition('2026-10-27T12:00:00', 200.01);
  assert.equal(res.critical_overload, true);
});

// -------------------------------------------------------------
// 2. EVENING PEAK WINDOW INCLUSIVITY [18..22]
// -------------------------------------------------------------

test('Evening Window: Hour 17:00 with demand <= 160 kW selects Main Grid Mode', () => {
  const res = evaluateGridTransition('2026-10-27T17:00:00', 100.0);
  assert.equal(res.grid_mode, 'Main Grid Mode');
});

test('Evening Window: Hour 18:00 (start of peak window) triggers Renewable Storage Mode even at low demand', () => {
  const res = evaluateGridTransition('2026-10-27T18:00:00', 50.0);
  assert.equal(res.grid_mode, 'Renewable Storage Mode');
});

test('Evening Window: Hour 22:00 (end of peak window) triggers Renewable Storage Mode even at low demand', () => {
  const res = evaluateGridTransition('2026-10-27T22:00:00', 50.0);
  assert.equal(res.grid_mode, 'Renewable Storage Mode');
});

test('Evening Window: Hour 23:00 with demand <= 160 kW returns to Main Grid Mode', () => {
  const res = evaluateGridTransition('2026-10-27T23:00:00', 100.0);
  assert.equal(res.grid_mode, 'Main Grid Mode');
});

// -------------------------------------------------------------
// 3. PEAK INTELLIGENCE STRICT CONGRUENCE
// -------------------------------------------------------------

test('Peak Intelligence: hoursOver160Kw strictly counts demand > 160.0 kW, ignoring 160.00 kW', () => {
  const fakeResults: ForecastHourResult[] = [
    {
      timestamp: '2026-10-27T12:00:00',
      hour: 12,
      ambient_temp_c: 25,
      humidity_pct: 50,
      solar_irradiance_wm2: 500,
      predicted_demand_kw: 160.00, // Exactly 160.00 kW - must NOT be counted as over 160
      grid_mode: 'Main Grid Mode',
      critical_overload: false,
      decision_reason: '',
      battery_soc_pct: 50,
      battery_soc_kwh: 250,
      battery_power_kw: 0,
      grid_import_kw: 160,
      solar_used_kw: 0,
      solar_curtailed_kw: 0,
    },
    {
      timestamp: '2026-10-27T13:00:00',
      hour: 13,
      ambient_temp_c: 26,
      humidity_pct: 48,
      solar_irradiance_wm2: 600,
      predicted_demand_kw: 160.10, // Strictly > 160 kW - MUST be counted
      grid_mode: 'Renewable Storage Mode',
      critical_overload: false,
      decision_reason: '',
      battery_soc_pct: 50,
      battery_soc_kwh: 250,
      battery_power_kw: 0,
      grid_import_kw: 160.1,
      solar_used_kw: 0,
      solar_curtailed_kw: 0,
    },
  ];

  const peak = computePeakIntelligence(fakeResults);
  assert.equal(peak.hoursOver160Kw, 1, 'Only row with > 160.0 kW should be counted');
  assert.deepEqual(peak.peakWindowHours, [13]);
});

// -------------------------------------------------------------
// 4. UNIFIED RIDGE PREDICTOR INTEGRITY
// -------------------------------------------------------------

test('Unified Ridge Predictor: Computes deterministic and physical demand predictions', () => {
  const sampleRow: TelemetryRow = {
    timestamp: '2026-10-27T12:00:00',
    ambient_temp_c: 30.8,
    humidity_pct: 40,
    solar_irradiance_wm2: 940,
  };
  const pred = predictLocalDemandKw(sampleRow);
  assert.ok(typeof pred === 'number' && Number.isFinite(pred));
  assert.ok(pred >= 35.0 && pred <= 350.0, `Prediction ${pred} kW within physical range`);
});
