/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Telemetry Validator and RFC 4180 CSV Engine
 * HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine
 */

import type { TelemetryRow, ValidationError, ValidationSummary } from '../types/microgrid.ts';

export interface ParseCsvOptions {
  requireTarget?: boolean;
  interpolateSmallGaps?: boolean;
}

export interface CsvParseResult {
  headers: string[];
  rows: string[][];
  parseErrors: string[];
}

/**
 * Robust RFC 4180 compliant CSV parser.
 * Handles:
 * - Commas inside quoted fields
 * - Escaped double quotes ("" -> ")
 * - Multiline records with newlines inside quotes
 * - CRLF and LF line endings
 * - UTF-8 Byte Order Mark (\uFEFF)
 * - Trailing whitespace and empty lines
 */
export function parseCsvText(csvText: string): CsvParseResult {
  if (!csvText || typeof csvText !== 'string') {
    return { headers: [], rows: [], parseErrors: ['Empty or non-string CSV input'] };
  }

  // Remove UTF-8 BOM if present
  let text = csvText;
  if (text.charCodeAt(0) === 0xfeff) {
    text = text.slice(1);
  }

  const parseErrors: string[] = [];
  const records: string[][] = [];
  let currentRecord: string[] = [];
  let currentField = '';
  let inQuotes = false;
  let i = 0;
  const len = text.length;

  while (i < len) {
    const char = text[i];

    if (inQuotes) {
      if (char === '"') {
        // Check for escaped double quote ("")
        if (i + 1 < len && text[i + 1] === '"') {
          currentField += '"';
          i += 2;
          continue;
        } else {
          // Closing quote
          inQuotes = false;
          i++;
          continue;
        }
      } else {
        currentField += char;
        i++;
        continue;
      }
    } else {
      // Not in quotes
      if (char === '"') {
        inQuotes = true;
        i++;
        continue;
      } else if (char === ',') {
        currentRecord.push(currentField.trim());
        currentField = '';
        i++;
        continue;
      } else if (char === '\r') {
        // Handle CRLF
        if (i + 1 < len && text[i + 1] === '\n') {
          i++;
        }
        currentRecord.push(currentField.trim());
        currentField = '';
        if (currentRecord.some(f => f.length > 0)) {
          records.push(currentRecord);
        }
        currentRecord = [];
        i++;
        continue;
      } else if (char === '\n') {
        currentRecord.push(currentField.trim());
        currentField = '';
        if (currentRecord.some(f => f.length > 0)) {
          records.push(currentRecord);
        }
        currentRecord = [];
        i++;
        continue;
      } else {
        currentField += char;
        i++;
        continue;
      }
    }
  }

  // Final field if text does not end with newline
  if (inQuotes) {
    parseErrors.push('Unclosed double quote detected at end of CSV file.');
  }
  currentRecord.push(currentField.trim());
  if (currentRecord.some(f => f.length > 0)) {
    records.push(currentRecord);
  }

  if (records.length === 0) {
    return { headers: [], rows: [], parseErrors: ['CSV contains no records'] };
  }

  const rawHeaders = records[0];
  const headers = rawHeaders.map(h => h.trim().replace(/^["']|["']$/g, ''));

  // Detect duplicate headers
  const seenHeaders = new Set<string>();
  for (const h of headers) {
    const lower = h.toLowerCase();
    if (seenHeaders.has(lower)) {
      parseErrors.push(`Duplicate header detected: "${h}"`);
    }
    seenHeaders.add(lower);
  }

  const rows = records.slice(1);

  return { headers, rows, parseErrors };
}

/**
 * Validates and normalizes raw telemetry records against HackSphere 3.0 schema.
 */
export function validateTelemetryCsv(
  csvText: string,
  options: ParseCsvOptions = {}
): {
  validRecords: TelemetryRow[];
  summary: ValidationSummary;
} {
  const { headers, rows, parseErrors } = parseCsvText(csvText);
  const errors: ValidationError[] = [];

  for (const pe of parseErrors) {
    errors.push({
      row: 1,
      field: 'format',
      message: pe,
    });
  }

  const requiredHeaders = ['timestamp', 'ambient_temp_c', 'humidity_pct', 'solar_irradiance_wm2'];
  const headerMap = new Map<string, number>();

  headers.forEach((h, idx) => {
    headerMap.set(h.toLowerCase(), idx);
  });

  const missingHeaders = requiredHeaders.filter(req => !headerMap.has(req));
  if (missingHeaders.length > 0) {
    errors.push({
      row: 1,
      field: 'header',
      message: `Missing required column(s): ${missingHeaders.join(', ')}. Official schema requires: timestamp, ambient_temp_c, humidity_pct, solar_irradiance_wm2`,
    });
  }

  const tsIdx = headerMap.get('timestamp') ?? -1;
  const tempIdx = headerMap.get('ambient_temp_c') ?? -1;
  const humIdx = headerMap.get('humidity_pct') ?? -1;
  const solIdx = headerMap.get('solar_irradiance_wm2') ?? -1;
  const targetIdx = headerMap.get('target_demand_kw') ?? -1;
  const hasTarget = targetIdx !== -1;

  if (options.requireTarget && !hasTarget) {
    errors.push({
      row: 1,
      field: 'target_demand_kw',
      message: 'Training data requires "target_demand_kw" target column',
    });
  }

  const validRecords: TelemetryRow[] = [];
  const seenTimestamps = new Set<string>();
  let duplicateCount = 0;
  let previousTimestampEpoch = 0;
  let isChronological = true;

  if (missingHeaders.length === 0) {
    rows.forEach((rowVals, rowNum) => {
      const lineNum = rowNum + 2; // +1 header, +1 1-based index
      const rawTs = rowVals[tsIdx] || '';
      const rawTemp = rowVals[tempIdx] || '';
      const rawHum = rowVals[humIdx] || '';
      const rawSol = rowVals[solIdx] || '';
      const rawTarget = hasTarget ? rowVals[targetIdx] : undefined;

      let rowValid = true;

      // Check unexpected column count
      if (rowVals.length !== headers.length && rowVals.length > 0) {
        errors.push({
          row: lineNum,
          field: 'column_count',
          message: `Expected ${headers.length} columns but found ${rowVals.length}.`,
        });
        rowValid = false;
      }

      // 1. Timestamp validation
      if (!rawTs) {
        errors.push({
          row: lineNum,
          field: 'timestamp',
          message: 'Empty timestamp value',
        });
        rowValid = false;
      } else {
        const parsedDate = new Date(rawTs);
        if (isNaN(parsedDate.getTime())) {
          errors.push({
            row: lineNum,
            field: 'timestamp',
            message: `Invalid timestamp format: "${rawTs}". Expected standard ISO format (e.g. 2026-10-26T00:00:00)`,
            rawValue: rawTs,
          });
          rowValid = false;
        } else {
          // Check duplicates
          if (seenTimestamps.has(rawTs)) {
            duplicateCount++;
            errors.push({
              row: lineNum,
              field: 'timestamp',
              message: `Duplicate timestamp detected: "${rawTs}"`,
              rawValue: rawTs,
            });
            rowValid = false;
          } else {
            seenTimestamps.add(rawTs);
          }

          // Check chronological sequence
          const currentEpoch = parsedDate.getTime();
          if (previousTimestampEpoch > 0 && currentEpoch < previousTimestampEpoch) {
            isChronological = false;
          }
          previousTimestampEpoch = currentEpoch;
        }
      }

      // 2. Weather fields validation
      const temp = parseFloat(rawTemp);
      if (isNaN(temp) || !Number.isFinite(temp)) {
        errors.push({
          row: lineNum,
          field: 'ambient_temp_c',
          message: `Non-numeric ambient_temp_c: "${rawTemp}"`,
          rawValue: rawTemp,
        });
        rowValid = false;
      } else if (temp < -60 || temp > 65) {
        errors.push({
          row: lineNum,
          field: 'ambient_temp_c',
          message: `Out of plausible range ambient_temp_c (-60°C to 65°C): ${temp}`,
          rawValue: rawTemp,
        });
        rowValid = false;
      }

      const hum = parseFloat(rawHum);
      if (isNaN(hum) || !Number.isFinite(hum)) {
        errors.push({
          row: lineNum,
          field: 'humidity_pct',
          message: `Non-numeric humidity_pct: "${rawHum}"`,
          rawValue: rawHum,
        });
        rowValid = false;
      } else if (hum < 0 || hum > 100) {
        errors.push({
          row: lineNum,
          field: 'humidity_pct',
          message: `Out of percentage range humidity_pct (0-100%): ${hum}`,
          rawValue: rawHum,
        });
        rowValid = false;
      }

      const sol = parseFloat(rawSol);
      if (isNaN(sol) || !Number.isFinite(sol)) {
        errors.push({
          row: lineNum,
          field: 'solar_irradiance_wm2',
          message: `Non-numeric solar_irradiance_wm2: "${rawSol}"`,
          rawValue: rawSol,
        });
        rowValid = false;
      } else if (sol < 0 || sol > 2000) {
        errors.push({
          row: lineNum,
          field: 'solar_irradiance_wm2',
          message: `Out of range solar_irradiance_wm2 (0-2000 W/m²): ${sol}`,
          rawValue: rawSol,
        });
        rowValid = false;
      }

      // 3. Optional target validation
      let target_demand_kw: number | undefined = undefined;
      if (hasTarget && rawTarget !== undefined && rawTarget !== '') {
        const parsedTarget = parseFloat(rawTarget);
        if (isNaN(parsedTarget) || !Number.isFinite(parsedTarget)) {
          errors.push({
            row: lineNum,
            field: 'target_demand_kw',
            message: `Non-numeric target_demand_kw: "${rawTarget}"`,
            rawValue: rawTarget,
          });
          rowValid = false;
        } else if (parsedTarget < 0 || parsedTarget > 5000) {
          errors.push({
            row: lineNum,
            field: 'target_demand_kw',
            message: `Out of plausible microgrid load range: ${parsedTarget} kW`,
            rawValue: rawTarget,
          });
          rowValid = false;
        } else {
          target_demand_kw = parsedTarget;
        }
      }

      if (rowValid) {
        validRecords.push({
          timestamp: rawTs,
          ambient_temp_c: temp,
          humidity_pct: hum,
          solar_irradiance_wm2: sol,
          ...(target_demand_kw !== undefined ? { target_demand_kw } : {}),
        });
      }
    });
  }

  // Enforce chronological sorting of valid records if out-of-order was detected
  validRecords.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  const summary: ValidationSummary = {
    totalRows: rows.length,
    validRows: validRecords.length,
    rejectedRows: rows.length - validRecords.length,
    hasTargetDemand: hasTarget,
    startDate: validRecords[0]?.timestamp,
    endDate: validRecords[validRecords.length - 1]?.timestamp,
    errors,
    cleaningPolicy:
      'Strict schema validation: Malformed, non-numeric, or duplicate records are isolated with clear row-level audit trails. Valid records are chronologically ordered by timestamp without fabricating unmeasured data.',
    isChronological,
    duplicateCount,
  };

  return { validRecords, summary };
}

/**
 * Serializes prediction results into the official HackSphere 3.0 CSV evaluation format:
 * Exactly two columns in order:
 * timestamp,target_demand_kw
 */
export function exportPredictionsToCsv(
  predictions: { timestamp: string; target_demand_kw: number }[]
): string {
  const header = 'timestamp,target_demand_kw\n';
  const rows = predictions.map(p => `${p.timestamp},${Number(p.target_demand_kw.toFixed(2))}`).join('\n');
  return header + rows;
}

/**
 * Serializes telemetry rows back into standard CSV.
 */
export function exportTelemetryToCsv(records: TelemetryRow[]): string {
  const hasTarget = records.some(r => r.target_demand_kw !== undefined);
  const header = hasTarget
    ? 'timestamp,ambient_temp_c,humidity_pct,solar_irradiance_wm2,target_demand_kw\n'
    : 'timestamp,ambient_temp_c,humidity_pct,solar_irradiance_wm2\n';

  const lines = records.map(r => {
    const base = `${r.timestamp},${r.ambient_temp_c},${r.humidity_pct},${r.solar_irradiance_wm2}`;
    return hasTarget ? `${base},${r.target_demand_kw ?? ''}` : base;
  });

  return header + lines.join('\n');
}
