/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Peak Demand Intelligence Engine
 * HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine
 * 
 * Computes:
 * 1. Diurnal peak and base load metrics
 * 2. Threshold exceedance counts (> 160 kW Renewable Storage Mode, >= 200 kW Critical Overload)
 * 3. Grid ramp rates (max kW/h delta)
 * 4. Battery peak shaving efficacy and solar curtailment
 */

import type { ForecastHourResult, PeakIntelligenceSummary } from '../types/microgrid.ts';

export function computePeakIntelligence(
  results: ForecastHourResult[]
): PeakIntelligenceSummary {
  if (results.length === 0) {
    return {
      peakDemandKw: 0,
      peakHour: 0,
      peakTimestamp: new Date().toISOString(),
      baseLoadKw: 0,
      baseHour: 0,
      averageDemandKw: 0,
      loadFactor: 0,
      hoursOver160Kw: 0,
      hoursCriticalOverload200Kw: 0,
      maxRampRateKwPerHour: 0,
      peakWindowHours: [],
      storagePeakReductionKw: 0,
      curtailedSolarKwh: 0,
    };
  }

  let peakDemand = -Infinity;
  let peakHour = 0;
  let peakTimestamp = results[0].timestamp;
  let baseDemand = Infinity;
  let baseHour = 0;
  let totalDemand = 0;

  let countOver160 = 0;
  let countCritical200 = 0;
  const peakWindowHours: number[] = [];
  let maxRampRate = 0;

  let totalSolarCurtailed = 0;
  let maxDischargeKw = 0;

  for (let i = 0; i < results.length; i++) {
    const r = results[i];
    const kw = r.predicted_demand_kw;
    totalDemand += kw;

    if (kw > peakDemand) {
      peakDemand = kw;
      peakHour = r.hour;
      peakTimestamp = r.timestamp;
    }
    if (kw < baseDemand) {
      baseDemand = kw;
      baseHour = r.hour;
    }

    // Strictly greater than 160.0 kW per official HackSphere 3.0 controller rule
    if (kw > 160.0) {
      countOver160++;
      peakWindowHours.push(r.hour);
    }
    if (kw >= 200.0 || r.critical_overload) {
      countCritical200++;
    }

    if (r.battery_power_kw > maxDischargeKw) {
      maxDischargeKw = r.battery_power_kw;
    }

    totalSolarCurtailed += r.solar_curtailed_kw;

    // Ramp rate compared to previous hour
    if (i > 0) {
      const prevKw = results[i - 1].predicted_demand_kw;
      const ramp = Math.abs(kw - prevKw);
      if (ramp > maxRampRate) {
        maxRampRate = ramp;
      }
    }
  }

  const avgDemand = totalDemand / results.length;
  const loadFactor = peakDemand > 0 ? avgDemand / peakDemand : 0;

  return {
    peakDemandKw: Number(peakDemand.toFixed(1)),
    peakHour,
    peakTimestamp,
    baseLoadKw: Number(baseDemand.toFixed(1)),
    baseHour,
    averageDemandKw: Number(avgDemand.toFixed(1)),
    loadFactor: Number(loadFactor.toFixed(3)),
    hoursOver160Kw: countOver160,
    hoursCriticalOverload200Kw: countCritical200,
    maxRampRateKwPerHour: Number(maxRampRate.toFixed(1)),
    peakWindowHours,
    storagePeakReductionKw: Number(maxDischargeKw.toFixed(1)),
    curtailedSolarKwh: Number(totalSolarCurtailed.toFixed(1)),
  };
}
