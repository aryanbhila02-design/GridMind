/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Authoritative Battery Configuration Validator
 * HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine
 */

import type { BatteryConfig } from '../types/microgrid.ts';

export interface BatteryValidationResult {
  isValid: boolean;
  config?: BatteryConfig;
  errors: Record<string, string>;
}

/**
 * Validates and merges battery configuration updates.
 * Distinguishes omitted fields from explicitly supplied zero values.
 * Rejects non-finite, negative, or physically impossible configurations.
 */
export function validateBatteryConfig(
  input: unknown,
  existingConfig: BatteryConfig
): BatteryValidationResult {
  const errors: Record<string, string> = {};

  if (!input || typeof input !== 'object') {
    return {
      isValid: false,
      errors: { _general: 'Battery configuration must be a non-null object.' },
    };
  }

  const raw = input as Record<string, unknown>;

  // Helper to parse numerical field
  const parseNumericField = (
    fieldName: keyof BatteryConfig,
    existingValue: number,
    opts: {
      min?: number;
      max?: number;
      allowZero?: boolean;
      requiredPositive?: boolean;
    }
  ): number => {
    // If field omitted or undefined, preserve existing value
    if (raw[fieldName] === undefined) {
      return existingValue;
    }

    const val = raw[fieldName];

    // Reject non-numeric types (e.g. boolean, null, object)
    if (typeof val === 'boolean' || val === null || typeof val === 'object') {
      errors[fieldName] = `Field '${fieldName}' must be a valid finite number.`;
      return existingValue;
    }

    const num = Number(val);

    if (isNaN(num) || !Number.isFinite(num)) {
      errors[fieldName] = `Field '${fieldName}' must be a finite numerical value.`;
      return existingValue;
    }

    if (opts.requiredPositive && num <= 0) {
      errors[fieldName] = `Field '${fieldName}' must be strictly greater than 0.`;
      return existingValue;
    }

    if (!opts.allowZero && num === 0 && !opts.requiredPositive) {
      errors[fieldName] = `Field '${fieldName}' cannot be zero.`;
      return existingValue;
    }

    if (opts.min !== undefined && num < opts.min) {
      errors[fieldName] = `Field '${fieldName}' cannot be less than ${opts.min}.`;
      return existingValue;
    }

    if (opts.max !== undefined && num > opts.max) {
      errors[fieldName] = `Field '${fieldName}' cannot exceed ${opts.max}.`;
      return existingValue;
    }

    return num;
  };

  const capacity_kwh = parseNumericField('capacity_kwh', existingConfig.capacity_kwh, {
    requiredPositive: true,
  });

  const initial_soc_pct = parseNumericField('initial_soc_pct', existingConfig.initial_soc_pct, {
    min: 0,
    max: 100,
    allowZero: true,
  });

  const max_charge_kw = parseNumericField('max_charge_kw', existingConfig.max_charge_kw, {
    min: 0,
    allowZero: true,
  });

  const max_discharge_kw = parseNumericField('max_discharge_kw', existingConfig.max_discharge_kw, {
    min: 0,
    allowZero: true,
  });

  const efficiency_pct = parseNumericField('efficiency_pct', existingConfig.efficiency_pct, {
    min: 1,
    max: 100,
  });

  const min_soc_pct = parseNumericField('min_soc_pct', existingConfig.min_soc_pct, {
    min: 0,
    max: 95,
    allowZero: true,
  });

  const low_soc_warning_pct = parseNumericField('low_soc_warning_pct', existingConfig.low_soc_warning_pct, {
    min: 0,
    max: 95,
    allowZero: true,
  });

  // Cross-field relational validation
  if (!errors.min_soc_pct && !errors.initial_soc_pct) {
    if (initial_soc_pct < min_soc_pct) {
      errors.initial_soc_pct = `Initial state of charge (${initial_soc_pct}%) cannot be less than minimum reserve buffer (${min_soc_pct}%).`;
    }
  }

  const isValid = Object.keys(errors).length === 0;

  if (!isValid) {
    return {
      isValid: false,
      errors,
    };
  }

  const validatedConfig: BatteryConfig = {
    capacity_kwh,
    initial_soc_pct,
    max_charge_kw,
    max_discharge_kw,
    efficiency_pct,
    min_soc_pct,
    low_soc_warning_pct,
  };

  return {
    isValid: true,
    config: validatedConfig,
    errors: {},
  };
}
