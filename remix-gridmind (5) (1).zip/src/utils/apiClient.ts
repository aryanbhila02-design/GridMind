/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Safe API Client for Hybrid Zoho Catalyst Slate & AppSail Deployments
 * 
 * Prevents "Unexpected token '<', '<!doctype ... is not valid JSON" errors by:
 * 1. Validating Content-Type headers before attempting JSON parsing
 * 2. Detecting HTML responses from static hosting SPAs (Zoho Catalyst Slate fallback)
 * 3. Supporting configurable API base URL (VITE_API_URL or window.__GRIDMIND_API_URL__)
 * 4. Providing typed status, error diagnostics, and fallback signals
 */

export interface ApiResponse<T> {
  ok: boolean;
  status: number;
  data?: T;
  error?: string;
  isHtmlResponse?: boolean;
  isNetworkError?: boolean;
}

/**
 * Resolves the active backend API base URL:
 * - Checks import.meta.env.VITE_API_URL
 * - Checks window.__GRIDMIND_API_URL__ (for runtime environment injection)
 * - Defaults to empty string (relative same-origin requests)
 */
export function getApiBaseUrl(): string {
  try {
    const windowUrl = typeof window !== 'undefined' ? (window as unknown as { __GRIDMIND_API_URL__?: string }).__GRIDMIND_API_URL__ : undefined;
    if (windowUrl && typeof windowUrl === 'string' && windowUrl.trim()) {
      return windowUrl.trim().replace(/\/+$/, '');
    }
  } catch {
    // Ignore window access errors
  }

  const envUrl = typeof import.meta !== 'undefined' && import.meta.env ? (import.meta.env.VITE_API_URL as string | undefined) : undefined;
  if (envUrl && typeof envUrl === 'string' && envUrl.trim()) {
    return envUrl.trim().replace(/\/+$/, '');
  }

  return '';
}

/**
 * Safely fetches an API endpoint and strictly validates JSON responses.
 * Never throws "Unexpected token '<', '<!doctype '..." when encountering HTML fallbacks.
 */
export async function safeFetchJson<T>(
  endpoint: string,
  options?: RequestInit
): Promise<ApiResponse<T>> {
  const baseUrl = getApiBaseUrl();
  const normalizedPath = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  const fullUrl = baseUrl ? `${baseUrl}${normalizedPath}` : normalizedPath;

  const defaultHeaders: Record<string, string> = {
    'Accept': 'application/json',
  };

  if (options?.body && !(options.body instanceof FormData)) {
    defaultHeaders['Content-Type'] = 'application/json';
  }

  const mergedHeaders = {
    ...defaultHeaders,
    ...(options?.headers as Record<string, string> | undefined),
  };

  try {
    const res = await fetch(fullUrl, {
      ...options,
      headers: mergedHeaders,
    });

    const contentType = res.headers.get('content-type') || '';

    // Check if response is HTML or non-JSON
    if (!contentType.toLowerCase().includes('application/json')) {
      const textPreview = await res.text();
      const isHtml = textPreview.trim().toLowerCase().startsWith('<!doctype') || textPreview.trim().startsWith('<html') || textPreview.trim().startsWith('<');

      return {
        ok: false,
        status: res.status,
        isHtmlResponse: true,
        error: isHtml
          ? `Server returned an HTML document (${res.status}) instead of JSON. The API backend is not directly reached on this host path.`
          : `Unexpected content type "${contentType}" received from ${normalizedPath} (${res.status}).`,
      };
    }

    // Response is JSON
    let parsedData: unknown;
    try {
      parsedData = await res.json();
    } catch (parseErr: unknown) {
      const msg = parseErr instanceof Error ? parseErr.message : String(parseErr);
      return {
        ok: false,
        status: res.status,
        error: `JSON parse error from ${normalizedPath}: ${msg}`,
      };
    }

    if (!res.ok) {
      const errObj = parsedData as { error?: string; message?: string } | null;
      let errorMsg = errObj?.error || errObj?.message;
      if (!errorMsg) {
        if (res.status === 405) {
          errorMsg = 'HTTP 405 Method Not Allowed: The current host (such as Zoho Catalyst Slate static CDN) does not route dynamic POST requests directly on this path.';
        } else {
          errorMsg = `API request failed with HTTP ${res.status}`;
        }
      }
      return {
        ok: false,
        status: res.status,
        data: parsedData as T,
        error: errorMsg,
      };
    }

    return {
      ok: true,
      status: res.status,
      data: parsedData as T,
    };
  } catch (netErr: unknown) {
    const msg = netErr instanceof Error ? netErr.message : String(netErr);
    return {
      ok: false,
      status: 0,
      isNetworkError: true,
      error: `Network request to ${fullUrl} failed: ${msg}`,
    };
  }
}
