/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — BESS Battery Storage & What-If Scenario View
 * HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine
 * 
 * Features:
 * - Real-time State of Charge (SoC) tracking & 15% reserve buffer monitoring
 * - 24-Hour Battery power charge/discharge and grid import metrics
 * - What-If Side-by-Side Simulation (Baseline vs Scaled vs Degraded)
 * - Strict 'Hypothetical Scenario — Not a Live Grid State' labeling
 */

import React, { useState, useEffect } from 'react';
import {
  BatteryCharging,
  Battery,
  Zap,
  Sun,
  ShieldCheck,
  AlertTriangle,
  Sliders,
  CheckCircle2,
  TrendingDown,
  RefreshCw,
  GitBranch,
  HelpCircle,
} from 'lucide-react';
import type { BatteryConfig, ForecastHourResult, WhatIfScenarioSummary } from '../types/microgrid.ts';
import { BatteryChart } from './BatteryChart.tsx';
import { safeFetchJson } from '../utils/apiClient.ts';
import { runWhatIfScenarios } from '../engine/whatIfEngine.ts';

interface BatteryViewProps {
  batteryConfig: BatteryConfig;
  forecastData: ForecastHourResult[];
}

export const BatteryView: React.FC<BatteryViewProps> = ({
  batteryConfig,
  forecastData,
}) => {
  const [whatIfScenarios, setWhatIfScenarios] = useState<WhatIfScenarioSummary[]>([]);
  const [loadingScenarios, setLoadingScenarios] = useState<boolean>(false);

  // Fetch what-if simulation from backend with in-browser fallback
  const runWhatIf = async () => {
    setLoadingScenarios(true);
    try {
      const res = await safeFetchJson<{ scenarios?: WhatIfScenarioSummary[] }>('/api/ml/what-if', {
        method: 'POST',
        body: JSON.stringify({}),
      });

      if (res.ok && res.data?.scenarios && res.data.scenarios.length > 0) {
        setWhatIfScenarios(res.data.scenarios);
      } else {
        // Fallback to client-side scenario simulation
        const customConfigs = [
          {
            name: 'Active Baseline Configuration',
            config: batteryConfig,
          },
          {
            name: 'High Capacity Buffer (1000 kWh, 250 kW)',
            config: {
              ...batteryConfig,
              capacity_kwh: 1000,
              max_charge_kw: 200,
              max_discharge_kw: 250,
            },
          },
          {
            name: 'Degraded Reserve (250 kWh, 60 kW)',
            config: {
              ...batteryConfig,
              capacity_kwh: 250,
              max_charge_kw: 50,
              max_discharge_kw: 60,
              min_soc_pct: 25,
            },
          },
        ];
        const results = runWhatIfScenarios(forecastData, customConfigs);
        setWhatIfScenarios(results);
      }
    } catch {
      const customConfigs = [
        {
          name: 'Active Baseline Configuration',
          config: batteryConfig,
        },
        {
          name: 'High Capacity Buffer (1000 kWh, 250 kW)',
          config: {
            ...batteryConfig,
            capacity_kwh: 1000,
            max_charge_kw: 200,
            max_discharge_kw: 250,
          },
        },
        {
          name: 'Degraded Reserve (250 kWh, 60 kW)',
          config: {
            ...batteryConfig,
            capacity_kwh: 250,
            max_charge_kw: 50,
            max_discharge_kw: 60,
            min_soc_pct: 25,
          },
        },
      ];
      const results = runWhatIfScenarios(forecastData, customConfigs);
      setWhatIfScenarios(results);
    } finally {
      setLoadingScenarios(false);
    }
  };

  useEffect(() => {
    runWhatIf();
  }, [batteryConfig, forecastData]);

  // Calculate live cumulative metrics across 24h
  const totalDischargedKwh = forecastData.reduce(
    (sum, r) => (r.battery_power_kw > 0 ? sum + r.battery_power_kw : sum),
    0
  );
  const totalChargedKwh = forecastData.reduce(
    (sum, r) => (r.battery_power_kw < 0 ? sum + Math.abs(r.battery_power_kw) : sum),
    0
  );
  const totalSolarUsedKwh = forecastData.reduce((sum, r) => sum + r.solar_used_kw, 0);
  const totalSolarCurtailedKwh = forecastData.reduce((sum, r) => sum + r.solar_curtailed_kw, 0);
  const totalGridImportKwh = forecastData.reduce((sum, r) => sum + r.grid_import_kw, 0);

  const currentPoint = forecastData[0] || {
    battery_soc_pct: batteryConfig.initial_soc_pct,
    battery_soc_kwh: (batteryConfig.initial_soc_pct / 100) * batteryConfig.capacity_kwh,
    battery_power_kw: 0,
  };

  return (
    <div className="space-y-6 max-w-6xl">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-100 flex items-center gap-2">
          <BatteryCharging className="w-6 h-6 text-cyan-400" />
          Battery Energy Storage System (BESS)
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          Simulating microgrid electrochemical storage dynamics, state-of-charge (SoC), C-rate limits, and what-if capacity scenarios.
        </p>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <span className="text-xs text-slate-400">Current SoC</span>
          <div className="text-2xl font-bold font-mono text-cyan-400 mt-1">
            {currentPoint.battery_soc_pct.toFixed(1)}%
          </div>
          <span className="text-[11px] text-slate-500 mt-0.5 block">
            {currentPoint.battery_soc_kwh.toFixed(1)} / {batteryConfig.capacity_kwh} kWh
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <span className="text-xs text-slate-400">24h Total Discharge</span>
          <div className="text-2xl font-bold font-mono text-amber-400 mt-1">
            {totalDischargedKwh.toFixed(1)} <span className="text-xs font-normal text-slate-400">kWh</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-0.5 block">
            Peak shave offset
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <span className="text-xs text-slate-400">Solar Energy Stored</span>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
            {totalChargedKwh.toFixed(1)} <span className="text-xs font-normal text-slate-400">kWh</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-0.5 block">
            From daytime photovoltaic surplus
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <span className="text-xs text-slate-400">Solar Curtailed</span>
          <div className="text-2xl font-bold font-mono text-rose-400 mt-1">
            {totalSolarCurtailedKwh.toFixed(1)} <span className="text-xs font-normal text-slate-400">kWh</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-0.5 block">
            Surplus exceeding BESS C-rate
          </span>
        </div>
      </div>

      {/* Main SoC Chart */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
        <h3 className="font-semibold text-slate-200 text-sm mb-4">
          24-Hour State-of-Charge & Power Profile
        </h3>
        <BatteryChart data={forecastData} />
      </div>

      {/* P4: What-If Energy Scenario Simulation Section */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 pb-3 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <GitBranch className="w-5 h-5 text-purple-400" />
              <h3 className="font-semibold text-slate-200 text-sm">
                What-If Storage Capacity Simulation (P4)
              </h3>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Simulating alternative battery sizing against the current 24-hour load and solar profile.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {/* Required prominent Hypothetical badge */}
            <span className="text-[11px] px-3 py-1 rounded-full font-sans font-semibold bg-amber-500/10 text-amber-300 border border-amber-500/30 flex items-center gap-1.5 shadow-sm">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              Hypothetical Scenario — Not a Live Grid State
            </span>

            <button
              onClick={runWhatIf}
              disabled={loadingScenarios}
              className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg flex items-center gap-1 cursor-pointer border border-slate-700"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingScenarios ? 'animate-spin' : ''}`} />
              Re-simulate
            </button>
          </div>
        </div>

        {/* Side-by-Side Comparison Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {whatIfScenarios.map((sc, idx) => (
            <div
              key={sc.id || idx}
              className={`p-4 rounded-xl border flex flex-col justify-between space-y-4 ${
                idx === 0
                  ? 'bg-slate-950 border-cyan-500/30 ring-1 ring-cyan-500/20'
                  : 'bg-slate-950/60 border-slate-800'
              }`}
            >
              <div>
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-slate-200 text-sm">{sc.scenarioName}</h4>
                  {idx === 0 && (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                      Active
                    </span>
                  )}
                </div>
                <div className="text-xs font-mono text-slate-400 mt-1">
                  Cap: {sc.batteryConfig.capacity_kwh} kWh | Rate: ±{sc.batteryConfig.max_discharge_kw} kW
                </div>
              </div>

              <div className="space-y-2 text-xs font-mono">
                <div className="flex justify-between py-1 border-b border-slate-900">
                  <span className="text-slate-400">Solar Self-Consumption</span>
                  <span className="text-emerald-400 font-bold">{sc.renewableSelfConsumptionPct}%</span>
                </div>

                <div className="flex justify-between py-1 border-b border-slate-900">
                  <span className="text-slate-400">Curtailed Solar</span>
                  <span className="text-rose-400 font-bold">{sc.totalSolarCurtailedKwh} kWh</span>
                </div>

                <div className="flex justify-between py-1 border-b border-slate-900">
                  <span className="text-slate-400">Grid Import Required</span>
                  <span className="text-cyan-400 font-bold">{sc.totalGridImportKwh} kWh</span>
                </div>

                <div className="flex justify-between py-1 border-b border-slate-900">
                  <span className="text-slate-400">Critical Overloads</span>
                  <span className={`font-bold ${sc.criticalOverloadsCount > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                    {sc.criticalOverloadsCount} events
                  </span>
                </div>

                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Battery Cycles</span>
                  <span className="text-purple-400 font-bold">{sc.batteryCyclesEquivalent}</span>
                </div>
              </div>

              <div className="text-[10px] text-slate-500 pt-1 border-t border-slate-900 text-center font-sans italic">
                Hypothetical Scenario Simulation
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Physical Microgrid Equipment & Hardware Assets */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 pb-3 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <h3 className="font-semibold text-slate-200 text-sm">
                Microgrid Hardware Equipment & Storage Asset Profiles
              </h3>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Verified electrical specifications, round-trip efficiency, and inverter coupling across physical hardware components.
            </p>
          </div>
          <span className="text-[11px] font-mono text-emerald-400 px-2.5 py-1 bg-emerald-950/60 border border-emerald-800/80 rounded-lg w-fit">
            System Rating: 480V 3Φ · 60Hz
          </span>
        </div>

        {/* 4 Hardware Equipment Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Card 1: BESS LiFePO4 */}
          <div className="bg-slate-950/80 border border-slate-800/90 rounded-xl overflow-hidden flex flex-col justify-between hover:border-cyan-500/40 transition-colors">
            <div>
              <div className="h-36 w-full bg-slate-900 relative overflow-hidden flex items-center justify-center p-2 border-b border-slate-800/80">
                <img
                  src="/assets/bess_storage.svg"
                  alt="LiFePO4 BESS Storage Cabinet"
                  onError={(e) => {
                    e.currentTarget.onerror = null;
                    e.currentTarget.src = "data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' width='400' height='240' fill='%230f172a'%3e%3crect width='400' height='240' fill='%23090d16'/%3e%3ctext x='50%25' y='50%25' fill='%2306b6d4' font-family='monospace' font-size='14' text-anchor='middle' dominant-baseline='middle'%3eBESS Storage Module%3c/text%3e%3c/svg%3e";
                  }}
                  className="w-full h-full object-contain"
                  loading="lazy"
                />
                <span className="absolute top-2 right-2 px-1.5 py-0.5 text-[9px] font-mono font-semibold bg-cyan-950 text-cyan-300 border border-cyan-800/70 rounded">
                  Active Asset
                </span>
              </div>
              <div className="p-3.5 space-y-2">
                <div>
                  <h4 className="text-xs font-semibold text-slate-100">BESS LiFePO4 Energy Rack</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-2">
                    Lithium-iron-phosphate containerized battery rack with liquid thermal management and BMS balancing.
                  </p>
                </div>
                <div className="space-y-1 text-[11px] font-mono border-t border-slate-900 pt-2 text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-sans">Capacity:</span>
                    <span className="font-semibold text-cyan-300">{batteryConfig.capacity_kwh} kWh</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-sans">Max Discharge:</span>
                    <span>{batteryConfig.max_discharge_kw} kW (C-Rate: {(batteryConfig.max_discharge_kw / batteryConfig.capacity_kwh).toFixed(2)}C)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-sans">Reserve Buffer:</span>
                    <span>{batteryConfig.min_soc_pct}% Minimum</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="px-3.5 pb-3 pt-1 border-t border-slate-900/60 text-[10px] text-slate-500 flex items-center justify-between font-sans">
              <span>Catalog: GM-BESS-920</span>
              <span className="text-emerald-400 font-semibold">95% Eff</span>
            </div>
          </div>

          {/* Card 2: Bifacial Solar PV Array */}
          <div className="bg-slate-950/80 border border-slate-800/90 rounded-xl overflow-hidden flex flex-col justify-between hover:border-amber-500/40 transition-colors">
            <div>
              <div className="h-36 w-full bg-slate-900 relative overflow-hidden flex items-center justify-center p-2 border-b border-slate-800/80">
                <img
                  src="/assets/solar_array.svg"
                  alt="Bifacial Photovoltaic Solar Array"
                  onError={(e) => {
                    e.currentTarget.onerror = null;
                    e.currentTarget.src = "data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' width='400' height='240' fill='%230f172a'%3e%3crect width='400' height='240' fill='%23090d16'/%3e%3ctext x='50%25' y='50%25' fill='%23f59e0b' font-family='monospace' font-size='14' text-anchor='middle' dominant-baseline='middle'%3eSolar PV Array%3c/text%3e%3c/svg%3e";
                  }}
                  className="w-full h-full object-contain"
                  loading="lazy"
                />
                <span className="absolute top-2 right-2 px-1.5 py-0.5 text-[9px] font-mono font-semibold bg-amber-950 text-amber-300 border border-amber-800/70 rounded">
                  Generation
                </span>
              </div>
              <div className="p-3.5 space-y-2">
                <div>
                  <h4 className="text-xs font-semibold text-slate-100">Bifacial Rooftop PV Array</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-2">
                    High-efficiency N-type TOPCon bifacial modules harvesting direct sunlight and building roof albedo.
                  </p>
                </div>
                <div className="space-y-1 text-[11px] font-mono border-t border-slate-900 pt-2 text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-sans">Nameplate Peak:</span>
                    <span className="font-semibold text-amber-300">450 kWp</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-sans">Module STC:</span>
                    <span>21.8% Efficiency</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-sans">Temp Coeff:</span>
                    <span>-0.30% / °C</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="px-3.5 pb-3 pt-1 border-t border-slate-900/60 text-[10px] text-slate-500 flex items-center justify-between font-sans">
              <span>Catalog: GM-PV-TOP450</span>
              <span className="text-amber-400 font-semibold">Dual-Axis</span>
            </div>
          </div>

          {/* Card 3: Inverter */}
          <div className="bg-slate-950/80 border border-slate-800/90 rounded-xl overflow-hidden flex flex-col justify-between hover:border-purple-500/40 transition-colors">
            <div>
              <div className="h-36 w-full bg-slate-900 relative overflow-hidden flex items-center justify-center p-2 border-b border-slate-800/80">
                <img
                  src="/assets/pcs_inverter.svg"
                  alt="Bidirectional Power Conversion Inverter"
                  onError={(e) => {
                    e.currentTarget.onerror = null;
                    e.currentTarget.src = "data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' width='400' height='240' fill='%230f172a'%3e%3crect width='400' height='240' fill='%23090d16'/%3e%3ctext x='50%25' y='50%25' fill='%23a855f7' font-family='monospace' font-size='14' text-anchor='middle' dominant-baseline='middle'%3ePCS Inverter%3c/text%3e%3c/svg%3e";
                  }}
                  className="w-full h-full object-contain"
                  loading="lazy"
                />
                <span className="absolute top-2 right-2 px-1.5 py-0.5 text-[9px] font-mono font-semibold bg-purple-950 text-purple-300 border border-purple-800/70 rounded">
                  Power Conversion
                </span>
              </div>
              <div className="p-3.5 space-y-2">
                <div>
                  <h4 className="text-xs font-semibold text-slate-100">Bidirectional PCS Inverter</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-2">
                    Four-quadrant silicon carbide (SiC) inverter enabling sub-cycle 4-quadrant reactive and active power dispatch.
                  </p>
                </div>
                <div className="space-y-1 text-[11px] font-mono border-t border-slate-900 pt-2 text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-sans">Power Rating:</span>
                    <span className="font-semibold text-purple-300">{batteryConfig.max_charge_kw} kVA</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-sans">Euro Efficiency:</span>
                    <span>98.4% Peak</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-sans">Switching:</span>
                    <span>SiC MOSFET 40kHz</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="px-3.5 pb-3 pt-1 border-t border-slate-900/60 text-[10px] text-slate-500 flex items-center justify-between font-sans">
              <span>Catalog: GM-PCS-250</span>
              <span className="text-cyan-400 font-semibold">IEEE 1547</span>
            </div>
          </div>

          {/* Card 4: Microgrid RTU Gateway */}
          <div className="bg-slate-950/80 border border-slate-800/90 rounded-xl overflow-hidden flex flex-col justify-between hover:border-emerald-500/40 transition-colors">
            <div>
              <div className="h-36 w-full bg-slate-900 relative overflow-hidden flex items-center justify-center p-2 border-b border-slate-800/80">
                <img
                  src="/assets/microgrid_rtu.svg"
                  alt="Microgrid RTU Controller Gateway"
                  onError={(e) => {
                    e.currentTarget.onerror = null;
                    e.currentTarget.src = "data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' width='400' height='240' fill='%230f172a'%3e%3crect width='400' height='240' fill='%23090d16'/%3e%3ctext x='50%25' y='50%25' fill='%2310b981' font-family='monospace' font-size='14' text-anchor='middle' dominant-baseline='middle'%3eRTU Gateway%3c/text%3e%3c/svg%3e";
                  }}
                  className="w-full h-full object-contain"
                  loading="lazy"
                />
                <span className="absolute top-2 right-2 px-1.5 py-0.5 text-[9px] font-mono font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800/70 rounded">
                  Substation RTU
                </span>
              </div>
              <div className="p-3.5 space-y-2">
                <div>
                  <h4 className="text-xs font-semibold text-slate-100">Smart Gateway & RTU Actuator</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-2">
                    Hardened substation automation unit evaluating 160 kW dispatch and 200 kW overload transformer protection.
                  </p>
                </div>
                <div className="space-y-1 text-[11px] font-mono border-t border-slate-900 pt-2 text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-sans">Transition Cycle:</span>
                    <span className="font-semibold text-emerald-400">&lt; 16 ms Transfer</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-sans">Protocols:</span>
                    <span>Modbus-TCP / DNP3</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-sans">Audit Trail:</span>
                    <span>Synchronized GPS Clock</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="px-3.5 pb-3 pt-1 border-t border-slate-900/60 text-[10px] text-slate-500 flex items-center justify-between font-sans">
              <span>Catalog: GM-RTU-100</span>
              <span className="text-emerald-400 font-semibold">IEC 61850</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
