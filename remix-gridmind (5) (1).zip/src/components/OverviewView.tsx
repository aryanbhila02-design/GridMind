/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Overview Dashboard View
 */

import React from 'react';
import {
  Zap,
  Activity,
  BatteryCharging,
  AlertTriangle,
  Clock,
  Cpu,
  Layers,
  Sun,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { ForecastHourResult, GridMode } from '../types/microgrid';
import { DemandChart } from './DemandChart';
import { BatteryChart } from './BatteryChart';

interface OverviewViewProps {
  forecastData: ForecastHourResult[];
  currentMode: GridMode;
  peakDemand: number;
  peakTimestamp: string;
  hoursInRenewableStorage: number;
  hoursInMainGrid: number;
  criticalAlertCount: number;
  batterySocPct: number;
  batterySocKwh: number;
  isQuickMlLive: boolean;
  lastForecastTimestamp?: string;
  modelUsed: string;
  onNavigateToUpload: () => void;
  onNavigateToController: () => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  forecastData,
  currentMode,
  peakDemand,
  peakTimestamp,
  hoursInRenewableStorage,
  hoursInMainGrid,
  criticalAlertCount,
  batterySocPct,
  batterySocKwh,
  isQuickMlLive,
  lastForecastTimestamp,
  modelUsed,
  onNavigateToUpload,
  onNavigateToController,
}) => {
  const latestDemand = forecastData[0]?.predicted_demand_kw ?? 135.0;

  // Calculate 24-hour aggregate energy balance
  const totalDemandKwh = forecastData.reduce((acc, r) => acc + r.predicted_demand_kw, 0);
  const totalGridImportKwh = forecastData.reduce((acc, r) => acc + r.grid_import_kw, 0);
  const totalBatteryDischargeKwh = forecastData.reduce(
    (acc, r) => acc + (r.battery_power_kw > 0 ? r.battery_power_kw : 0),
    0
  );
  const totalSolarUsedKwh = forecastData.reduce((acc, r) => acc + r.solar_used_kw, 0);

  const solarSharePct = totalDemandKwh > 0 ? ((totalSolarUsedKwh / totalDemandKwh) * 100).toFixed(1) : '0';
  const batterySharePct = totalDemandKwh > 0 ? ((totalBatteryDischargeKwh / totalDemandKwh) * 100).toFixed(1) : '0';
  const gridSharePct = totalDemandKwh > 0 ? ((totalGridImportKwh / totalDemandKwh) * 100).toFixed(1) : '0';

  return (
    <div className="space-y-6">
      {/* 8 Metric Summary KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Metric 1: Current Grid Mode */}
        <div className="bg-slate-900/70 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Operating Mode</span>
            <Layers className="w-4 h-4 text-cyan-400 shrink-0" />
          </div>
          <div>
            <div
              className={`text-base font-bold tracking-tight truncate ${
                currentMode === 'Renewable Storage Mode' ? 'text-cyan-300' : 'text-slate-100'
              }`}
            >
              {currentMode}
            </div>
            <div className="text-[11px] text-slate-400 mt-1 truncate" title={currentMode === 'Renewable Storage Mode' ? 'Load > 160 kW or 18-22h peak' : 'Nominal main grid dispatch'}>
              {currentMode === 'Renewable Storage Mode' ? 'Load > 160 kW or 18-22h peak' : 'Nominal main grid dispatch'}
            </div>
          </div>
        </div>

        {/* Metric 2: Latest Demand */}
        <div className="bg-slate-900/70 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Latest Predicted Demand</span>
            <Zap className="w-4 h-4 text-amber-400 shrink-0" />
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-white tabular-nums">
              {latestDemand.toFixed(1)} <span className="text-xs font-normal text-slate-400 font-sans">kW</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1 flex flex-wrap items-center gap-1.5">
              <span>Next interval:</span>
              <span className={latestDemand > 160 ? 'text-cyan-400 font-semibold' : 'text-emerald-400 font-semibold'}>
                {latestDemand > 160 ? '> 160 kW active' : '≤ 160 kW'}
              </span>
            </div>
          </div>
        </div>

        {/* Metric 3: Peak Demand & Time */}
        <div className="bg-slate-900/70 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Predicted 24h Peak</span>
            <Activity className="w-4 h-4 text-rose-400 shrink-0" />
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-rose-300 tabular-nums">
              {peakDemand.toFixed(1)} <span className="text-xs font-normal text-slate-400 font-sans">kW</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1 font-mono truncate">
              Peak at {peakTimestamp ? peakTimestamp.split('T')[1]?.slice(0, 5) || peakTimestamp : '19:00'}
            </div>
          </div>
        </div>

        {/* Metric 4: Grid Mode Duration Split */}
        <div className="bg-slate-900/70 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Mode Schedule (24h)</span>
            <Clock className="w-4 h-4 text-cyan-400 shrink-0" />
          </div>
          <div>
            <div className="flex flex-wrap items-baseline gap-x-1.5 gap-y-0.5 font-mono">
              <span className="text-base sm:text-lg font-bold text-cyan-300 tabular-nums">{hoursInRenewableStorage}h</span>
              <span className="text-xs text-slate-400 font-sans">Renewable</span>
              <span className="text-slate-600 font-sans">/</span>
              <span className="text-base sm:text-lg font-bold text-slate-300 tabular-nums">{hoursInMainGrid}h</span>
              <span className="text-xs text-slate-400 font-sans">Grid</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1 truncate" title={hoursInRenewableStorage > 0 ? 'Evening peak or high load detected' : 'Full base grid window'}>
              {hoursInRenewableStorage > 0 ? 'Evening peak or high load detected' : 'Full base grid window'}
            </div>
          </div>
        </div>

        {/* Metric 5: Critical Overload Alerts */}
        <div className="bg-slate-900/70 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Critical Overload Alerts</span>
            <AlertTriangle className={`w-4 h-4 shrink-0 ${criticalAlertCount > 0 ? 'text-rose-500' : 'text-slate-500'}`} />
          </div>
          <div>
            <div
              className={`text-2xl font-bold font-mono tabular-nums ${
                criticalAlertCount > 0 ? 'text-rose-400' : 'text-emerald-400'
              }`}
            >
              {criticalAlertCount}
            </div>
            <div className="text-[11px] text-slate-400 mt-1 truncate">
              {criticalAlertCount > 0
                ? 'Hours ≥ 200 kW microgrid limit'
                : 'Zero overload conditions'}
            </div>
          </div>
        </div>

        {/* Metric 6: Battery State of Charge */}
        <div className="bg-slate-900/70 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Battery SOC</span>
            <BatteryCharging className="w-4 h-4 text-emerald-400 shrink-0" />
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-emerald-300 tabular-nums">
              {batterySocPct}%
            </div>
            <div className="text-[11px] text-slate-400 mt-1 font-mono truncate">
              {batterySocKwh.toFixed(1)} kWh available
            </div>
          </div>
        </div>

        {/* Metric 7: QuickML Connectivity */}
        <div className="bg-slate-900/70 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Zoho QuickML Status</span>
            <Cpu className="w-4 h-4 text-cyan-400 shrink-0" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span
                className={`text-sm font-semibold truncate ${
                  isQuickMlLive ? 'text-emerald-300' : 'text-amber-300'
                }`}
              >
                {isQuickMlLive ? 'QuickML Connected' : 'Local Fallback'}
              </span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1 truncate" title={isQuickMlLive ? 'Published Catalyst Model' : 'Local Rule-Based Baseline (Demo Mode)'}>
              {isQuickMlLive ? 'Published Catalyst Model' : 'Trained Ridge Pipeline'}
            </div>
          </div>
        </div>

        {/* Metric 8: Last Forecast Timestamp */}
        <div className="bg-slate-900/70 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Last Forecast Run</span>
            <ShieldCheck className="w-4 h-4 text-teal-400" />
          </div>
          <div>
            <div className="text-sm font-semibold font-mono text-slate-200">
              {lastForecastTimestamp ? new Date(lastForecastTimestamp).toLocaleTimeString() : 'Ready'}
            </div>
            <div className="text-[11px] text-slate-400 mt-1 truncate">
              24 hourly points generated
            </div>
          </div>
        </div>
      </div>

      {/* Main 24-Hour Demand Forecast Card */}
      <div className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-sm font-semibold text-white tracking-tight flex items-center gap-2">
              <span>24-Hour Electricity Demand Forecast & Operational Limits</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Microgrid load trajectory with official 160 kW mode transition and 200 kW overload reference lines.
            </p>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <span className="text-slate-400 text-[11px]">
              Engine: <span className="text-cyan-300 font-mono">{modelUsed}</span>
            </span>
          </div>
        </div>

        <DemandChart data={forecastData} showActuals={true} />
      </div>

      {/* Grid Timeline Bar */}
      <div className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-5">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-xs font-semibold text-slate-200">
              24-Hour Grid Operating Mode Schedule
            </h3>
            <p className="text-[11px] text-slate-400">
              Hour-by-hour dispatch state determined strictly by HackSphere 3.0 microgrid rules.
            </p>
          </div>
          <div className="flex items-center gap-3 text-[11px]">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-xs bg-slate-700 inline-block"></span>
              <span className="text-slate-300">Main Grid Mode</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-xs bg-cyan-500 inline-block"></span>
              <span className="text-cyan-300">Renewable Storage Mode</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-xs bg-rose-500 inline-block"></span>
              <span className="text-rose-300">Overload (≥200 kW)</span>
            </div>
          </div>
        </div>

        {/* 24 Segment Bar */}
        <div className="overflow-x-auto pb-1">
          <div className="grid grid-cols-24 gap-1 h-9 min-w-[540px] sm:min-w-0 rounded-lg overflow-hidden bg-slate-950 p-1 border border-slate-800">
            {forecastData.map(d => {
              const isStorage = d.grid_mode === 'Renewable Storage Mode';
              const isOverload = d.critical_overload;
              const bgClass = isOverload
                ? 'bg-rose-500/80 hover:bg-rose-400'
                : isStorage
                ? 'bg-cyan-500/80 hover:bg-cyan-400'
                : 'bg-slate-700/80 hover:bg-slate-600';

              return (
                <div
                  key={`timeline-${d.hour}`}
                  title={`Hour ${d.hour}:00 - ${d.predicted_demand_kw} kW (${d.grid_mode})`}
                  className={`${bgClass} rounded-xs flex items-center justify-center text-[9px] font-mono text-slate-950 font-bold transition-colors cursor-help`}
                >
                  {d.hour}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Two Column Layout: Battery Dispatch & Energy Balance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Battery SOC & Flow */}
        <div className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-xs font-semibold text-slate-200">
                Battery State of Charge & Power Flow
              </h3>
              <p className="text-[11px] text-slate-400">
                500 kWh BESS simulation obeying capacity and C-rate discharge constraints.
              </p>
            </div>
            <button
              onClick={onNavigateToController}
              className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
            >
              Simulate What-If →
            </button>
          </div>
          <BatteryChart data={forecastData} />
        </div>

        {/* Energy Balance & Source Breakdown */}
        <div className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-xs font-semibold text-slate-200">
                  24-Hour Cumulative Energy Balance
                </h3>
                <p className="text-[11px] text-slate-400">
                  Conservation of energy: Total Demand ({totalDemandKwh.toFixed(0)} kWh) supplied across sources.
                </p>
              </div>
              <span className="text-[11px] font-mono text-cyan-400">
                {totalDemandKwh.toFixed(0)} kWh Total
              </span>
            </div>

            {/* Energy Source Progress Bar */}
            <div className="w-full h-4 bg-slate-950 rounded-lg overflow-hidden flex border border-slate-800 mb-4">
              <div
                style={{ width: `${gridSharePct}%` }}
                className="bg-slate-600 h-full"
                title={`Grid Import: ${gridSharePct}%`}
              />
              <div
                style={{ width: `${solarSharePct}%` }}
                className="bg-amber-400 h-full"
                title={`Solar Direct: ${solarSharePct}%`}
              />
              <div
                style={{ width: `${batterySharePct}%` }}
                className="bg-emerald-500 h-full"
                title={`Battery Discharge: ${batterySharePct}%`}
              />
            </div>

            {/* Source Details Grid */}
            <div className="grid grid-cols-3 gap-3 text-xs font-mono">
              <div className="bg-slate-950/60 border border-slate-800/60 rounded-lg p-3">
                <div className="text-slate-400 text-[10px] uppercase font-sans">Grid Import</div>
                <div className="text-base font-bold text-slate-200 mt-1 tabular-nums">
                  {totalGridImportKwh.toFixed(0)} <span className="text-[10px] font-normal text-slate-400 font-sans">kWh</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">{gridSharePct}% of total</div>
              </div>

              <div className="bg-slate-950/60 border border-slate-800/60 rounded-lg p-3">
                <div className="text-slate-400 text-[10px] uppercase font-sans">Solar Direct</div>
                <div className="text-base font-bold text-amber-300 mt-1 tabular-nums">
                  {totalSolarUsedKwh.toFixed(0)} <span className="text-[10px] font-normal text-slate-400 font-sans">kWh</span>
                </div>
                <div className="text-[10px] text-amber-500/80 mt-0.5">{solarSharePct}% of total</div>
              </div>

              <div className="bg-slate-950/60 border border-slate-800/60 rounded-lg p-3">
                <div className="text-slate-400 text-[10px] uppercase font-sans">Battery Storage</div>
                <div className="text-base font-bold text-emerald-400 mt-1 tabular-nums">
                  {totalBatteryDischargeKwh.toFixed(0)} <span className="text-[10px] font-normal text-slate-400 font-sans">kWh</span>
                </div>
                <div className="text-[10px] text-emerald-500/80 mt-0.5">{batterySharePct}% of total</div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs text-slate-400">
            <span>Microgrid Self-Sufficiency:</span>
            <span className="font-mono font-bold text-cyan-300 tabular-nums">
              {(parseFloat(solarSharePct) + parseFloat(batterySharePct)).toFixed(1)}% Renewable & Stored
            </span>
          </div>
        </div>
      </div>

      {/* Decision Table */}
      <div className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-xs font-semibold text-slate-200">
              Hourly Grid Dispatch Audit Trail (Sample Hours)
            </h3>
            <p className="text-[11px] text-slate-400">
              Deterministic rule evaluation adhering to the HackSphere 3.0 specification.
            </p>
          </div>
          <button
            onClick={onNavigateToUpload}
            className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
          >
            Upload Telemetry CSV →
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-sans text-[11px]">
                <th className="py-2 px-3">Hour</th>
                <th className="py-2 px-3">Weather Telemetry</th>
                <th className="py-2 px-3 text-right">Predicted Demand</th>
                <th className="py-2 px-3">Operating Mode</th>
                <th className="py-2 px-3">Alert State</th>
                <th className="py-2 px-3 font-sans">Rule Justification</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {forecastData.slice(0, 8).map(r => (
                <tr key={`row-${r.hour}`} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-2.5 px-3 text-slate-300 font-semibold">
                    {r.hour.toString().padStart(2, '0')}:00
                  </td>
                  <td className="py-2.5 px-3 text-slate-400 text-[11px]">
                    {r.ambient_temp_c}°C · {r.humidity_pct}% RH · {r.solar_irradiance_wm2} W/m²
                  </td>
                  <td className="py-2.5 px-3 text-right text-cyan-300 font-bold tabular-nums">
                    {r.predicted_demand_kw} kW
                  </td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded ${
                        r.grid_mode === 'Renewable Storage Mode'
                          ? 'bg-cyan-950 text-cyan-300 border border-cyan-800/60'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {r.grid_mode}
                    </span>
                  </td>
                  <td className="py-2.5 px-3">
                    {r.critical_overload ? (
                      <span className="text-[10px] px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 flex items-center gap-1 w-max">
                        <AlertTriangle className="w-3 h-3" /> Overload (≥200 kW)
                      </span>
                    ) : (
                      <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-500" /> Nominal
                      </span>
                    )}
                  </td>
                  <td className="py-2.5 px-3 text-slate-400 font-sans text-[11px] truncate max-w-xs">
                    {r.decision_reason}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
