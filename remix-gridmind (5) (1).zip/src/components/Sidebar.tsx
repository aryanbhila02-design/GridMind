/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Collapsible Professional Microgrid Sidebar
 * HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine
 */

import React from 'react';
import {
  LayoutDashboard,
  TrendingUp,
  Sliders,
  BatteryCharging,
  UploadCloud,
  LineChart,
  History,
  Settings,
  Zap,
  ChevronLeft,
  ChevronRight,
  Brain,
  Compass,
  ShieldAlert,
  Flame,
  Globe,
  X,
} from 'lucide-react';

export type NavView =
  | 'overview'
  | 'forecast'
  | 'controller'
  | 'battery'
  | 'mllab'
  | 'explainability'
  | 'uncertainty'
  | 'peak'
  | 'nationalgrid'
  | 'upload'
  | 'analytics'
  | 'events'
  | 'config';

interface SidebarProps {
  currentView: NavView;
  onSelectView: (view: NavView) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  criticalAlertCount: number;
  isQuickMlLive: boolean;
  mobileOpen?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onSelectView,
  collapsed,
  onToggleCollapse,
  criticalAlertCount,
  isQuickMlLive,
  mobileOpen,
  onCloseMobile,
}) => {
  const primaryNavItems: { id: NavView; label: string; icon: React.ReactNode; badge?: number }[] = [
    {
      id: 'overview',
      label: 'Overview Dashboard',
      icon: <LayoutDashboard className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'forecast',
      label: '24-Hour Forecast',
      icon: <TrendingUp className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'controller',
      label: 'Grid Controller',
      icon: <Sliders className="w-4 h-4 shrink-0" />,
      badge: criticalAlertCount > 0 ? criticalAlertCount : undefined,
    },
    {
      id: 'battery',
      label: 'Battery & What-If',
      icon: <BatteryCharging className="w-4 h-4 shrink-0" />,
    },
  ];

  const intelligenceNavItems: { id: NavView; label: string; icon: React.ReactNode }[] = [
    {
      id: 'mllab',
      label: 'ML Research Lab',
      icon: <Brain className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'explainability',
      label: 'Explainability (P2)',
      icon: <Compass className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'uncertainty',
      label: 'Uncertainty (P3)',
      icon: <ShieldAlert className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'peak',
      label: 'Peak Intelligence',
      icon: <Flame className="w-4 h-4 shrink-0" />,
    },
  ];

  const operationalNavItems: { id: NavView; label: string; icon: React.ReactNode }[] = [
    {
      id: 'upload',
      label: 'Ingest & Validate',
      icon: <UploadCloud className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'nationalgrid',
      label: 'National Grid (CEA)',
      icon: <Globe className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'analytics',
      label: 'TimeSeries Benchmark',
      icon: <LineChart className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'events',
      label: 'Audit Events',
      icon: <History className="w-4 h-4 shrink-0" />,
    },
    {
      id: 'config',
      label: 'System Config',
      icon: <Settings className="w-4 h-4 shrink-0" />,
    },
  ];

  return (
    <>
      <aside
        className={`hidden md:flex bg-slate-950 border-r border-slate-800 transition-all duration-300 flex-col shrink-0 select-none ${
          collapsed ? 'w-16' : 'w-64'
        }`}
      >
      {/* Brand Header */}
      <div className="p-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2.5 overflow-hidden">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shrink-0 shadow-lg shadow-cyan-500/20">
            <Zap className="w-4 h-4 text-white" />
          </div>
          {!collapsed && (
            <div className="flex flex-col truncate">
              <span className="font-bold text-sm text-slate-100 tracking-wide flex items-center gap-1.5">
                GridMind
              </span>
              <span className="text-[11px] text-slate-400 truncate">
                HackSphere 3.0 Microgrid
              </span>
            </div>
          )}
        </div>
        <button
          onClick={onToggleCollapse}
          className="p-1 rounded-md text-slate-400 hover:text-slate-200 hover:bg-slate-900 transition-colors cursor-pointer"
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* Navigation Groups */}
      <div className="flex-1 py-3 px-2 space-y-4 overflow-y-auto">
        {/* Core Operations */}
        <div className="space-y-1">
          {!collapsed && (
            <div className="px-3 pb-1 text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
              Core Grid
            </div>
          )}
          {primaryNavItems.map(item => {
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectView(item.id)}
                title={collapsed ? item.label : undefined}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                } ${collapsed ? 'justify-center px-0' : ''}`}
              >
                {item.icon}
                {!collapsed && <span className="flex-1 text-left truncate">{item.label}</span>}
                {!collapsed && item.badge !== undefined && (
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-500 text-white">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Intelligence & Research Lab */}
        <div className="space-y-1">
          {!collapsed && (
            <div className="px-3 pb-1 text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
              ML & Intelligence
            </div>
          )}
          {intelligenceNavItems.map(item => {
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectView(item.id)}
                title={collapsed ? item.label : undefined}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-purple-500/10 text-purple-300 border border-purple-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                } ${collapsed ? 'justify-center px-0' : ''}`}
              >
                {item.icon}
                {!collapsed && <span className="flex-1 text-left truncate">{item.label}</span>}
              </button>
            );
          })}
        </div>

        {/* Operations & Benchmarks */}
        <div className="space-y-1">
          {!collapsed && (
            <div className="px-3 pb-1 text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
              Management
            </div>
          )}
          {operationalNavItems.map(item => {
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectView(item.id)}
                title={collapsed ? item.label : undefined}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                } ${collapsed ? 'justify-center px-0' : ''}`}
              >
                {item.icon}
                {!collapsed && <span className="flex-1 text-left truncate">{item.label}</span>}
              </button>
            );
          })}
        </div>
      </div>

      {/* Footer Info */}
      <div className="p-3 border-t border-slate-800 text-[11px] text-slate-400 flex flex-col gap-1.5">
        {!collapsed && (
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-slate-500">QuickML Engine:</span>
            <span
              className={`text-[10px] font-mono font-medium px-2 py-0.5 rounded-full ${
                isQuickMlLive
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
              }`}
            >
              {isQuickMlLive ? 'Live QuickML' : 'Local Fallback'}
            </span>
          </div>
        )}
      </div>
    </aside>

    {/* Mobile Drawer Overlay */}
    {mobileOpen && (
      <div className="md:hidden fixed inset-0 z-50 flex">
        {/* Backdrop */}
        <div
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm transition-opacity"
          onClick={onCloseMobile}
          aria-label="Close navigation backdrop"
        />

        {/* Drawer Container */}
        <div className="relative w-72 max-w-[85vw] bg-slate-950 border-r border-slate-800 flex flex-col h-full z-10 shadow-2xl">
          {/* Header */}
          <div className="p-4 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shrink-0 shadow-lg shadow-cyan-500/20">
                <Zap className="w-4 h-4 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-sm text-slate-100 tracking-wide flex items-center gap-1.5">
                  GridMind
                </span>
                <span className="text-[11px] text-slate-400">HackSphere 3.0 Microgrid</span>
              </div>
            </div>
            <button
              onClick={onCloseMobile}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-900 transition-colors cursor-pointer"
              aria-label="Close navigation menu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Mobile Nav Items */}
          <div className="flex-1 py-3 px-3 space-y-4 overflow-y-auto">
            {/* Core Grid */}
            <div className="space-y-1">
              <div className="px-3 pb-1 text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
                Core Grid
              </div>
              {primaryNavItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => {
                    onSelectView(item.id);
                    onCloseMobile?.();
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    currentView === item.id
                      ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  {item.icon}
                  <span className="flex-1 text-left">{item.label}</span>
                  {item.badge !== undefined && (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-500 text-white">
                      {item.badge}
                    </span>
                  )}
                </button>
              ))}
            </div>

            {/* ML & Intelligence */}
            <div className="space-y-1">
              <div className="px-3 pb-1 text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
                ML & Intelligence
              </div>
              {intelligenceNavItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => {
                    onSelectView(item.id);
                    onCloseMobile?.();
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    currentView === item.id
                      ? 'bg-purple-500/10 text-purple-300 border border-purple-500/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  {item.icon}
                  <span className="flex-1 text-left">{item.label}</span>
                </button>
              ))}
            </div>

            {/* Management */}
            <div className="space-y-1">
              <div className="px-3 pb-1 text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
                Management
              </div>
              {operationalNavItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => {
                    onSelectView(item.id);
                    onCloseMobile?.();
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    currentView === item.id
                      ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  {item.icon}
                  <span className="flex-1 text-left">{item.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Mobile Footer */}
          <div className="p-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span className="text-[10px] text-slate-500">QuickML Engine:</span>
            <span
              className={`text-[10px] font-mono font-medium px-2 py-0.5 rounded-full ${
                isQuickMlLive
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
              }`}
            >
              {isQuickMlLive ? 'Live QuickML' : 'Local Fallback'}
            </span>
          </div>
        </div>
      </div>
    )}
  </>
  );
};
