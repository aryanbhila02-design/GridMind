/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Controller Rules Official Verification Suite
 * Task 6 Mandatory Test Cases (Strict Parity Check)
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateGridTransition } from '../engine/transitionController.ts';

// -------------------------------------------------------------
// TASK 6 MANDATORY TEST CASES
// -------------------------------------------------------------

test('Test 1: Demand = 120 kW, hour = 14:00 -> Main Grid, Critical Overload: No', () => {
  const result = evaluateGridTransition('2026-10-27T14:00:00', 120);
  assert.equal(result.grid_mode, 'Main Grid Mode');
  assert.equal(result.critical_overload, false);
  assert.equal(result.hour, 14);
});

test('Test 2: Demand = 170 kW, hour = 14:00 -> Renewable Storage, Critical Overload: No', () => {
  const result = evaluateGridTransition('2026-10-27T14:00:00', 170);
  assert.equal(result.grid_mode, 'Renewable Storage Mode');
  assert.equal(result.critical_overload, false);
  assert.equal(result.hour, 14);
});

test('Test 3: Demand = 120 kW, hour = 19:00 -> Renewable Storage, Critical Overload: No', () => {
  const result = evaluateGridTransition('2026-10-27T19:00:00', 120);
  assert.equal(result.grid_mode, 'Renewable Storage Mode');
  assert.equal(result.critical_overload, false);
  assert.equal(result.hour, 19);
});

test('Test 4: Demand = 200 kW, hour = 14:00 -> Renewable Storage, Critical Overload: Yes', () => {
  const result = evaluateGridTransition('2026-10-27T14:00:00', 200);
  assert.equal(result.grid_mode, 'Renewable Storage Mode');
  assert.equal(result.critical_overload, true);
  assert.equal(result.hour, 14);
});

test('Test 5: Demand = 160 kW, hour = 14:00 -> Main Grid, Critical Overload: No', () => {
  const result = evaluateGridTransition('2026-10-27T14:00:00', 160);
  assert.equal(result.grid_mode, 'Main Grid Mode');
  assert.equal(result.critical_overload, false);
  assert.equal(result.hour, 14);
});

test('Test 6: Demand = 199.9 kW, hour = 14:00 -> Renewable Storage, Critical Overload: No', () => {
  const result = evaluateGridTransition('2026-10-27T14:00:00', 199.9);
  assert.equal(result.grid_mode, 'Renewable Storage Mode');
  assert.equal(result.critical_overload, false);
  assert.equal(result.hour, 14);
});

test('Test 7: Demand = 150 kW, hour = 22:00 -> Renewable Storage, Critical Overload: No', () => {
  const result = evaluateGridTransition('2026-10-27T22:00:00', 150);
  assert.equal(result.grid_mode, 'Renewable Storage Mode');
  assert.equal(result.critical_overload, false);
  assert.equal(result.hour, 22);
});

test('Test 8: Demand = 150 kW, hour = 23:00 -> Main Grid, Critical Overload: No', () => {
  const result = evaluateGridTransition('2026-10-27T23:00:00', 150);
  assert.equal(result.grid_mode, 'Main Grid Mode');
  assert.equal(result.critical_overload, false);
  assert.equal(result.hour, 23);
});

test('Advisory Principle: Recommendations do not assert direct physical hardware control', () => {
  const decision = evaluateGridTransition('2026-10-27T18:00:00', 180);
  assert.ok(decision.decision_reason.length > 0);
  assert.equal(typeof decision.grid_mode, 'string');
});
