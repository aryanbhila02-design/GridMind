/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * Comprehensive Unit Tests for Safe API Client & HTML Fallback Detection
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { safeFetchJson } from '../utils/apiClient.ts';

test('API Client: Detects HTML responses and does not crash on <!doctype html>', async () => {
  // Mock global fetch returning HTML
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => {
    return new Response('<!doctype html><html><body>Slate SPA fallback</body></html>', {
      status: 200,
      headers: { 'content-type': 'text/html; charset=utf-8' },
    });
  };

  try {
    const res = await safeFetchJson('/api/ml/explainability');
    assert.equal(res.ok, false);
    assert.equal(res.isHtmlResponse, true);
    assert.ok(res.error?.includes('HTML document'));
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('API Client: Handles valid JSON responses cleanly', async () => {
  const originalFetch = globalThis.fetch;
  const mockPayload = { success: true, baselineRmse: 10.45, items: [1, 2, 3] };
  globalThis.fetch = async () => {
    return new Response(JSON.stringify(mockPayload), {
      status: 200,
      headers: { 'content-type': 'application/json' },
    });
  };

  try {
    const res = await safeFetchJson<typeof mockPayload>('/api/ml/explainability');
    assert.equal(res.ok, true);
    assert.equal(res.data?.baselineRmse, 10.45);
    assert.equal(res.status, 200);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('API Client: Handles HTTP 404 JSON errors properly', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => {
    return new Response(JSON.stringify({ success: false, error: 'Route not found' }), {
      status: 404,
      headers: { 'content-type': 'application/json' },
    });
  };

  try {
    const res = await safeFetchJson('/api/unknown');
    assert.equal(res.ok, false);
    assert.equal(res.status, 404);
    assert.equal(res.error, 'Route not found');
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('API Client: Handles network failure gracefully without throwing uncaught exceptions', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => {
    throw new Error('Failed to fetch: Connection refused');
  };

  try {
    const res = await safeFetchJson('/api/unreachable');
    assert.equal(res.ok, false);
    assert.equal(res.isNetworkError, true);
    assert.ok(res.error?.includes('Connection refused'));
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('API Client: Handles HTTP 405 Method Not Allowed with clear diagnostic message', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => {
    return new Response(JSON.stringify({ error: 'Method Not Allowed' }), {
      status: 405,
      headers: { 'content-type': 'application/json' },
    });
  };

  try {
    const res = await safeFetchJson('/api/quickml/test-connection', { method: 'POST' });
    assert.equal(res.ok, false);
    assert.equal(res.status, 405);
    assert.equal(res.error, 'Method Not Allowed');
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test('API Client: Supplies descriptive fallback when HTTP 405 returns no error body', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => {
    return new Response('{}', {
      status: 405,
      headers: { 'content-type': 'application/json' },
    });
  };

  try {
    const res = await safeFetchJson('/api/quickml/test-connection', { method: 'POST' });
    assert.equal(res.ok, false);
    assert.equal(res.status, 405);
    assert.ok(res.error?.includes('405 Method Not Allowed'));
    assert.ok(res.error?.includes('Slate'));
  } finally {
    globalThis.fetch = originalFetch;
  }
});
