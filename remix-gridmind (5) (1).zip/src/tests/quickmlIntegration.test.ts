/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Comprehensive Zoho Catalyst QuickML Integration Test Suite
 * Task 5: Validates Live QuickML, Fallback, Error Handling, and Source Transparency
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  invokeQuickMLBatch,
  invokeQuickMLRegionalPeakDemand,
  QUICKML_DEPLOYED_MODEL_INFO,
  evaluateQuickMLHoldout,
  getServerQuickMLConfig,
  isQuickMLConfigured,
} from '../engine/quickmlClient.ts';
import { executeForecast } from '../engine/forecastingEngine.ts';
import type { TelemetryRow } from '../types/microgrid.ts';


const SAMPLE_ROWS: TelemetryRow[] = [
  {
    timestamp: '2026-10-27T14:00:00',
    ambient_temp_c: 25.0,
    humidity_pct: 50,
    solar_irradiance_wm2: 600,
  },
  {
    timestamp: '2026-10-27T15:00:00',
    ambient_temp_c: 26.5,
    humidity_pct: 48,
    solar_irradiance_wm2: 550,
  },
];

test('QuickML: Unconfigured endpoint returns unverified source and does not throw', async () => {
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;
  delete process.env.ZOHO_QUICKML_ENDPOINT;

  try {
    const res = await invokeQuickMLBatch(SAMPLE_ROWS);
    assert.equal(res.success, false);
    assert.equal(res.source, 'unverified');
    assert.ok(res.error?.includes('not configured'));
  } finally {
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
  }
});

test('QuickML: Successful response produces live_quickml source and valid predictions', async () => {
  const origFetch = globalThis.fetch;
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;
  const origKey = process.env.ZOHO_CATALYST_API_KEY;

  process.env.ZOHO_QUICKML_ENDPOINT = 'https://quickml.catalyst.zoho.com/baas/v1/project/123/ml/models/456/predict';
  process.env.ZOHO_CATALYST_API_KEY = 'mock_catalyst_auth_token';

  globalThis.fetch = async (_url, init) => {
    // Verify authorization header includes token
    const headers = init?.headers as Record<string, string>;
    assert.ok(headers['Authorization']?.includes('mock_catalyst_auth_token'));
    assert.equal(headers['Content-Type'], 'application/json');

    return new Response(JSON.stringify({ predictions: [175.4, 182.1] }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  };

  try {
    const res = await invokeQuickMLBatch(SAMPLE_ROWS);
    assert.equal(res.success, true);
    assert.equal(res.source, 'live_quickml');
    assert.deepEqual(res.predictions, [175.4, 182.1]);
    assert.ok(res.latencyMs >= 0);
  } finally {
    globalThis.fetch = origFetch;
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
    else delete process.env.ZOHO_QUICKML_ENDPOINT;
    if (origKey) process.env.ZOHO_CATALYST_API_KEY = origKey;
    else delete process.env.ZOHO_CATALYST_API_KEY;
  }
});

test('QuickML: Authentication failure (HTTP 401) reports failure without leaking secret', async () => {
  const origFetch = globalThis.fetch;
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;
  const origKey = process.env.ZOHO_CATALYST_API_KEY;

  process.env.ZOHO_QUICKML_ENDPOINT = 'https://quickml.catalyst.zoho.com/predict';
  process.env.ZOHO_CATALYST_API_KEY = 'super_secret_token_never_leak';

  globalThis.fetch = async () => {
    return new Response(JSON.stringify({ error: 'Unauthorized token' }), {
      status: 401,
      statusText: 'Unauthorized',
      headers: { 'Content-Type': 'application/json' },
    });
  };

  try {
    const res = await invokeQuickMLBatch(SAMPLE_ROWS);
    assert.equal(res.success, false);
    assert.equal(res.source, 'failed');
    assert.equal(res.httpStatus, 401);
    assert.ok(res.error?.includes('Authentication failed'));
    assert.ok(!res.error?.includes('super_secret_token_never_leak'), 'Must not leak secrets in error message');
  } finally {
    globalThis.fetch = origFetch;
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
    else delete process.env.ZOHO_QUICKML_ENDPOINT;
    if (origKey) process.env.ZOHO_CATALYST_API_KEY = origKey;
    else delete process.env.ZOHO_CATALYST_API_KEY;
  }
});

test('QuickML: Service unavailability (HTTP 503) is handled gracefully', async () => {
  const origFetch = globalThis.fetch;
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;

  process.env.ZOHO_QUICKML_ENDPOINT = 'https://quickml.catalyst.zoho.com/predict';

  globalThis.fetch = async () => {
    return new Response('Service Unavailable', {
      status: 503,
      statusText: 'Service Unavailable',
      headers: { 'Content-Type': 'text/plain' },
    });
  };

  try {
    const res = await invokeQuickMLBatch(SAMPLE_ROWS);
    assert.equal(res.success, false);
    assert.equal(res.source, 'failed');
    assert.equal(res.httpStatus, 503);
    assert.ok(res.error?.includes('QuickML service error'));
  } finally {
    globalThis.fetch = origFetch;
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
    else delete process.env.ZOHO_QUICKML_ENDPOINT;
  }
});

test('QuickML: Request timeout aborts and returns clean error', async () => {
  const origFetch = globalThis.fetch;
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;

  process.env.ZOHO_QUICKML_ENDPOINT = 'https://quickml.catalyst.zoho.com/predict';

  globalThis.fetch = async (_url, init) => {
    return new Promise((_resolve, reject) => {
      init?.signal?.addEventListener('abort', () => {
        const abortErr = new Error('This operation was aborted');
        abortErr.name = 'AbortError';
        reject(abortErr);
      });
    });
  };

  try {
    const res = await invokeQuickMLBatch(SAMPLE_ROWS, 50); // 50ms fast timeout
    assert.equal(res.success, false);
    assert.equal(res.source, 'failed');
    assert.ok(res.error?.toLowerCase().includes('timed out'));
  } finally {
    globalThis.fetch = origFetch;
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
    else delete process.env.ZOHO_QUICKML_ENDPOINT;
  }
});

test('QuickML: Invalid response schema with mismatched row count is rejected safely', async () => {
  const origFetch = globalThis.fetch;
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;

  process.env.ZOHO_QUICKML_ENDPOINT = 'https://quickml.catalyst.zoho.com/predict';

  // Return 1 item when 2 were requested
  globalThis.fetch = async () => {
    return new Response(JSON.stringify({ predictions: [150.0] }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  };

  try {
    const res = await invokeQuickMLBatch(SAMPLE_ROWS);
    assert.equal(res.success, false);
    assert.equal(res.source, 'failed');
    assert.ok(res.error?.includes('could not be parsed into 2 valid numeric predictions'));
  } finally {
    globalThis.fetch = origFetch;
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
    else delete process.env.ZOHO_QUICKML_ENDPOINT;
  }
});

test('Forecasting Engine: Uses live QuickML predictions and labels source as live_quickml', async () => {
  const origFetch = globalThis.fetch;
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;

  process.env.ZOHO_QUICKML_ENDPOINT = 'https://quickml.catalyst.zoho.com/predict';

  globalThis.fetch = async () => {
    return new Response(JSON.stringify({ predictions: [172.5, 205.0] }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  };

  try {
    const output = await executeForecast(SAMPLE_ROWS, {
      endpointUrl: process.env.ZOHO_QUICKML_ENDPOINT,
      apiKey: 'test',
      projectId: 'p1',
      catalystEnv: 'development',
      timeoutMs: 5000,
      isConnected: true,
      connectionStatus: 'connected_verified',
    });

    assert.equal(output.source, 'live_quickml');
    assert.equal(output.isQuickMlLive, true);
    assert.equal(output.forecastingMode, 'live_quickml');
    assert.equal(output.results[0].predicted_demand_kw, 172.5);
    // Task 6 check: 172.5 kW > 160 kW -> Renewable Storage Mode
    assert.equal(output.results[0].grid_mode, 'Renewable Storage Mode');
    assert.equal(output.results[1].predicted_demand_kw, 205.0);
    // Task 6 check: 205.0 kW >= 200 kW -> Critical Overload
    assert.equal(output.results[1].critical_overload, true);
  } finally {
    globalThis.fetch = origFetch;
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
    else delete process.env.ZOHO_QUICKML_ENDPOINT;
  }
});

test('Forecasting Engine: Falls back safely when QuickML fails and labels source as fallback', async () => {
  const origFetch = globalThis.fetch;
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;

  process.env.ZOHO_QUICKML_ENDPOINT = 'https://quickml.catalyst.zoho.com/predict';

  globalThis.fetch = async () => {
    return new Response(JSON.stringify({ error: 'Model internal error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  };

  try {
    const output = await executeForecast(SAMPLE_ROWS, {
      endpointUrl: process.env.ZOHO_QUICKML_ENDPOINT,
      apiKey: 'test',
      projectId: 'p1',
      catalystEnv: 'development',
      timeoutMs: 5000,
      isConnected: false,
      connectionStatus: 'connection_failed',
    });

    // Verification of Task 3 & Task 5:
    assert.equal(output.source, 'fallback');
    assert.equal(output.isQuickMlLive, false);
    assert.equal(output.forecastingMode, 'quickml_failed_fallback');
    assert.ok(output.results.length === 2);
    // Predictions generated by local baseline model
    assert.ok(output.results[0].predicted_demand_kw > 0);
    assert.ok(!output.modelUsed.includes('Live Endpoint'));
  } finally {
    globalThis.fetch = origFetch;
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
    else delete process.env.ZOHO_QUICKML_ENDPOINT;
  }
});

test('QuickML Regional: Rejects records missing required Region_ID or Entity_Name', async () => {
  const badInput = [
    { Region_ID: '', Entity_Name: 'Uttar Pradesh', Peak_Demand_MW: 31120 },
  ];
  const res = await invokeQuickMLRegionalPeakDemand(badInput as any);
  assert.equal(res.success, false);
  assert.ok(res.error?.includes('missing required feature'));
});

test('QuickML Regional: Prevents target leakage by stripping May_2026_peak_demand_MW from request', async () => {
  const origFetch = globalThis.fetch;
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;

  process.env.ZOHO_QUICKML_ENDPOINT = 'https://quickml.catalyst.zoho.com/predict';

  let capturedPayload: any = null;
  globalThis.fetch = async (_url, init) => {
    capturedPayload = JSON.parse(init?.body as string);
    return new Response(JSON.stringify({ predictions: [31500.0] }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  };

  try {
    const recordsWithTarget = [
      {
        Region_ID: 'NR',
        Entity_Name: 'Uttar Pradesh',
        Peak_Demand_MW: 30240,
        Jan_2026_peak_demand_MW: 29500,
        // Attempting to leak the target column
        May_2026_peak_demand_MW: 32000,
        target: 32000,
      },
    ];

    const res = await invokeQuickMLRegionalPeakDemand(recordsWithTarget);
    assert.equal(res.success, true);
    assert.equal(res.source, 'live_quickml');

    // Verify anti-leakage defense: target must NOT be in the instances sent to the model!
    const sentInstance = capturedPayload.instances[0];
    assert.equal(sentInstance.May_2026_peak_demand_MW, undefined, 'Target must be stripped to prevent leakage');
    assert.equal(sentInstance.target, undefined, 'Target alias must be stripped to prevent leakage');
    assert.equal(sentInstance.Region_ID, 'NR');
    assert.equal(sentInstance.Entity_Name, 'Uttar Pradesh');
  } finally {
    globalThis.fetch = origFetch;
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
    else delete process.env.ZOHO_QUICKML_ENDPOINT;
  }
});

test('QuickML Regional: Unconfigured endpoint falls back to calibrated CEA regional baseline with clear labeling', async () => {
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;
  delete process.env.ZOHO_QUICKML_ENDPOINT;

  try {
    const input = [
      { Region_ID: 'NR', Entity_Name: 'Punjab', Peak_Demand_MW: 16125 },
      { Region_ID: 'WR', Entity_Name: 'Maharashtra', Peak_Demand_MW: 29840 },
    ];

    const res = await invokeQuickMLRegionalPeakDemand(input);
    assert.equal(res.success, true);
    assert.equal(res.source, 'regional_baseline');
    assert.equal(res.predictions?.length, 2);
    // Verified summer heatwave growth factor for NR (> 16125 MW)
    assert.ok(res.predictions![0].predicted_May_2026_peak_demand_MW > 16125);
    assert.ok(res.suitabilityNotice.includes('NOT Hourly Microgrid'));
  } finally {
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
  }
});

test('QuickML: Supports QUICKML_ENDPOINT_URL and QUICKML_ENDPOINT_KEY environment variable names', () => {
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;
  const origUrl = process.env.QUICKML_ENDPOINT_URL;
  const origKey = process.env.QUICKML_ENDPOINT_KEY;

  delete process.env.ZOHO_QUICKML_ENDPOINT;
  process.env.QUICKML_ENDPOINT_URL = 'https://quickml.catalyst.zoho.com/predict-alias';
  process.env.QUICKML_ENDPOINT_KEY = 'mock_key_alias';

  try {
    const config = getServerQuickMLConfig();
    assert.equal(config.endpointUrl, 'https://quickml.catalyst.zoho.com/predict-alias');
    assert.equal(config.apiKey, 'mock_key_alias');
    assert.equal(isQuickMLConfigured(), true);
  } finally {
    delete process.env.QUICKML_ENDPOINT_URL;
    delete process.env.QUICKML_ENDPOINT_KEY;
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
    if (origUrl) process.env.QUICKML_ENDPOINT_URL = origUrl;
    if (origKey) process.env.QUICKML_ENDPOINT_KEY = origKey;
  }
});

test('QuickML Holdout Evaluation: Reports isMeasured: false, null metrics, and Awaiting Endpoint when unconfigured', async () => {
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;
  const origUrl = process.env.QUICKML_ENDPOINT_URL;
  delete process.env.ZOHO_QUICKML_ENDPOINT;
  delete process.env.QUICKML_ENDPOINT_URL;

  try {
    const holdoutData: TelemetryRow[] = [
      { timestamp: '2026-10-27T10:00:00', ambient_temp_c: 24, humidity_pct: 50, solar_irradiance_wm2: 500, target_demand_kw: 140 },
      { timestamp: '2026-10-27T11:00:00', ambient_temp_c: 26, humidity_pct: 48, solar_irradiance_wm2: 600, target_demand_kw: 155 },
    ];

    const result = await evaluateQuickMLHoldout(holdoutData);
    assert.equal(result.isConfigured, false);
    assert.equal(result.isMeasured, false);
    assert.equal(result.status, 'not_configured');
    assert.equal(result.statusLabel, 'Awaiting Endpoint');
    assert.equal(result.rmse, null);
    assert.equal(result.mae, null);
    assert.equal(result.r2, null);
    assert.ok(result.notes.includes('unconnected'));
  } finally {
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
    if (origUrl) process.env.QUICKML_ENDPOINT_URL = origUrl;
  }
});

test('QuickML Holdout Evaluation: Computes genuine empirical RMSE, MAE and R² when endpoint is active', async () => {
  const origFetch = globalThis.fetch;
  const origUrl = process.env.QUICKML_ENDPOINT_URL;
  const origKey = process.env.QUICKML_ENDPOINT_KEY;

  process.env.QUICKML_ENDPOINT_URL = 'https://quickml.catalyst.zoho.com/predict';
  process.env.QUICKML_ENDPOINT_KEY = 'mock_auth_token';

  // Ground truth actuals: [140.0, 150.0]
  // Mock predictions: [142.0, 146.0] -> errors: [+2, -4] -> abs: [2, 4] -> MAE: 3.0 -> sq: [4, 16] -> mean sq: 10 -> RMSE: sqrt(10) ≈ 3.16
  globalThis.fetch = async () => {
    return new Response(JSON.stringify({ predictions: [142.0, 146.0] }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  };

  try {
    const holdoutData: TelemetryRow[] = [
      { timestamp: '2026-10-27T10:00:00', ambient_temp_c: 24, humidity_pct: 50, solar_irradiance_wm2: 500, target_demand_kw: 140.0 },
      { timestamp: '2026-10-27T11:00:00', ambient_temp_c: 26, humidity_pct: 48, solar_irradiance_wm2: 600, target_demand_kw: 150.0 },
    ];

    const result = await evaluateQuickMLHoldout(holdoutData);
    assert.equal(result.isConfigured, true);
    assert.equal(result.isMeasured, true);
    assert.equal(result.status, 'connected_verified');
    assert.equal(result.sampleCount, 2);
    assert.equal(result.mae, 3.0);
    assert.equal(result.rmse, 3.16);
    assert.ok(result.r2 !== null);
    assert.ok(result.notes.includes('Empirically evaluated'));
  } finally {
    globalThis.fetch = origFetch;
    delete process.env.QUICKML_ENDPOINT_URL;
    delete process.env.QUICKML_ENDPOINT_KEY;
    if (origUrl) process.env.QUICKML_ENDPOINT_URL = origUrl;
    if (origKey) process.env.QUICKML_ENDPOINT_KEY = origKey;
  }
});

test('QuickML Holdout Evaluation: Accurately classifies HTTP 401 as auth_failed without fabricating metrics', async () => {
  const origFetch = globalThis.fetch;
  const origUrl = process.env.QUICKML_ENDPOINT_URL;
  const origKey = process.env.QUICKML_ENDPOINT_KEY;

  process.env.QUICKML_ENDPOINT_URL = 'https://quickml.catalyst.zoho.com/predict';
  process.env.QUICKML_ENDPOINT_KEY = 'invalid_expired_token';

  globalThis.fetch = async () => {
    return new Response(JSON.stringify({ error: 'Invalid OAuth token' }), {
      status: 401,
      headers: { 'Content-Type': 'application/json' },
    });
  };

  try {
    const holdoutData: TelemetryRow[] = [
      { timestamp: '2026-10-27T10:00:00', ambient_temp_c: 24, humidity_pct: 50, solar_irradiance_wm2: 500, target_demand_kw: 140.0 },
    ];

    const result = await evaluateQuickMLHoldout(holdoutData);
    assert.equal(result.isConfigured, true);
    assert.equal(result.isMeasured, false);
    assert.equal(result.status, 'auth_failed');
    assert.equal(result.statusLabel, 'Authentication Failed');
    assert.equal(result.rmse, null);
    assert.equal(result.mae, null);
  } finally {
    globalThis.fetch = origFetch;
    delete process.env.QUICKML_ENDPOINT_URL;
    delete process.env.QUICKML_ENDPOINT_KEY;
    if (origUrl) process.env.QUICKML_ENDPOINT_URL = origUrl;
    if (origKey) process.env.QUICKML_ENDPOINT_KEY = origKey;
  }
});

