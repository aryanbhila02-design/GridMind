/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Master Application Entry Point
 * HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine
 */

import React, { useState, useEffect } from 'react';
import { Sidebar, NavView } from './components/Sidebar';
import { TopNav } from './components/TopNav';
import { OverviewView } from './components/OverviewView';
import { ForecastView } from './components/ForecastView';
import { GridControllerView } from './components/GridControllerView';
import { BatteryView } from './components/BatteryView';
import { UploadView } from './components/UploadView';
import { AnalyticsView } from './components/AnalyticsView';
import { EventsView } from './components/EventsView';
import { ConfigView } from './components/ConfigView';
import { MlLabView } from './components/MlLabView';
import { ExplainabilityView } from './components/ExplainabilityView';
import { UncertaintyView } from './components/UncertaintyView';
import { PeakIntelligenceView } from './components/PeakIntelligenceView';
import { NationalGridView } from './components/NationalGridView';
import type {
  BatteryConfig,
  ForecastHourResult,
  GridEvent,
  GridMode,
  TelemetryRow,
} from './types/microgrid';
import { DEFAULT_BATTERY_CONFIG } from './engine/batterySimulator';
import { generateSynthetic24HourTelemetry, executeForecast } from './engine/forecastingEngine';
import { safeFetchJson } from './utils/apiClient';

export default function App() {
  const [currentView, setCurrentView] = useState<NavView>('overview');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [forecastData, setForecastData] = useState<ForecastHourResult[]>([]);
  const [activeTelemetry, setActiveTelemetry] = useState<TelemetryRow[]>([]);
  const [batteryConfig, setBatteryConfig] = useState<BatteryConfig>(DEFAULT_BATTERY_CONFIG);
  const [isForecasting, setIsForecasting] = useState<boolean>(false);
  const [events, setEvents] = useState<GridEvent[]>([]);

  const [metadata, setMetadata] = useState({
    modelUsed: 'Trained Ridge Regression (Held-Out Evaluated on Official Telemetry)',
    isQuickMlLive: false,
    forecastingMode: 'local_baseline_demo',
    timestamp: new Date().toISOString(),
    notes: 'System initialized. Ready for telemetry ingestion or live QuickML invocation.',
  });

  // Fetch latest forecast & grid status from backend or seed on mount
  useEffect(() => {
    safeFetchJson<{
      forecast?: ForecastHourResult[];
      metadata?: typeof metadata;
      batteryConfig?: BatteryConfig;
    }>('/api/forecast/latest').then(res => {
      if (res.ok && res.data?.forecast && Array.isArray(res.data.forecast) && res.data.forecast.length > 0) {
        setForecastData(res.data.forecast);
        if (res.data.metadata) {
          setMetadata(res.data.metadata);
        }
        if (res.data.batteryConfig) {
          setBatteryConfig(res.data.batteryConfig);
        }
      } else {
        runLocalSeedForecast();
      }
    });

    safeFetchJson<{ events?: GridEvent[] }>('/api/grid/events').then(res => {
      if (res.ok && res.data?.events) {
        setEvents(res.data.events);
      }
    });
  }, []);

  const runLocalSeedForecast = async () => {
    const seed = generateSynthetic24HourTelemetry();
    setActiveTelemetry(seed);
    const output = await executeForecast(seed);
    setForecastData(output.results);
    setMetadata({
      modelUsed: output.modelUsed,
      isQuickMlLive: output.isQuickMlLive,
      forecastingMode: output.forecastingMode,
      timestamp: output.executionTimestamp,
      notes: output.notes,
    });
  };

  // Run or Refresh 24-Hour Forecast (Phase 2: Zero client secrets sent)
  const handleRefreshForecast = async (rowsToUse?: TelemetryRow[]) => {
    setIsForecasting(true);
    if (rowsToUse && rowsToUse.length > 0) {
      setActiveTelemetry(rowsToUse);
    }
    try {
      const res = await safeFetchJson<{
        results?: ForecastHourResult[];
        metadata?: typeof metadata;
      }>('/api/forecast', {
        method: 'POST',
        body: JSON.stringify({
          telemetryRows: rowsToUse,
          batteryConfig,
        }),
      });

      if (res.ok && res.data?.results) {
        setForecastData(res.data.results);
        if (res.data.metadata) setMetadata(res.data.metadata);
      } else {
        const telemetry = rowsToUse || (activeTelemetry.length > 0 ? activeTelemetry : generateSynthetic24HourTelemetry());
        setActiveTelemetry(telemetry);
        const output = await executeForecast(telemetry);
        setForecastData(output.results);
        setMetadata({
          modelUsed: output.modelUsed,
          isQuickMlLive: output.isQuickMlLive,
          forecastingMode: output.forecastingMode,
          timestamp: output.executionTimestamp,
          notes: output.notes,
        });
      }
    } catch {
      const telemetry = rowsToUse || (activeTelemetry.length > 0 ? activeTelemetry : generateSynthetic24HourTelemetry());
      setActiveTelemetry(telemetry);
      const output = await executeForecast(telemetry);
      setForecastData(output.results);
      setMetadata({
        modelUsed: output.modelUsed,
        isQuickMlLive: output.isQuickMlLive,
        forecastingMode: output.forecastingMode,
        timestamp: output.executionTimestamp,
        notes: output.notes,
      });
    } finally {
      setIsForecasting(false);
    }
  };

  const handleRunForecastWithTelemetry = async (rows: TelemetryRow[]) => {
    await handleRefreshForecast(rows);
    setCurrentView('forecast');
  };

  // Operational metrics
  const currentPoint = forecastData[0] || null;
  const currentMode: GridMode = currentPoint?.grid_mode || 'Main Grid Mode';
  const criticalAlertCount = forecastData.filter(r => r.critical_overload).length;
  const batterySocPct = currentPoint?.battery_soc_pct ?? batteryConfig.initial_soc_pct;
  const batterySocKwh = currentPoint?.battery_soc_kwh ?? (batteryConfig.initial_soc_pct / 100) * batteryConfig.capacity_kwh;

  const peakDemand = forecastData.reduce(
    (max, r) => (r.predicted_demand_kw > max.demand ? { demand: r.predicted_demand_kw, time: r.timestamp } : max),
    { demand: 0, time: '' }
  );

  const hoursInRenewableStorage = forecastData.filter(r => r.grid_mode === 'Renewable Storage Mode').length;
  const hoursInMainGrid = forecastData.filter(r => r.grid_mode === 'Main Grid Mode').length;

  return (
    <div className="flex h-screen w-screen bg-[#030712] text-slate-100 overflow-hidden font-sans antialiased">
      {/* Collapsible Sidebar & Mobile Drawer */}
      <Sidebar
        currentView={currentView}
        onSelectView={setCurrentView}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        criticalAlertCount={criticalAlertCount}
        isQuickMlLive={metadata.isQuickMlLive}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        {/* Top Navigation */}
        <TopNav
          currentView={currentView}
          onSelectView={setCurrentView}
          onRefreshForecast={() => handleRefreshForecast()}
          isForecasting={isForecasting}
          currentMode={currentMode}
          criticalAlertCount={criticalAlertCount}
          lastForecastTimestamp={metadata.timestamp}
          isQuickMlLive={metadata.isQuickMlLive}
          onToggleMobileMenu={() => setMobileMenuOpen(prev => !prev)}
        />

        {/* Viewport Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-[#030712] relative">
          <div className="max-w-7xl mx-auto">
            {currentView === 'overview' && (
              <OverviewView
                forecastData={forecastData}
                currentMode={currentMode}
                peakDemand={peakDemand.demand}
                peakTimestamp={peakDemand.time}
                hoursInRenewableStorage={hoursInRenewableStorage}
                hoursInMainGrid={hoursInMainGrid}
                criticalAlertCount={criticalAlertCount}
                batterySocPct={batterySocPct}
                batterySocKwh={batterySocKwh}
                isQuickMlLive={metadata.isQuickMlLive}
                lastForecastTimestamp={metadata.timestamp}
                modelUsed={metadata.modelUsed}
                onNavigateToUpload={() => setCurrentView('upload')}
                onNavigateToController={() => setCurrentView('controller')}
              />
            )}

            {currentView === 'forecast' && (
              <ForecastView
                forecastData={forecastData}
                modelUsed={metadata.modelUsed}
              />
            )}

            {currentView === 'controller' && <GridControllerView />}

            {currentView === 'battery' && (
              <BatteryView
                forecastData={forecastData}
                batteryConfig={batteryConfig}
              />
            )}

            {currentView === 'mllab' && <MlLabView telemetryRows={activeTelemetry} />}

            {currentView === 'explainability' && <ExplainabilityView telemetryRows={activeTelemetry} />}

            {currentView === 'uncertainty' && (
              <UncertaintyView
                forecastData={forecastData}
                calibrationRows={activeTelemetry}
              />
            )}

            {currentView === 'peak' && <PeakIntelligenceView forecastData={forecastData} />}

            {currentView === 'nationalgrid' && <NationalGridView />}

            {currentView === 'upload' && (
              <UploadView
                onTelemetryLoaded={records => setActiveTelemetry(records)}
                onRunForecastWithTelemetry={handleRunForecastWithTelemetry}
                isForecasting={isForecasting}
              />
            )}

            {currentView === 'analytics' && <AnalyticsView />}

            {currentView === 'events' && <EventsView initialEvents={events} />}

            {currentView === 'config' && (
              <ConfigView
                batteryConfig={batteryConfig}
                onSaveBatteryConfig={setBatteryConfig}
                metadata={metadata}
              />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
