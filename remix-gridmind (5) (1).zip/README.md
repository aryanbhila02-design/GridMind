# GridMind — Smart Energy Microgrid & Demand Forecasting Engine
**HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine**  
*Zoho Catalyst AppSail & QuickML Production Integration Guide*

---

## 1. Project Overview & Architectural Boundaries

**GridMind** is an intelligent energy microgrid decision-support, 24-hour demand forecasting, battery simulation, and machine learning research platform built for **HackSphere 3.0**.

The system accepts hourly weather and telemetry inputs, forecasts electricity demand over a 24-hour horizon, deterministically evaluates grid dispatch operating modes according to official HackSphere 3.0 rules, simulates battery electrochemical storage (BESS), and generates critical overload alerts.

### Technical Scope & Domain Separation:
1. **Local Microgrid Telemetry & Hourly Dispatch (kW)**:
   - Scope: Local feeder and distributed energy resources (DERs).
   - Units: Kilowatts (kW).
   - Machine Learning: L2-regularized Ridge Regression model trained on official `train_telemetry.csv` (RMSE: 10.03 kW, MAE: 7.56 kW, $R^2$: 0.943; held-out walk-forward CV: RMSE 10.45 kW).
   - Evaluated via `predict.py` (Interfaces A & B) and `forecastingEngine.ts`.
2. **Macro National/Regional Power Position (`electric_data` / QuickML) (MW)**:
   - Scope: Central Electricity Authority (CEA) / Grid Controller of India Bulk Grid Benchmark (electric Data.pdf, 5 pages).
   - Units: Net Megawatts (MW, where $1\text{ MW} = 1,000\text{ kW}$).
   - Deployed QuickML Model: `Hacksphere_Prediction_Pipeline_model`.
   - QuickML Endpoint: `Hacksphere_Electricity_Prediction`.
   - Dataset: `electric_data`.
   - Target: `May_2026_peak_demand_MW`.
   - Task: Regional Summer Heatwave Peak Demand Regression (MW net).
   - **Target Anti-Leakage Protocol**: `May_2026_peak_demand_MW` is strictly stripped from inference requests to prevent target leakage. Input features include `Region_ID`, `Entity_Name`, and baseline historical demand.

> **Operational Scope & Decision Support Notice**: GridMind is a software-level decision-support and simulation engine. It does not directly command physical switchgear or high-voltage electrical actuators.

---

## 2. Core Architecture & Technologies

- **Frontend**: React 19, TypeScript, Vite 8, Tailwind CSS v4, Lucide icons, Motion.
- **Backend API**: Express 4 running under Node.js 20/22 with ESM bundling, Vite development middleware in dev mode, and static asset serving in production.
- **Zoho Catalyst Hosting**: Fully configured for **Catalyst AppSail** (`catalyst.json` and `app-config.json`) with auto-detected listening port (`X_ZOHO_CATALYST_LISTEN_PORT || PORT || 3000`), `0.0.0.0` host binding, and graceful `SIGTERM`/`SIGINT` container shutdowns.
- **Machine Learning Integration**:
  - **QuickML Client (`src/engine/quickmlClient.ts`)**: Server-side proxy reading credentials exclusively from protected environment variables, with SSRF protection, deterministic timeout, non-leaking diagnostics, and truthful connection verification.
  - **Regional QuickML Predictor**: `invokeQuickMLRegionalPeakDemand` executing predictions on regional `electric_data` entities, preventing target leakage.
  - **Hourly Microgrid Predictor**: Unified Ridge Regression pipeline trained on `train_telemetry.csv`, replicated identically in TypeScript (`forecastingEngine.ts`) and Python (`predict.py`).
  - **ML Research Lab**: In-browser and server implementations of Gradient Descent, Perceptron Binary Classifier, and Multilayer Perceptron (MLP 5-16-8-1) with analytical backpropagation and finite-difference gradient checks.
  - **Explainability**: Permutation Feature Importance ($\Delta$RMSE).
  - **Uncertainty**: Conformal Prediction intervals (80%, 90%, 95%).
  - **What-If Scenarios**: BESS capacity comparison engine.
- **Data Persistence**: File-backed atomic JSON persistence with directory initialization, temporary-file write renaming, and corrupted file tolerance:
  - `data/persisted_telemetry.json` (uploaded and active telemetry)
  - `data/persisted_forecast.json` (latest 24-hr demand forecast & metadata)
  - `data/persisted_events.json` (audit logs & mode changes)
  - `data/persisted_settings.json` (battery storage configuration)
  - `data/persisted_experiments.json` (ML Lab training runs)

---

## 3. Official HackSphere 3.0 Controller Rules & Threshold Parity

The energy transition controller deterministically evaluates every forecast hour $t$:

1. **Renewable Storage Mode**:
   $$\text{Mode} = \text{Renewable Storage Mode} \iff \text{Demand}_t > 160.0\text{ kW} \quad\lor\quad \text{Hour}_t \in [18, 19, 20, 21, 22]$$
2. **Main Grid Mode**:
   $$\text{Mode} = \text{Main Grid Mode} \iff \text{Demand}_t \le 160.0\text{ kW} \quad\land\quad \text{Hour}_t \notin [18, 19, 20, 21, 22]$$
3. **Critical Overload Alert**:
   $$\text{Alert} = \text{True} \iff \text{Demand}_t \ge 200.0\text{ kW}$$

> **Threshold Parity Guarantee**: All sub-engines, including `peakIntelligenceEngine.ts`, strictly use `kw > 160.0` (correcting legacy `>= 160.0` discrepancies). Exactly at 160.00 kW outside evening hours, the system remains in **Main Grid Mode**. At 160.01 kW, it transitions to **Renewable Storage Mode**.

---

## 4. Zoho Catalyst QuickML Model Specification

| Property | Value | Notes |
| :--- | :--- | :--- |
| **Model Name** | `Hacksphere_Prediction_Pipeline_model` | Trained regression model |
| **Endpoint Name** | `Hacksphere_Electricity_Prediction` | Published endpoint in Catalyst QuickML Console |
| **Source Dataset** | `electric_data` | CEA Peak Power Supply Position Report (Revised) |
| **Prediction Target** | `May_2026_peak_demand_MW` | Net Megawatts (MW) regional peak electricity demand |
| **Task Type** | Tabular Regression | Continuous numeric target |
| **Expected Input Features** | `Region_ID`, `Entity_Name`, `Jan_2026_peak_demand_MW`, `Peak_Demand_MW`, `Peak_Met_MW` | Regional entity attributes |
| **Forbidden Features** | `May_2026_peak_demand_MW`, `target` | Strictly stripped to prevent target leakage |
| **Suitability Classification** | Technical Reference Data & Macro Grid Benchmark | Not an hourly microgrid feeder demand model |

---

## 5. Security & Secret Management

1. **Zero Client Secrets**: No API keys, OAuth tokens, or client credentials are ever transmitted to frontend JavaScript, rendered in DOM attributes, or stored in browser local storage.
2. **Server-Side Proxy**: QuickML integration requests are routed exclusively through `/api/quickml/*` endpoints on the server.
3. **SSRF Protection**: Connection test and prediction routes ignore client-supplied URLs and strictly use the server's configured environment endpoint.
4. **Header Cleanliness**: Only standard `Authorization: Zoho-oauthtoken ...` (or `Bearer`), `CATALYST-KEY`, and `X-Catalyst-Project-Id` headers are transmitted.
5. **Safe Diagnostics**: Errors and exceptions log sanitized messages without leaking secret tokens or sensitive URLs.

---

## 6. Zoho Catalyst Deployment Guide

GridMind is configured for production deployment via **Zoho Catalyst AppSail**.

### Deployment Target: Catalyst AppSail
- **Service Type**: Standalone Web Application (PaaS)
- **Runtime Stack**: `node20`
- **Build Command**: `npm run build` (builds React Vite frontend to `dist/` and bundles `server.ts` to `dist/server.js`)
- **Startup Command**: `npm start` (`node dist/server.js`)
- **Port Binding**: Listens on `0.0.0.0:${process.env.X_ZOHO_CATALYST_LISTEN_PORT || process.env.PORT || 3000}`

### Deployment Configuration Files:
- **`catalyst.json`**:
```json
{
  "appsail": [
    {
      "name": "GridMind",
      "source": ".",
      "build": "npm run build",
      "run": "npm start",
      "env_variables": {
        "NODE_ENV": "production"
      }
    }
  ]
}
```

- **`app-config.json`**:
```json
{
  "command": "npm start",
  "stack": "node20",
  "env_variables": {
    "NODE_ENV": "production"
  }
}
```

### Deployment Steps:
1. **Install Zoho Catalyst CLI**:
   ```bash
   npm install -g zcatalyst-cli
   ```
2. **Login to Catalyst**:
   ```bash
   catalyst login
   ```
3. **Initialize or Associate Project**:
   ```bash
   catalyst init
   # Select your existing Zoho Catalyst project
   ```
4. **Set Production Environment Variables**:
   In the Zoho Catalyst Console (under **AppSail > Environment Variables**) or via CLI, configure:
   - `ZOHO_QUICKML_ENDPOINT`: Full callable URL of `Hacksphere_Electricity_Prediction`
   - `ZOHO_CATALYST_API_KEY`: Permanent auth token or OAuth token
   - `ZOHO_PROJECT_ID`: Your Catalyst Project ID
   - `ZOHO_CATALYST_ENV`: `production`
   - `NODE_ENV`: `production`
5. **Deploy Application**:
   ```bash
   catalyst deploy --only appsail
   ```

---

## 7. API Documentation

| Endpoint | Method | Status | Description |
| :--- | :--- | :--- | :--- |
| `GET /api/health` | GET | 200 | Truthful health check reporting backend availability, QuickML status, real request success, persistence status, and runtime info. |
| `GET /api/quickml/config` | GET | 200 | Safe QuickML status (secrets strictly excluded). |
| `GET /api/quickml/model-info` | GET | 200 | Official metadata for `Hacksphere_Prediction_Pipeline_model`. |
| `ALL /api/quickml/test-connection` | GET/POST | 200 | SSRF-safe QuickML endpoint reachability test. |
| `POST /api/quickml/regional-predict` | POST | 200 | Regional demand regression predicting `May_2026_peak_demand_MW` on `electric_data` entities with anti-leakage defense. |
| `GET /api/grid/status` | GET | 200 | Active microgrid operating mode, peak load, overload status, and battery SoC. |
| `GET /api/forecast/latest` | GET | 200 | Latest persisted 24-hour demand forecast and battery dispatch results. |
| `POST /api/forecast` | POST | 200/400 | Computes 24-hour microgrid forecast with battery simulation and grid mode evaluation. |
| `POST /api/telemetry/upload` | POST | 200/400 | Ingests CSV telemetry with RFC 4180 parsing, range validation, and persistence. |
| `POST /api/battery/config` | POST | 200/400 | Validates and persists battery capacity, power limits, and reserve thresholds. |
| `GET /api/grid/events` | GET | 200 | Audit history of grid events, mode switches, and alerts. |
| `GET /api/grid/national-power-position` | GET | 200 | National Power Supply Position benchmark reports from CEA `electric Data.pdf`. |
| `POST /api/ml/train-gradient-descent` | POST | 200 | Trains Gradient Descent Regressor and records/persists experiment. |
| `POST /api/ml/train-perceptron` | POST | 200 | Trains Single Perceptron Classifier and records/persists experiment. |
| `POST /api/ml/train-neural-net` | POST | 200 | Trains Deep MLP Regressor (5-16-8-1) and records/persists experiment. |
| `GET /api/ml/experiments` | GET | 200 | Retrieves persisted ML experiment records. |

---

## 8. Verification Commands

Run the complete verification pipeline locally:

```bash
# 1. Run unit test suite (89 unit tests across 14 test modules)
npm test

# 2. Run Python HackSphere 3.0 evaluation suite (Interfaces A & B)
python3 test_eval.py sample_test_input.csv sample_predictions.csv

# 3. TypeScript compilation / linting
npm run lint

# 4. Production build
npm run build

# 5. Start production server
npm start
```

---

## 9. Status of Configuration Steps

### Completed Steps:
- Full-stack React + TypeScript + Express architecture preserved.
- Zoho Catalyst AppSail configuration (`catalyst.json` and `app-config.json`) deployed.
- Container port handling (`X_ZOHO_CATALYST_LISTEN_PORT || PORT || 3000`) and graceful shutdown implemented.
- Centralized QuickML client (`src/engine/quickmlClient.ts`) created with zero secret leakage.
- QuickML model `Hacksphere_Prediction_Pipeline_model` and endpoint `Hacksphere_Electricity_Prediction` integrated.
- Target anti-leakage defense implemented: `May_2026_peak_demand_MW` stripped from input feature payloads.
- Clear domain distinction between macro bulk supply (MW) and microgrid hourly load (kW) documented and enforced.
- Persistence across restarts implemented for telemetry, forecasts, events, settings, and ML experiments.
- Truthful `GET /api/health` endpoint implemented reporting actual QuickML and persistence states.
- 89 automated tests passing with 100% success.
- Python evaluation contract (Interfaces A & B) verified with `test_eval.py`.

### Pending Manual Steps:
- If invoking the live QuickML model in production, populate `ZOHO_QUICKML_ENDPOINT` with the full callable URL from the Zoho Catalyst QuickML Console and `ZOHO_CATALYST_API_KEY` with the valid Catalyst auth token in your Catalyst AppSail environment.
