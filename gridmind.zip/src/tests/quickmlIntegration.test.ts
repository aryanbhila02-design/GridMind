/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Comprehensive Zoho Catalyst QuickML Integration Test Suite
 * Task 5: Validates Live QuickML, Fallback, Error Handling, and Source Transparency
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { invokeQuickMLBatch } from '../engine/quickmlClient.ts';
import { executeForecast } from '../engine/forecastingEngine.ts';
import type { TelemetryRow } from '../types/microgrid.ts';

const SAMPLE_ROWS: TelemetryRow[] = [
  {
    timestamp: '2026-10-27T14:00:00',
    ambient_temp_c: 25.0,
    humidity_pct: 50,
    solar_irradiance_wm2: 600,
  },
  {
    timestamp: '2026-10-27T15:00:00',
    ambient_temp_c: 26.5,
    humidity_pct: 48,
    solar_irradiance_wm2: 550,
  },
];

test('QuickML: Unconfigured endpoint returns unverified source and does not throw', async () => {
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;
  delete process.env.ZOHO_QUICKML_ENDPOINT;

  try {
    const res = await invokeQuickMLBatch(SAMPLE_ROWS);
    assert.equal(res.success, false);
    assert.equal(res.source, 'unverified');
    assert.ok(res.error?.includes('not configured'));
  } finally {
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
  }
});

test('QuickML: Successful response produces live_quickml source and valid predictions', async () => {
  const origFetch = globalThis.fetch;
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;
  const origKey = process.env.ZOHO_CATALYST_API_KEY;

  process.env.ZOHO_QUICKML_ENDPOINT = 'https://quickml.catalyst.zoho.com/baas/v1/project/123/ml/models/456/predict';
  process.env.ZOHO_CATALYST_API_KEY = 'mock_catalyst_auth_token';

  globalThis.fetch = async (_url, init) => {
    // Verify authorization header includes token
    const headers = init?.headers as Record<string, string>;
    assert.ok(headers['Authorization']?.includes('mock_catalyst_auth_token'));
    assert.equal(headers['Content-Type'], 'application/json');

    return new Response(JSON.stringify({ predictions: [175.4, 182.1] }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  };

  try {
    const res = await invokeQuickMLBatch(SAMPLE_ROWS);
    assert.equal(res.success, true);
    assert.equal(res.source, 'live_quickml');
    assert.deepEqual(res.predictions, [175.4, 182.1]);
    assert.ok(res.latencyMs >= 0);
  } finally {
    globalThis.fetch = origFetch;
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
    else delete process.env.ZOHO_QUICKML_ENDPOINT;
    if (origKey) process.env.ZOHO_CATALYST_API_KEY = origKey;
    else delete process.env.ZOHO_CATALYST_API_KEY;
  }
});

test('QuickML: Authentication failure (HTTP 401) reports failure without leaking secret', async () => {
  const origFetch = globalThis.fetch;
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;
  const origKey = process.env.ZOHO_CATALYST_API_KEY;

  process.env.ZOHO_QUICKML_ENDPOINT = 'https://quickml.catalyst.zoho.com/predict';
  process.env.ZOHO_CATALYST_API_KEY = 'super_secret_token_never_leak';

  globalThis.fetch = async () => {
    return new Response(JSON.stringify({ error: 'Unauthorized token' }), {
      status: 401,
      statusText: 'Unauthorized',
      headers: { 'Content-Type': 'application/json' },
    });
  };

  try {
    const res = await invokeQuickMLBatch(SAMPLE_ROWS);
    assert.equal(res.success, false);
    assert.equal(res.source, 'failed');
    assert.equal(res.httpStatus, 401);
    assert.ok(res.error?.includes('Authentication failed'));
    assert.ok(!res.error?.includes('super_secret_token_never_leak'), 'Must not leak secrets in error message');
  } finally {
    globalThis.fetch = origFetch;
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
    else delete process.env.ZOHO_QUICKML_ENDPOINT;
    if (origKey) process.env.ZOHO_CATALYST_API_KEY = origKey;
    else delete process.env.ZOHO_CATALYST_API_KEY;
  }
});

test('QuickML: Service unavailability (HTTP 503) is handled gracefully', async () => {
  const origFetch = globalThis.fetch;
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;

  process.env.ZOHO_QUICKML_ENDPOINT = 'https://quickml.catalyst.zoho.com/predict';

  globalThis.fetch = async () => {
    return new Response('Service Unavailable', {
      status: 503,
      statusText: 'Service Unavailable',
      headers: { 'Content-Type': 'text/plain' },
    });
  };

  try {
    const res = await invokeQuickMLBatch(SAMPLE_ROWS);
    assert.equal(res.success, false);
    assert.equal(res.source, 'failed');
    assert.equal(res.httpStatus, 503);
    assert.ok(res.error?.includes('QuickML service error'));
  } finally {
    globalThis.fetch = origFetch;
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
    else delete process.env.ZOHO_QUICKML_ENDPOINT;
  }
});

test('QuickML: Request timeout aborts and returns clean error', async () => {
  const origFetch = globalThis.fetch;
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;

  process.env.ZOHO_QUICKML_ENDPOINT = 'https://quickml.catalyst.zoho.com/predict';

  globalThis.fetch = async (_url, init) => {
    return new Promise((_resolve, reject) => {
      init?.signal?.addEventListener('abort', () => {
        const abortErr = new Error('This operation was aborted');
        abortErr.name = 'AbortError';
        reject(abortErr);
      });
    });
  };

  try {
    const res = await invokeQuickMLBatch(SAMPLE_ROWS, 50); // 50ms fast timeout
    assert.equal(res.success, false);
    assert.equal(res.source, 'failed');
    assert.ok(res.error?.toLowerCase().includes('timed out'));
  } finally {
    globalThis.fetch = origFetch;
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
    else delete process.env.ZOHO_QUICKML_ENDPOINT;
  }
});

test('QuickML: Invalid response schema with mismatched row count is rejected safely', async () => {
  const origFetch = globalThis.fetch;
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;

  process.env.ZOHO_QUICKML_ENDPOINT = 'https://quickml.catalyst.zoho.com/predict';

  // Return 1 item when 2 were requested
  globalThis.fetch = async () => {
    return new Response(JSON.stringify({ predictions: [150.0] }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  };

  try {
    const res = await invokeQuickMLBatch(SAMPLE_ROWS);
    assert.equal(res.success, false);
    assert.equal(res.source, 'failed');
    assert.ok(res.error?.includes('could not be parsed into 2 valid numeric predictions'));
  } finally {
    globalThis.fetch = origFetch;
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
    else delete process.env.ZOHO_QUICKML_ENDPOINT;
  }
});

test('Forecasting Engine: Uses live QuickML predictions and labels source as live_quickml', async () => {
  const origFetch = globalThis.fetch;
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;

  process.env.ZOHO_QUICKML_ENDPOINT = 'https://quickml.catalyst.zoho.com/predict';

  globalThis.fetch = async () => {
    return new Response(JSON.stringify({ predictions: [172.5, 205.0] }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  };

  try {
    const output = await executeForecast(SAMPLE_ROWS, {
      endpointUrl: process.env.ZOHO_QUICKML_ENDPOINT,
      apiKey: 'test',
      projectId: 'p1',
      catalystEnv: 'development',
      timeoutMs: 5000,
      isConnected: true,
      connectionStatus: 'connected_verified',
    });

    assert.equal(output.source, 'live_quickml');
    assert.equal(output.isQuickMlLive, true);
    assert.equal(output.forecastingMode, 'live_quickml');
    assert.equal(output.results[0].predicted_demand_kw, 172.5);
    // Task 6 check: 172.5 kW > 160 kW -> Renewable Storage Mode
    assert.equal(output.results[0].grid_mode, 'Renewable Storage Mode');
    assert.equal(output.results[1].predicted_demand_kw, 205.0);
    // Task 6 check: 205.0 kW >= 200 kW -> Critical Overload
    assert.equal(output.results[1].critical_overload, true);
  } finally {
    globalThis.fetch = origFetch;
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
    else delete process.env.ZOHO_QUICKML_ENDPOINT;
  }
});

test('Forecasting Engine: Falls back safely when QuickML fails and labels source as fallback', async () => {
  const origFetch = globalThis.fetch;
  const origEndpoint = process.env.ZOHO_QUICKML_ENDPOINT;

  process.env.ZOHO_QUICKML_ENDPOINT = 'https://quickml.catalyst.zoho.com/predict';

  globalThis.fetch = async () => {
    return new Response(JSON.stringify({ error: 'Model internal error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  };

  try {
    const output = await executeForecast(SAMPLE_ROWS, {
      endpointUrl: process.env.ZOHO_QUICKML_ENDPOINT,
      apiKey: 'test',
      projectId: 'p1',
      catalystEnv: 'development',
      timeoutMs: 5000,
      isConnected: false,
      connectionStatus: 'connection_failed',
    });

    // Verification of Task 3 & Task 5:
    assert.equal(output.source, 'fallback');
    assert.equal(output.isQuickMlLive, false);
    assert.equal(output.forecastingMode, 'quickml_failed_fallback');
    assert.ok(output.results.length === 2);
    // Predictions generated by local baseline model
    assert.ok(output.results[0].predicted_demand_kw > 0);
    assert.ok(!output.modelUsed.includes('Live Endpoint'));
  } finally {
    globalThis.fetch = origFetch;
    if (origEndpoint) process.env.ZOHO_QUICKML_ENDPOINT = origEndpoint;
    else delete process.env.ZOHO_QUICKML_ENDPOINT;
  }
});
