/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — National Power Supply Position & Bulk Grid Benchmarks
 * 
 * Sourced directly from official Central Electricity Authority (CEA) / Grid Controller of India
 * "Peak Power Supply Position Report (Revised) / अधिकतम विद्युत आपूर्ति स्थिति रिपोर्ट (संशोधित)"
 * Source Document: electric Data.pdf
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Building2,
  Download,
  FileText,
  Search,
  ShieldCheck,
  Info,
  Calendar,
  Globe,
  ArrowUpRight,
  TrendingUp,
  AlertCircle,
  FileSpreadsheet,
  CheckCircle2,
} from 'lucide-react';
import {
  getNationalGridReport,
  getForecastingSuitabilityAudit,
  exportNationalGridToCsv,
  ORDERED_REPORT_KEYS,
  MonthlySupplyReport,
  RegionalSupplyReport,
  PowerSupplyRecord,
} from '../data/nationalGridData';
import { safeFetchJson } from '../utils/apiClient';

export const NationalGridView: React.FC = () => {
  const [selectedMonth, setSelectedMonth] = useState<string>('2026-05');
  const [activeTab, setActiveTab] = useState<'monthly' | 'cumulative'>('monthly');
  const [selectedRegionFilter, setSelectedRegionFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showAuditModal, setShowAuditModal] = useState<boolean>(false);
  const [report, setReport] = useState<MonthlySupplyReport>(getNationalGridReport('2026-05'));

  const suitabilityAudit = useMemo(() => getForecastingSuitabilityAudit(), []);

  // Update report when selected month changes
  useEffect(() => {
    // Attempt to load from API if backend is running, otherwise use local typed data
    safeFetchJson<{ report?: MonthlySupplyReport }>(`/api/grid/national-power-position?month=${selectedMonth}`)
      .then(res => {
        if (res.ok && res.data?.report) {
          setReport(res.data.report);
        } else {
          setReport(getNationalGridReport(selectedMonth));
        }
      })
      .catch(() => {
        setReport(getNationalGridReport(selectedMonth));
      });
  }, [selectedMonth]);

  // Handle CSV Download via client-side Blob
  const handleDownloadCsv = () => {
    const csvContent = exportNationalGridToCsv(selectedMonth);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', url);
    downloadAnchor.setAttribute('download', `CEA_National_Power_Position_${selectedMonth}.csv`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    URL.revokeObjectURL(url);
  };

  // Handle JSON Download
  const handleDownloadJson = () => {
    const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(
      JSON.stringify(report, null, 2)
    )}`;
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', jsonString);
    downloadAnchor.setAttribute('download', `CEA_National_Power_Position_${selectedMonth}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Filter states based on region filter and search query
  const displayedRegions: RegionalSupplyReport[] = activeTab === 'monthly' ? report.regions : report.cumulative_regions;

  const flattenedStates = useMemo(() => {
    const list: { regionName: string; regionId: string; record: PowerSupplyRecord }[] = [];
    for (const reg of displayedRegions) {
      if (selectedRegionFilter !== 'ALL' && reg.region_id !== selectedRegionFilter) {
        continue;
      }
      for (const st of reg.states) {
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matches =
            st.name.toLowerCase().includes(q) ||
            (st.name_hi && st.name_hi.includes(q)) ||
            reg.region_name.toLowerCase().includes(q);
          if (!matches) continue;
        }
        list.push({
          regionName: reg.region_name,
          regionId: reg.region_id,
          record: st,
        });
      }
    }
    return list;
  }, [displayedRegions, selectedRegionFilter, searchQuery]);

  const allIndiaMetric = activeTab === 'monthly' ? report.all_india_monthly : report.all_india_cumulative;

  return (
    <div className="space-y-6 pb-12">
      {/* 1. Header Banner */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 sm:p-6 backdrop-blur-sm relative overflow-hidden">
        <div className="absolute -right-16 -top-16 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 relative z-10">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-2.5 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 flex items-center gap-1.5">
                <Globe className="w-3 h-3" />
                Technical Reference Data
              </span>
              <span className="px-2.5 py-0.5 rounded text-[11px] font-mono text-slate-300 bg-slate-800 border border-slate-700">
                CEA / Grid Controller of India
              </span>
              <span className="px-2.5 py-0.5 rounded text-[11px] font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800">
                Source: electric Data.pdf (Page {report.page_number} of 5)
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
              National Power Supply Position & Bulk Grid Benchmark
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 max-w-3xl">
              Official monthly and cumulative peak power supply metrics (MW net) across India&apos;s 5 synchronous
              electrical regions and constituent states. Integrated as a macro baseline benchmark for microgrid grid-connection reliability.
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0 flex-wrap">
            <button
              onClick={() => setShowAuditModal(true)}
              className="px-3 py-2 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
            >
              <Info className="w-3.5 h-3.5 text-cyan-400" />
              <span>Forecasting Audit</span>
            </button>
            <button
              onClick={handleDownloadCsv}
              className="px-3 py-2 rounded-lg text-xs font-medium bg-cyan-600 hover:bg-cyan-500 text-white transition flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={handleDownloadJson}
              className="px-3 py-2 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              <span>JSON</span>
            </button>
          </div>
        </div>

        {/* Month Selector Tabs */}
        <div className="mt-6 pt-5 border-t border-slate-800/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs text-slate-400 mr-2 font-medium flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-cyan-400" />
              Reporting Period:
            </span>
            {ORDERED_REPORT_KEYS.map(key => {
              const rep = getNationalGridReport(key);
              const isSelected = selectedMonth === key;
              return (
                <button
                  key={key}
                  onClick={() => setSelectedMonth(key)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-cyan-500 text-slate-950 font-semibold shadow-md shadow-cyan-500/20'
                      : 'bg-slate-800/90 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-700/60'
                  }`}
                >
                  <span>{rep.month_label}</span>
                  <span className="text-[10px] opacity-75 font-mono hidden md:inline">
                    (P.{rep.page_number})
                  </span>
                </button>
              );
            })}
          </div>

          <div className="inline-flex p-1 bg-slate-950 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setActiveTab('monthly')}
              className={`px-3 py-1 rounded-md font-medium transition cursor-pointer ${
                activeTab === 'monthly'
                  ? 'bg-slate-800 text-cyan-400 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Month: {report.month_label}
            </button>
            <button
              onClick={() => setActiveTab('cumulative')}
              className={`px-3 py-1 rounded-md font-medium transition cursor-pointer ${
                activeTab === 'cumulative'
                  ? 'bg-slate-800 text-cyan-400 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Cumulative ({report.cumulative_period.split(' to ')[0].replace('April ', 'Apr-')} to {report.cumulative_period.split(' to ')[1]})
            </button>
          </div>
        </div>
      </div>

      {/* 2. Key National Metrics Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Peak Demand */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="font-medium">All India Peak Demand</span>
            <Building2 className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="mt-2">
            <div className="text-2xl font-bold font-mono text-white tabular-nums tracking-tight">
              {allIndiaMetric.peak_demand_mw.toLocaleString()} <span className="text-xs text-cyan-400 font-sans">MW net</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
              <span>Concurrent Synchronous Grid Peak</span>
            </p>
          </div>
          <div className="mt-3 pt-2 border-t border-slate-800/80 text-[10px] text-slate-500 font-mono">
            Reporting: {activeTab === 'monthly' ? report.reporting_month : report.cumulative_period}
          </div>
        </div>

        {/* Metric 2: Peak Met */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="font-medium">All India Peak Met</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2">
            <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums tracking-tight">
              {allIndiaMetric.peak_met_mw.toLocaleString()} <span className="text-xs text-slate-400 font-sans">MW net</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Supply Reliability:{' '}
              <span className="font-semibold text-emerald-300">
                {((allIndiaMetric.peak_met_mw / allIndiaMetric.peak_demand_mw) * 100).toFixed(2)}%
              </span>
            </p>
          </div>
          <div className="mt-3 pt-2 border-t border-slate-800/80 text-[10px] text-slate-500 font-mono">
            Frequency Base: 50.00 Hz Synchronous
          </div>
        </div>

        {/* Metric 3: Demand Not Met */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="font-medium">Demand Not Met (Deficit)</span>
            <ShieldCheck className="w-4 h-4 text-blue-400" />
          </div>
          <div className="mt-2">
            <div className="text-2xl font-bold font-mono text-white tabular-nums tracking-tight">
              {allIndiaMetric.deficit_mw.toLocaleString()}{' '}
              <span className="text-xs text-slate-400 font-sans">MW ({allIndiaMetric.deficit_pct}%)</span>
            </div>
            <div className="flex items-center gap-1.5 mt-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
              <span className="text-[11px] text-emerald-400 font-medium">Near-Zero Grid Deficit</span>
            </div>
          </div>
          <div className="mt-3 pt-2 border-t border-slate-800/80 text-[10px] text-slate-500">
            Localized distribution constraints only
          </div>
        </div>

        {/* Metric 4: Scale Ratio (Microgrid vs Macro Bulk Grid) */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="font-medium">Microgrid vs Macro Scale</span>
            <ArrowUpRight className="w-4 h-4 text-purple-400" />
          </div>
          <div className="mt-2">
            <div className="text-2xl font-bold font-mono text-purple-300 tabular-nums tracking-tight">
              {(allIndiaMetric.peak_demand_mw * 1000 / 200).toLocaleString(undefined, { maximumFractionDigits: 0 })}x
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              National Bulk (MW) vs 200 kW Overload Limit
            </p>
          </div>
          <div className="mt-3 pt-2 border-t border-slate-800/80 text-[10px] text-slate-500 font-mono">
            1 MW = 1,000 kW (Scale Distinction)
          </div>
        </div>
      </div>

      {/* 3. Regional Comparison Cards */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-cyan-400" />
            5 Synchronous Regional Power Zones ({activeTab === 'monthly' ? report.month_label : report.cumulative_period})
          </h2>
          <span className="text-xs text-slate-500">Figures in Megawatts (MW net)</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {displayedRegions.map(reg => {
            const peak = reg.regional_peak;
            return (
              <div
                key={reg.region_id}
                onClick={() => setSelectedRegionFilter(reg.region_id === selectedRegionFilter ? 'ALL' : reg.region_id)}
                className={`p-3.5 rounded-xl border transition cursor-pointer ${
                  selectedRegionFilter === reg.region_id
                    ? 'bg-cyan-950/40 border-cyan-500/50 shadow-md shadow-cyan-500/10'
                    : 'bg-slate-900/50 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-white tracking-wide">{reg.region_id}</span>
                  <span className="text-[10px] font-medium text-slate-400">{reg.states.length} Entities</span>
                </div>
                <div className="text-xs text-slate-400 mt-0.5 truncate">{reg.region_name}</div>
                <div className="text-[10px] text-slate-500">{reg.region_name_hi}</div>

                <div className="mt-3 pt-2 border-t border-slate-800 flex items-baseline justify-between font-mono">
                  <span className="text-[11px] text-slate-400">Peak:</span>
                  <span className="text-sm font-semibold text-white">
                    {peak.peak_demand_mw.toLocaleString()} <span className="text-[10px] text-slate-400 font-sans">MW</span>
                  </span>
                </div>

                <div className="mt-1 flex items-center justify-between text-[11px] font-mono">
                  <span className="text-slate-400">Met:</span>
                  <span className="text-emerald-400 font-medium">
                    {peak.peak_met_mw.toLocaleString()} MW
                  </span>
                </div>

                <div className="mt-1 flex items-center justify-between text-[10px] font-mono">
                  <span className="text-slate-500">Deficit:</span>
                  <span className={peak.deficit_mw > 0 ? 'text-amber-400 font-semibold' : 'text-slate-400'}>
                    {peak.deficit_mw} MW ({peak.deficit_pct}%)
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Filterable State / System Table */}
      <div className="bg-slate-900/70 border border-slate-800 rounded-xl overflow-hidden backdrop-blur-sm">
        {/* Table Controls */}
        <div className="p-4 border-b border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-medium text-slate-400">Filter Region:</span>
            {['ALL', 'NR', 'WR', 'SR', 'ER', 'NER'].map(r => (
              <button
                key={r}
                onClick={() => setSelectedRegionFilter(r)}
                className={`px-2.5 py-1 rounded text-xs font-mono font-medium transition cursor-pointer ${
                  selectedRegionFilter === r
                    ? 'bg-cyan-500 text-slate-950 font-semibold'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {r}
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search State or UT..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider text-[10px] font-semibold border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Constituent State / UT / System</th>
                <th className="py-3 px-3">Region</th>
                <th className="py-3 px-3 text-right">Peak Demand (MW net)</th>
                <th className="py-3 px-3 text-right">Peak Met (MW net)</th>
                <th className="py-3 px-3 text-right">Deficit (MW)</th>
                <th className="py-3 px-3 text-right">Deficit (%)</th>
                <th className="py-3 px-4">System Classification & Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {flattenedStates.length > 0 ? (
                flattenedStates.map(({ regionName, regionId, record }) => {
                  return (
                    <tr key={record.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-2.5 px-4 font-sans">
                        <div className="font-medium text-white flex items-center gap-1.5">
                          <span>{record.name}</span>
                          {record.is_standalone && (
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-medium bg-amber-500/10 text-amber-400 border border-amber-500/30">
                              Stand-Alone
                            </span>
                          )}
                        </div>
                        {record.name_hi && (
                          <div className="text-[11px] text-slate-400 font-sans">{record.name_hi}</div>
                        )}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 border border-slate-700/60">
                          {regionId}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right font-semibold text-white tabular-nums">
                        {record.peak_demand_mw.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right text-emerald-400 font-medium tabular-nums">
                        {record.peak_met_mw.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right tabular-nums">
                        <span
                          className={record.deficit_mw > 0 ? 'text-amber-400 font-semibold' : 'text-slate-400'}
                        >
                          {record.deficit_mw.toLocaleString()}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right tabular-nums">
                        <span
                          className={record.deficit_pct > 0 ? 'text-amber-400 font-semibold' : 'text-slate-400'}
                        >
                          {record.deficit_pct.toFixed(2)}%
                        </span>
                      </td>
                      <td className="py-2.5 px-4 font-sans text-[11px] text-slate-400">
                        {record.notes ? (
                          <span className="text-cyan-300/90">{record.notes}</span>
                        ) : record.is_standalone ? (
                          <span className="text-amber-300/80">Island microgrid, not synchronous with mainland grid</span>
                        ) : (
                          <span className="text-slate-400">Mainland synchronous transmission grid</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400 font-sans">
                    No matching states or systems found for &quot;{searchQuery}&quot;
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 5. Document Footnotes & Provenance Details */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 space-y-3">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-300 uppercase tracking-wider">
          <FileText className="w-4 h-4 text-cyan-400" />
          <span>Official CEA Document Footnotes & Data Provenance (electric Data.pdf)</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-400">
          {report.footnotes.map((fn, idx) => (
            <div key={idx} className="p-3 rounded-lg bg-slate-950/60 border border-slate-800/80 flex items-start gap-2.5">
              <span className="font-mono text-cyan-400 font-semibold shrink-0">{idx + 1}.</span>
              <p className="leading-relaxed">{fn.replace(/^\d+\.\s*/, '')}</p>
            </div>
          ))}
        </div>
      </div>

      {/* 6. Technical Engineering Audit Modal */}
      {showAuditModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-5 shadow-2xl relative">
            <div className="flex items-start justify-between">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                  Engineering Suitability Audit
                </span>
                <h3 className="text-lg font-bold text-white mt-1">
                  Why electric Data.pdf is Technical Reference Data vs ML Training Telemetry
                </h3>
              </div>
              <button
                onClick={() => setShowAuditModal(false)}
                className="text-slate-400 hover:text-white text-sm p-1 rounded hover:bg-slate-800 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs text-slate-300">
              <div className="p-3.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-200 space-y-1">
                <div className="font-semibold flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                  Classification: {suitabilityAudit.category}
                </div>
                <p className="text-[11px] leading-relaxed text-amber-300/90">
                  Direct ingestion of monthly macro-level peak MW data into the 24-hour microgrid telemetry pipeline is mathematically invalid and causes severe target leakage.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">Technical Disqualification Reasons for Hourly ML Training:</h4>
                <ul className="space-y-2">
                  {suitabilityAudit.reasons.map((r, i) => (
                    <li key={i} className="flex items-start gap-2 text-slate-300">
                      <span className="text-rose-400 font-bold font-mono">✕</span>
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="font-semibold text-white mb-2">Architecturally Sound Usage in GridMind:</h4>
                <ul className="space-y-2">
                  {suitabilityAudit.recommended_usage.map((u, i) => (
                    <li key={i} className="flex items-start gap-2 text-slate-300">
                      <span className="text-emerald-400 font-bold font-mono">✓</span>
                      <span>{u}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 font-mono text-[11px] flex justify-between items-center text-slate-400">
                <span>Units: {suitabilityAudit.units.national_grid}</span>
                <span>Microgrid: {suitabilityAudit.units.microgrid_telemetry}</span>
                <span className="text-cyan-400 font-semibold">{suitabilityAudit.units.conversion_ratio}</span>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setShowAuditModal(false)}
                className="px-4 py-2 rounded-lg text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white transition cursor-pointer"
              >
                Close Audit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
