/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * GridMind — Centralized Zoho Catalyst QuickML Client
 * HackSphere 3.0: Smart Energy Microgrid & Demand Forecasting Engine
 * 
 * Secure Server-Side Invocation of Zoho Catalyst QuickML REST Endpoint:
 * - Credentials sourced strictly from server-side environment variables
 * - No client-side credential transmission or exposure
 * - Standard Zoho Catalyst OAuth / Project headers
 * - Deterministic timeout and non-leaking error diagnostics
 * - Transparent response validation (never masks failures as successes)
 */

import type { TelemetryRow } from '../types/microgrid.ts';

export interface QuickMLInferenceResult {
  success: boolean;
  predictions?: number[];
  httpStatus?: number;
  latencyMs: number;
  error?: string;
  source: 'live_quickml' | 'unverified' | 'failed';
}

export interface ServerQuickMLConfig {
  endpointUrl: string;
  apiKey: string;
  projectId: string;
  catalystEnv: string;
  timeoutMs: number;
}

/**
 * Loads trusted server-side QuickML configuration from process.env
 */
export function getServerQuickMLConfig(): ServerQuickMLConfig {
  return {
    endpointUrl: (process.env.ZOHO_QUICKML_ENDPOINT || '').trim(),
    apiKey: (process.env.ZOHO_CATALYST_API_KEY || '').trim(),
    projectId: (process.env.ZOHO_PROJECT_ID || '').trim(),
    catalystEnv: (process.env.ZOHO_CATALYST_ENV || 'development').trim(),
    timeoutMs: Number(process.env.ZOHO_QUICKML_TIMEOUT_MS) || 8000,
  };
}

/**
 * Checks whether QuickML is configured with an endpoint URL
 */
export function isQuickMLConfigured(): boolean {
  const config = getServerQuickMLConfig();
  return Boolean(config.endpointUrl && config.endpointUrl.startsWith('http'));
}

/**
 * Invokes published Zoho Catalyst QuickML batch prediction endpoint.
 * Conforms to Catalyst QuickML REST payload structure.
 */
export async function invokeQuickMLBatch(
  rows: TelemetryRow[],
  customTimeoutMs?: number
): Promise<QuickMLInferenceResult> {
  const config = getServerQuickMLConfig();
  const start = Date.now();

  if (!config.endpointUrl || !config.endpointUrl.startsWith('http')) {
    return {
      success: false,
      latencyMs: 0,
      error: 'Zoho Catalyst QuickML endpoint is not configured in server environment (ZOHO_QUICKML_ENDPOINT).',
      source: 'unverified',
    };
  }

  // Prevent SSRF: allow only https/http to legitimate catalyst or external endpoints
  try {
    const parsed = new URL(config.endpointUrl);
    if (!['https:', 'http:'].includes(parsed.protocol)) {
      return {
        success: false,
        latencyMs: 0,
        error: 'Invalid protocol for QuickML endpoint. Only HTTPS/HTTP permitted.',
        source: 'failed',
      };
    }
  } catch {
    return {
      success: false,
      latencyMs: 0,
      error: 'Malformed QuickML endpoint URL.',
      source: 'failed',
    };
  }

  // Construct feature payload compatible with both batch and single QuickML endpoints
  const instances = rows.map(r => ({
    timestamp: r.timestamp,
    ambient_temp_c: Number(r.ambient_temp_c),
    humidity_pct: Number(r.humidity_pct),
    solar_irradiance_wm2: Number(r.solar_irradiance_wm2),
  }));

  const payload = {
    instances,
    data: instances,
    ...(instances.length === 1 ? instances[0] : {}),
  };

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  };

  // Standard Catalyst OAuth & API Key headers
  if (config.apiKey) {
    const authHeader = config.apiKey.startsWith('Zoho-oauthtoken') || config.apiKey.startsWith('Bearer')
      ? config.apiKey
      : `Zoho-oauthtoken ${config.apiKey}`;
    headers['Authorization'] = authHeader;
    headers['CATALYST-KEY'] = config.apiKey;
  }

  if (config.projectId) {
    headers['X-Catalyst-Project-Id'] = config.projectId;
  }

  if (config.catalystEnv) {
    headers['X-Catalyst-Environment'] = config.catalystEnv;
  }

  const timeoutMs = customTimeoutMs || config.timeoutMs;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(config.endpointUrl, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
    clearTimeout(timer);

    const latencyMs = Date.now() - start;

    if (!response.ok) {
      let errorDetail = `HTTP ${response.status} (${response.statusText})`;
      if (response.status === 401 || response.status === 403) {
        errorDetail = `Authentication failed (HTTP ${response.status}). Verify ZOHO_CATALYST_API_KEY in server environment.`;
      } else if (response.status === 404) {
        errorDetail = `Endpoint not found (HTTP 404). Verify ZOHO_QUICKML_ENDPOINT path in Catalyst console.`;
      } else if (response.status === 405) {
        errorDetail = `QuickML endpoint returned HTTP 405 Method Not Allowed. Verify endpoint URL, model deployment path, or HTTP method in Catalyst console.`;
      } else if (response.status >= 500) {
        errorDetail = `QuickML service error (HTTP ${response.status}). Service temporarily unavailable.`;
      }

      return {
        success: false,
        httpStatus: response.status,
        latencyMs,
        error: errorDetail,
        source: 'failed',
      };
    }

    const contentType = response.headers.get('content-type') || '';
    if (!contentType.toLowerCase().includes('application/json')) {
      return {
        success: false,
        httpStatus: response.status,
        latencyMs,
        error: `QuickML returned non-JSON content-type "${contentType}". Expected application/json.`,
        source: 'failed',
      };
    }

    const resJson = await response.json();
    let preds: number[] = [];

    // Robust parsing across all official Catalyst QuickML response schemas
    if (Array.isArray(resJson.predictions)) {
      preds = resJson.predictions.map((p: unknown) => {
        if (typeof p === 'number') return p;
        if (typeof p === 'object' && p !== null) {
          const obj = p as Record<string, unknown>;
          return Number(obj.target_demand_kw ?? obj.prediction ?? obj.demand_kw ?? NaN);
        }
        return Number(p);
      });
    } else if (Array.isArray(resJson.data)) {
      preds = resJson.data.map((d: unknown) => {
        if (typeof d === 'number') return d;
        if (typeof d === 'object' && d !== null) {
          const obj = d as Record<string, unknown>;
          return Number(obj.target_demand_kw ?? obj.prediction ?? obj.demand_kw ?? NaN);
        }
        return Number(d);
      });
    } else if (Array.isArray(resJson)) {
      preds = resJson.map((item: unknown) => {
        if (typeof item === 'number') return item;
        if (typeof item === 'object' && item !== null) {
          const obj = item as Record<string, unknown>;
          return Number(obj.target_demand_kw ?? obj.prediction ?? NaN);
        }
        return Number(item);
      });
    } else if (rows.length === 1) {
      // Single prediction schema support
      const singleVal = resJson.prediction ?? resJson.target_demand_kw ?? resJson.data?.prediction ?? resJson.data?.target_demand_kw ?? resJson.result;
      if (singleVal !== undefined && singleVal !== null) {
        preds = [Number(singleVal)];
      }
    }

    // Validate prediction count and numerical validity
    if (preds.length === rows.length && preds.every(p => !isNaN(p) && Number.isFinite(p))) {
      return {
        success: true,
        predictions: preds,
        httpStatus: response.status,
        latencyMs,
        source: 'live_quickml',
      };
    } else {
      return {
        success: false,
        httpStatus: response.status,
        latencyMs,
        error: `QuickML response received (HTTP ${response.status}) but payload could not be parsed into ${rows.length} valid numeric predictions (got ${preds.length}).`,
        source: 'failed',
      };
    }
  } catch (err: unknown) {
    clearTimeout(timer);
    const latencyMs = Date.now() - start;
    const msg = err instanceof Error ? err.message : String(err);
    const isTimeout = msg.toLowerCase().includes('abort') || msg.toLowerCase().includes('timeout');
    return {
      success: false,
      latencyMs,
      error: isTimeout
        ? `Zoho Catalyst QuickML request timed out after ${timeoutMs}ms.`
        : `QuickML request network error: ${msg}`,
      source: 'failed',
    };
  }
}
